# ============================================================
#  PHASE 3 — FAIR BENCHMARKING — 25-bar space truss
#  Mirrors the 10-bar Phase 3 methodology (see
#  phase3_10bar_benchmark.py), adapted for:
#    - 8 DISCRETE design groups (snap every candidate before FEM)
#    - 16 random variables, additional deterministic stress check
#
#  Answers R1-2, R3-2 for this benchmark: PSO, GA, SLSQP are each
#  run under their NATIVE budget (as originally used) and under a
#  MATCHED budget (~200 evaluations, the order of magnitude the
#  LLM operator consumes for this truss), with the SAME discrete
#  coordinate-descent refinement applied to every method's output.

# ============================================================

import numpy as np
from scipy.stats import norm
from scipy.optimize import minimize, differential_evolution
import time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

# ================================================================
# PROBLEM CONSTANTS  (identical to Phase 0/1, validated)
# ================================================================
E_MEAN   = 1e7
RHO      = 0.1
SIG_LIM  = 40e3
DISP_LIM = 0.35

P1x_M = 1.0e3;  P1y_M = 10.0e3; P1z_M = 10.0e3
P2y_M = 10.0e3; P2z_M = 10.0e3
P3x_M = 0.5e3;  P6x_M = 0.6e3

TARGET_R = 0.99
COV      = 0.05

DISC_VALS = np.array([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,
                      1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0,
                      2.1,2.2,2.3,2.4,2.5,2.6,2.8,3.0,3.2,3.4])
A_MIN, A_MAX, N_GRP = DISC_VALS[0], DISC_VALS[-1], 8

N_SEEDS        = 20
NATIVE_SEEDS   = 5     # expensive native-budget runs — order of magnitude only
SEEDS          = list(range(1, N_SEEDS + 1))
SEEDS_NATIVE   = list(range(1, NATIVE_SEEDS + 1))

MATCHED_EVAL_CAP = 200   # ~ order of magnitude the LLM operator used for 25-bar

OUT_CSV  = "phase3_perrun_25bar.csv"
OUT_XLSX = "phase3_25bar_benchmark.xlsx"

# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS = ["fem_solves", "ls_evals", "form_calls", "hlrf_iters", "eval_calls"]
    def __init__(self):
        self.phase = "search"; self.data = {}
    def _d(self):
        if self.phase not in self.data:
            self.data[self.phase] = {f: 0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self, f, n=1): self._d()[f] += n
    def set_phase(self, p): self.phase = p; self._d()
    def total(self, f): return sum(d[f] for d in self.data.values())

CNT = Counters()

# ================================================================
# GEOMETRY  (identical to Phase 0/1, validated against JJ's Colab run)
# ================================================================
NODES = np.array([
    [-37.5,   0.0, 200.0], [ 37.5,   0.0, 200.0],
    [-37.5,  37.5, 100.0], [ 37.5,  37.5, 100.0],
    [ 37.5, -37.5, 100.0], [-37.5, -37.5, 100.0],
    [-100.0, 100.0,  0.0], [ 100.0, 100.0,  0.0],
    [ 100.0,-100.0,  0.0], [-100.0,-100.0,  0.0],
], dtype=float)

ELEM_N1 = np.array([0,0,1,0,1, 1,1,0,0, 5,3,2,5, 2,5,3,4, 3,2,4,5, 5,2,3,4])
ELEM_N2 = np.array([1,3,2,4,5, 3,4,2,5, 2,4,3,4, 9,6,8,7, 6,7,9,8, 9,6,7,8])
IDA     = np.array([0,1,1,1,1, 2,2,2,2, 3,3,4,4, 5,5,5,5, 6,6,6,6, 7,7,7,7])

N_EL, N_SDOF = 25, 30
FIXED_DOFS = list(range(18, 30))
FREE_DOFS  = [d for d in range(N_SDOF) if d not in FIXED_DOFS]

EL_LE  = np.array([np.linalg.norm(NODES[ELEM_N2[i]]-NODES[ELEM_N1[i]]) for i in range(N_EL)])
EL_DIR = np.array([(NODES[ELEM_N2[i]]-NODES[ELEM_N1[i]])/EL_LE[i] for i in range(N_EL)])

# --- Precompute per-element constant quantities ONCE (speedup only,
#     identical numerics): unit 6x6 stiffness (with E*A/le factored out),
#     global dof indices, and the E-independent stress-recovery row. ---
_EL_KE_UNIT, _EL_DOFS, _EL_STRESS_ROW = [], [], []
for _i in range(N_EL):
    _lx, _ly, _lz = EL_DIR[_i]; _le = EL_LE[_i]
    _Te = np.array([[_lx,_ly,_lz,0,0,0],[0,0,0,_lx,_ly,_lz]])
    _EL_KE_UNIT.append(_Te.T @ np.array([[1.,-1.],[-1.,1.]]) @ _Te)
    _n1, _n2 = ELEM_N1[_i], ELEM_N2[_i]
    _EL_DOFS.append([3*_n1,3*_n1+1,3*_n1+2,3*_n2,3*_n2+1,3*_n2+2])
    _EL_STRESS_ROW.append(np.array([-1/_le, 1/_le]) @ _Te)
_EL_KE_UNIT   = np.array(_EL_KE_UNIT)
_EL_DOFS      = np.array(_EL_DOFS)
_EL_STRESS_ROW = np.array(_EL_STRESS_ROW)

def snap_discrete(A):
    return np.array([DISC_VALS[np.argmin(np.abs(DISC_VALS - a))] for a in np.asarray(A, dtype=float)])

# ================================================================
# FEM + FORM + EVALUATE  (identical to Phase 0/1, validated)
# ================================================================
def fem_25bar(A_grp, E_v=E_MEAN, p1x=P1x_M, p1y=P1y_M, p1z=P1z_M,
              p2y=P2y_M, p2z=P2z_M, p3x=P3x_M, p6x=P6x_M):
    CNT.inc("fem_solves")
    A_grp = np.asarray(A_grp, dtype=float).ravel()
    A_el  = A_grp[IDA]
    K     = np.zeros((N_SDOF, N_SDOF))
    scale = E_v * A_el / EL_LE          # (25,) per-element E*A/le factor
    for i in range(N_EL):
        idx = _EL_DOFS[i]
        K[np.ix_(idx, idx)] += scale[i] * _EL_KE_UNIT[i]
    wt = RHO * np.sum(EL_LE * A_el)

    F = np.zeros(N_SDOF)
    F[0] += p1x; F[1] -= p1y; F[2] -= p1z
    F[4] -= p2y; F[5] -= p2z
    F[6] += p3x; F[15] += p6x

    Kb, Fb = K.copy(), F.copy()
    for d in FIXED_DOFS:
        Kb[d,:] = 0; Kb[:,d] = 0; Kb[d,d] = 1; Fb[d] = 0
    try:
        U = np.linalg.solve(Kb, Fb)
    except np.linalg.LinAlgError:
        return np.zeros(N_SDOF), np.zeros(N_EL), np.inf

    stress = np.array([E_v * (_EL_STRESS_ROW[i] @ U[_EL_DOFS[i]]) for i in range(N_EL)])
    return U, stress, wt

def form_25bar(A_grp):
    CNT.inc("form_calls")
    A_grp = np.asarray(A_grp, dtype=float).ravel()
    mu_X = np.array([E_MEAN, P1x_M, P1y_M, P1z_M, P2y_M, P2z_M, P3x_M, P6x_M, *A_grp])
    sig_X = COV * mu_X
    N_RV = 16

    def g(X):
        CNT.inc("ls_evals")
        E_v, p1x, p1y, p1z, p2y, p2z, p3x, p6x = X[:8]
        try:
            U, _, _ = fem_25bar(X[8:16], E_v, p1x, p1y, p1z, p2y, p2z, p3x, p6x)
            return DISP_LIM - np.max(np.abs(U[:4]))
        except Exception:
            return -1.0

    g_mean = g(mu_X)
    u, b_prev, h = np.zeros(N_RV), 0.0, 1e-4
    for _ in range(30):
        CNT.inc("hlrf_iters")
        X = mu_X + sig_X * u
        g0 = g(X)
        dg = np.array([(g(mu_X + sig_X*(u + h*np.eye(N_RV)[j])) - g0)/h for j in range(N_RV)])
        nd = np.linalg.norm(dg)
        if nd < 1e-12: break
        alpha = dg / nd
        beta_k = -alpha @ u + g0/nd
        u_new = -alpha * beta_k
        if np.linalg.norm(u_new-u) < 1e-4:
            u = u_new; break
        u = u_new
        b_now = np.linalg.norm(u)
        if abs(b_now-b_prev) < 1e-4: break
        b_prev = b_now

    beta = np.linalg.norm(u)
    if g_mean < 0: beta = -beta
    return float(beta), float(norm.cdf(beta))

def evaluate(A_grp):
    CNT.inc("eval_calls")
    A_grp = np.clip(np.asarray(A_grp, dtype=float).ravel(), A_MIN, A_MAX)
    U, stress, weight = fem_25bar(A_grp)
    max_stress = np.max(np.abs(stress))
    beta, R = form_25bar(A_grp)
    feasible = (R >= TARGET_R - 1e-6) and (max_stress <= SIG_LIM)
    return weight, R, feasible, max_stress

def penalty_fitness(A_grp):
    """Continuous relaxation for PSO/GA (they explore continuously,
    output is snapped to the discrete grid before every evaluation)."""
    A_snapped = snap_discrete(A_grp)
    W, R, feas, sig = evaluate(A_snapped)
    if R < TARGET_R:
        return W + 1e4 + 1e6*(TARGET_R - R)**2
    if sig > SIG_LIM:
        return W + 1e4 + 1e-1*(sig - SIG_LIM)
    return W

A_SORA = np.array([0.1, 2.0, 3.4, 0.1, 0.1, 1.2, 1.9, 3.4])

def init_design(mode, rng):
    if mode == "warm":
        candidates = [
            np.array([0.1, 1.0, 3.4, 0.1, 0.5, 1.5, 1.5, 3.4]),
            np.array([0.1, 0.3, 3.4, 0.1, 2.0, 2.0, 1.8, 3.4]),
            snap_discrete(A_SORA + rng.uniform(-0.3, 0.3, N_GRP)),
        ]
        feas_costs = []
        for c in candidates:
            cs = snap_discrete(c)
            w, r, feas, _ = evaluate(cs)
            feas_costs.append((cs, w if feas else np.inf + w))
        return min(feas_costs, key=lambda x: x[1])[0]
    else:
        return snap_discrete(rng.uniform(A_MIN, A_MAX, N_GRP))

def coord_descent_discrete(A_init, W_init, R_init, max_passes=20):
    A = snap_discrete(A_init.copy()); W, R = W_init, R_init
    improved = True
    for _ in range(max_passes):
        if not improved: break
        improved = False
        for i in range(N_GRP):
            idx_cur = np.argmin(np.abs(DISC_VALS - A[i]))
            if idx_cur == 0: continue
            A_try = A.copy()
            A_try[i] = DISC_VALS[idx_cur-1]
            W_t, R_t, feas, _ = evaluate(A_try)
            if feas and W_t < W:
                A, W, R = A_try, W_t, R_t; improved = True
    return A, W, R

# ================================================================
# PSO  (continuous exploration, snapped to discrete grid per eval)
# ================================================================
def run_pso(seed, init_mode, n_iters, n_particles, eval_cap=None):
    rng = np.random.RandomState(seed)
    n = n_particles
    if init_mode == "warm":
        X0 = init_design("warm", rng)
        X = np.tile(X0, (n,1)) + rng.uniform(-0.5, 0.5, (n, N_GRP))
    else:
        X = rng.uniform(A_MIN, A_MAX, (n, N_GRP))
    X = np.clip(X, A_MIN, A_MAX)
    V = rng.uniform(-0.3, 0.3, (n, N_GRP))
    fit = np.array([penalty_fitness(X[i]) for i in range(n)])
    pb, pb_fit = X.copy(), fit.copy()
    gi = np.argmin(pb_fit); gb, gb_fit = pb[gi].copy(), pb_fit[gi]
    w, c1, c2 = 0.72, 1.49, 1.49
    for it in range(n_iters):
        if eval_cap and CNT.total("eval_calls") >= eval_cap: break
        r1 = rng.rand(n, N_GRP); r2 = rng.rand(n, N_GRP)
        V = w*V + c1*r1*(pb-X) + c2*r2*(gb-X)
        X = np.clip(X+V, A_MIN, A_MAX)
        for i in range(n):
            f = penalty_fitness(X[i])
            if f < pb_fit[i]:
                pb[i], pb_fit[i] = X[i].copy(), f
                if f < gb_fit: gb, gb_fit = X[i].copy(), f
            if eval_cap and CNT.total("eval_calls") >= eval_cap: break
    gb_snap = snap_discrete(gb)
    W_f, R_f, feas_f, _ = evaluate(gb_snap)
    return gb_snap, W_f, R_f, feas_f

# ================================================================
# GA — Differential Evolution
# ================================================================
def run_ga(seed, init_mode, maxiter, popsize, eval_cap=None):
    rng = np.random.RandomState(seed)
    calls = [0]
    def obj(A):
        calls[0] += 1
        if eval_cap and calls[0] > eval_cap:
            return 1e10
        return penalty_fitness(A)
    bounds = [(A_MIN, A_MAX)]*N_GRP
    kwargs = dict(maxiter=maxiter, popsize=popsize, seed=seed,
                  mutation=(0.5,1.0), recombination=0.7, tol=1e-6, polish=False)
    if init_mode == "warm":
        x0 = init_design("warm", rng)
        init_pop = np.clip(x0 + rng.uniform(-0.5,0.5,(popsize*N_GRP, N_GRP)), A_MIN, A_MAX)
        kwargs["init"] = init_pop
    res = differential_evolution(obj, bounds, **kwargs)
    A_snap = snap_discrete(res.x)
    W_f, R_f, feas_f, _ = evaluate(A_snap)
    return A_snap, W_f, R_f, feas_f

# ================================================================
# SLSQP  (continuous relaxation, snapped at the end)
# ================================================================
def run_slsqp(seed, init_mode, maxiter, eval_cap=None):
    rng = np.random.RandomState(seed)
    def obj(A):
        _, _, wt = fem_25bar(snap_discrete(A))
        return wt
    def con_r(A):
        _, R, _, _ = evaluate(snap_discrete(A)); return R - TARGET_R
    def con_s(A):
        _, _, _, sig = evaluate(snap_discrete(A)); return SIG_LIM - sig
    A0 = init_design(init_mode, rng)
    bounds = [(A_MIN, A_MAX)]*N_GRP
    cons = [{"type":"ineq","fun":con_r}, {"type":"ineq","fun":con_s}]
    res = minimize(obj, A0, method="SLSQP", bounds=bounds, constraints=cons,
                   options={"maxiter": maxiter, "ftol": 1e-5})
    A_snap = snap_discrete(res.x)
    W_f, R_f, feas_f, _ = evaluate(A_snap)
    return A_snap, W_f, R_f, feas_f

# ================================================================
# ONE RUN
# ================================================================
NATIVE_ITERS = 100
NATIVE_PSO_PARTICLES = 25
NATIVE_GA_POPSIZE = 12
NATIVE_SLSQP_MAXITER = 300

def run_one(method, init_mode, budget, seed):
    global CNT
    CNT = Counters()
    t0 = time.time()

    if budget == "native":
        if method == "PSO":
            A_best, W, R, feas = run_pso(seed, init_mode, NATIVE_ITERS, NATIVE_PSO_PARTICLES)
        elif method == "GA":
            A_best, W, R, feas = run_ga(seed, init_mode, NATIVE_ITERS, NATIVE_GA_POPSIZE)
        else:
            A_best, W, R, feas = run_slsqp(seed, init_mode, NATIVE_SLSQP_MAXITER)
    else:
        if method == "PSO":
            n_part = 10
            n_iter = max(1, MATCHED_EVAL_CAP // n_part)
            A_best, W, R, feas = run_pso(seed, init_mode, n_iter, n_part, eval_cap=MATCHED_EVAL_CAP)
        elif method == "GA":
            popsize = 4
            n_iter = max(1, MATCHED_EVAL_CAP // (popsize*N_GRP))
            A_best, W, R, feas = run_ga(seed, init_mode, n_iter, popsize, eval_cap=MATCHED_EVAL_CAP)
        else:
            A_best, W, R, feas = run_slsqp(seed, init_mode, maxiter=15, eval_cap=MATCHED_EVAL_CAP)

    W_search, R_search, feas_search = W, R, feas
    eval_search = CNT.total("eval_calls")

    CNT.set_phase("cd")
    W_cd, R_cd = W_search, R_search
    if feas_search and W_search < np.inf:
        A_cd, W_cd2, R_cd2 = coord_descent_discrete(A_best, W_search, R_search)
        if W_cd2 < W_search and R_cd2 >= TARGET_R:
            W_cd, R_cd = W_cd2, R_cd2

    elapsed = time.time()-t0
    return {
        "method": method, "init": init_mode, "budget": budget, "seed": seed,
        "W_search": W_search if feas_search else None,
        "W_final": W_cd if feas_search else None,
        "R_final": R_cd, "feasible": bool(feas_search),
        "CD_delta": (W_search - W_cd) if feas_search else 0.0,
        "eval_search": eval_search, "eval_total": CNT.total("eval_calls"),
        "fem_total": CNT.total("fem_solves"), "time_s": round(elapsed,2),
    }

# ================================================================
# DRIVER  (resumable)
# ================================================================
def append_csv(fname, rows, fieldnames):
    new = not os.path.exists(fname)
    with open(fname, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

METHODS = ["PSO", "GA", "SLSQP"]
INITS   = ["warm", "random"]
BUDGETS = ["native", "matched"]

def rebuild_excel():
    if not os.path.exists(OUT_CSV):
        print("No data yet."); return
    rows = list(csv.DictReader(open(OUT_CSV)))
    if not rows: return
    from collections import defaultdict
    groups = defaultdict(list)
    for r in rows: groups[(r["method"],r["init"],r["budget"])].append(r)

    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Summary"
    ws.append(["method","init","budget","n","feasible_rate",
               "W_final_mean","W_final_std","W_final_min","CD_delta_mean","eval_total_mean"])
    for (method,init,budget), rs in groups.items():
        wf = np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd = np.array([float(r["CD_delta"]) for r in rs])
        ev  = np.array([float(r["eval_total"]) for r in rs])
        feas = np.mean([r["feasible"]=="True" for r in rs])
        ws.append([method, init, budget, len(rs), feas,
                   float(wf.mean()) if len(wf) else None,
                   float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,
                   float(cdd.mean()), float(ev.mean())])
    ws.append([]); ws.append(["timestamp", datetime.datetime.now().isoformat()])
    ws.append(["note","native=5 seeds (expensive); matched=~200 eval cap, 20 seeds"])

    ws2 = wb.create_sheet("PerRun")
    keys2 = list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])

    wb.save(OUT_XLSX)
    print(f"✓ Saved: {OUT_XLSX}  ({len(rows)} total runs)")

def download_final():
    """Download the final Excel once, after the whole run completes."""
    try:
        from google.colab import files as _colab_files
        _colab_files.download(OUT_XLSX)
        print(f"⬇ Downloaded: {OUT_XLSX}")
    except Exception:
        pass

def main():
    combos = [(m,i,b) for m in METHODS for i in INITS for b in BUDGETS]
    if len(sys.argv) > 1:
        want = set(sys.argv[1:])
        combos = [c for c in combos if f"{c[0]}_{c[1]}_{c[2]}" in want or c[0] in want]

    done_seeds = {}
    if os.path.exists(OUT_CSV):
        for r in csv.DictReader(open(OUT_CSV)):
            done_seeds.setdefault((r["method"],r["init"],r["budget"]), set()).add(int(r["seed"]))

    print(f"Running {len(combos)} combos")
    for (method, init, budget) in combos:
        name = f"{method}_{init}_{budget}"
        seeds_here = SEEDS_NATIVE if budget=="native" else SEEDS
        already = done_seeds.get((method,init,budget), set())
        remaining = [s for s in seeds_here if s not in already]
        if not remaining:
            print(f"\n=== {name}: all done, skipping ==="); continue
        print(f"\n=== {name} ({len(remaining)}/{len(seeds_here)} remaining) ===")
        fieldnames = None
        for s in remaining:
            r = run_one(method, init, budget, s)
            if fieldnames is None: fieldnames = list(r.keys())
            append_csv(OUT_CSV, [r], fieldnames)
            print(f"  seed {s:2d}: W_final={r['W_final']}  R={r['R_final']:.4f}  "
                  f"eval={r['eval_total']}  t={r['time_s']}s", flush=True)
            rebuild_excel()

    rebuild_excel()
    download_final()

if __name__ == "__main__":
    main()
