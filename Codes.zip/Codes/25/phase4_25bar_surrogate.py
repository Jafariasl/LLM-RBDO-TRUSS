# ============================================================
#  PHASE 4 — SURROGATE-ASSISTED BASELINE (Kriging / EGO) — 25-bar
#  Mirrors the 10-bar Phase 4 methodology, adapted for the
#  discrete 8-group design space (candidates snapped to the grid
#  before every true evaluation) and the 16-variable reliability
#  problem with the added stress constraint.
#
#  Answers R1-3 for this benchmark: a Kriging surrogate of the
#  penalized objective is built over an initial Latin-hypercube
#  design and refined by expected-improvement infill, the same
#  discrete coordinate-descent refinement applied at the end as
#  for every other method.
#
#  Two budgets, matching Phase 3:
#    matched : ~200 true evaluations total (init DoE + infill)
#    native  : ~500 true evaluations total (larger DoE + more infill)
#
# ============================================================

import numpy as np
from scipy.stats import norm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
import time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

# ================================================================
# PROBLEM CONSTANTS  (identical to Phase 0/1/3, validated)
# ================================================================
E_MEAN   = 1e7
RHO      = 0.1
SIG_LIM  = 40e3
DISP_LIM = 0.35
P1x_M = 1.0e3;  P1y_M = 10.0e3; P1z_M = 10.0e3
P2y_M = 10.0e3; P2z_M = 10.0e3
P3x_M = 0.5e3;  P6x_M = 0.6e3
TARGET_R = 0.99
COV      = 0.05
DISC_VALS = np.array([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,
                      1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0,
                      2.1,2.2,2.3,2.4,2.5,2.6,2.8,3.0,3.2,3.4])
A_MIN, A_MAX, N_GRP = DISC_VALS[0], DISC_VALS[-1], 8

N_SEEDS      = 20
NATIVE_SEEDS = 5
SEEDS        = list(range(1, N_SEEDS+1))
SEEDS_NATIVE = list(range(1, NATIVE_SEEDS+1))

MATCHED_TOTAL = 200   # total true evaluations (matched to Phase 3)
NATIVE_TOTAL  = 500

OUT_CSV  = "phase4_perrun_25bar.csv"
OUT_XLSX = "phase4_25bar_surrogate.xlsx"

# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS = ["fem_solves", "ls_evals", "form_calls", "hlrf_iters", "eval_calls"]
    def __init__(self): self.phase="search"; self.data={}
    def _d(self):
        if self.phase not in self.data: self.data[self.phase]={f:0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self,f,n=1): self._d()[f]+=n
    def set_phase(self,p): self.phase=p; self._d()
    def total(self,f): return sum(d[f] for d in self.data.values())
CNT = Counters()

# ================================================================
# GEOMETRY + precomputed element matrices (from Phase 3, validated)
# ================================================================
NODES = np.array([
    [-37.5,0.0,200.0],[37.5,0.0,200.0],[-37.5,37.5,100.0],[37.5,37.5,100.0],
    [37.5,-37.5,100.0],[-37.5,-37.5,100.0],[-100.0,100.0,0.0],[100.0,100.0,0.0],
    [100.0,-100.0,0.0],[-100.0,-100.0,0.0]], dtype=float)
ELEM_N1 = np.array([0,0,1,0,1, 1,1,0,0, 5,3,2,5, 2,5,3,4, 3,2,4,5, 5,2,3,4])
ELEM_N2 = np.array([1,3,2,4,5, 3,4,2,5, 2,4,3,4, 9,6,8,7, 6,7,9,8, 9,6,7,8])
IDA     = np.array([0,1,1,1,1, 2,2,2,2, 3,3,4,4, 5,5,5,5, 6,6,6,6, 7,7,7,7])
N_EL, N_SDOF = 25, 30
FIXED_DOFS = list(range(18,30))
EL_LE  = np.array([np.linalg.norm(NODES[ELEM_N2[i]]-NODES[ELEM_N1[i]]) for i in range(N_EL)])
EL_DIR = np.array([(NODES[ELEM_N2[i]]-NODES[ELEM_N1[i]])/EL_LE[i] for i in range(N_EL)])

_EL_KE_UNIT, _EL_DOFS, _EL_STRESS_ROW = [], [], []
for _i in range(N_EL):
    _lx,_ly,_lz = EL_DIR[_i]; _le = EL_LE[_i]
    _Te = np.array([[_lx,_ly,_lz,0,0,0],[0,0,0,_lx,_ly,_lz]])
    _EL_KE_UNIT.append(_Te.T @ np.array([[1.,-1.],[-1.,1.]]) @ _Te)
    _n1,_n2 = ELEM_N1[_i], ELEM_N2[_i]
    _EL_DOFS.append([3*_n1,3*_n1+1,3*_n1+2,3*_n2,3*_n2+1,3*_n2+2])
    _EL_STRESS_ROW.append(np.array([-1/_le,1/_le]) @ _Te)
_EL_KE_UNIT=np.array(_EL_KE_UNIT); _EL_DOFS=np.array(_EL_DOFS); _EL_STRESS_ROW=np.array(_EL_STRESS_ROW)

def snap_discrete(A):
    return np.array([DISC_VALS[np.argmin(np.abs(DISC_VALS-a))] for a in np.asarray(A,dtype=float)])

def fem_25bar(A_grp, E_v=E_MEAN, p1x=P1x_M,p1y=P1y_M,p1z=P1z_M,p2y=P2y_M,p2z=P2z_M,p3x=P3x_M,p6x=P6x_M):
    CNT.inc("fem_solves")
    A_grp=np.asarray(A_grp,dtype=float).ravel(); A_el=A_grp[IDA]
    K=np.zeros((N_SDOF,N_SDOF)); scale=E_v*A_el/EL_LE
    for i in range(N_EL):
        idx=_EL_DOFS[i]; K[np.ix_(idx,idx)] += scale[i]*_EL_KE_UNIT[i]
    wt=RHO*np.sum(EL_LE*A_el)
    F=np.zeros(N_SDOF); F[0]+=p1x; F[1]-=p1y; F[2]-=p1z; F[4]-=p2y; F[5]-=p2z; F[6]+=p3x; F[15]+=p6x
    Kb,Fb=K.copy(),F.copy()
    for d in FIXED_DOFS: Kb[d,:]=0; Kb[:,d]=0; Kb[d,d]=1; Fb[d]=0
    try: U=np.linalg.solve(Kb,Fb)
    except np.linalg.LinAlgError: return np.zeros(N_SDOF), np.zeros(N_EL), np.inf
    stress=np.array([E_v*(_EL_STRESS_ROW[i]@U[_EL_DOFS[i]]) for i in range(N_EL)])
    return U,stress,wt

def form_25bar(A_grp):
    CNT.inc("form_calls")
    A_grp=np.asarray(A_grp,dtype=float).ravel()
    mu_X=np.array([E_MEAN,P1x_M,P1y_M,P1z_M,P2y_M,P2z_M,P3x_M,P6x_M,*A_grp]); sig_X=COV*mu_X; N_RV=16
    def g(X):
        CNT.inc("ls_evals")
        E_v,p1x,p1y,p1z,p2y,p2z,p3x,p6x=X[:8]
        try:
            U,_,_=fem_25bar(X[8:16],E_v,p1x,p1y,p1z,p2y,p2z,p3x,p6x)
            return DISP_LIM-np.max(np.abs(U[:4]))
        except Exception: return -1.0
    g_mean=g(mu_X); u,b_prev,h=np.zeros(N_RV),0.0,1e-4
    for _ in range(30):
        CNT.inc("hlrf_iters")
        X=mu_X+sig_X*u; g0=g(X)
        dg=np.array([(g(mu_X+sig_X*(u+h*np.eye(N_RV)[j]))-g0)/h for j in range(N_RV)])
        nd=np.linalg.norm(dg)
        if nd<1e-12: break
        alpha=dg/nd; beta_k=-alpha@u+g0/nd; u_new=-alpha*beta_k
        if np.linalg.norm(u_new-u)<1e-4: u=u_new; break
        u=u_new; b_now=np.linalg.norm(u)
        if abs(b_now-b_prev)<1e-4: break
        b_prev=b_now
    beta=np.linalg.norm(u)
    if g_mean<0: beta=-beta
    return float(beta), float(norm.cdf(beta))

def evaluate(A_grp):
    CNT.inc("eval_calls")
    A_grp=np.clip(np.asarray(A_grp,dtype=float).ravel(),A_MIN,A_MAX)
    U,stress,weight=fem_25bar(A_grp); max_stress=np.max(np.abs(stress))
    beta,R=form_25bar(A_grp)
    feasible=(R>=TARGET_R-1e-6) and (max_stress<=SIG_LIM)
    return weight,R,feasible,max_stress

def penalty_fitness(A_grp):
    A_snapped=snap_discrete(A_grp)
    W,R,feas,sig=evaluate(A_snapped)
    if R<TARGET_R: return W+1e4+1e6*(TARGET_R-R)**2
    if sig>SIG_LIM: return W+1e4+1e-1*(sig-SIG_LIM)
    return W

A_SORA=np.array([0.1,2.0,3.4,0.1,0.1,1.2,1.9,3.4])
def init_design(mode,rng):
    if mode=="warm":
        cands=[np.array([0.1,1.0,3.4,0.1,0.5,1.5,1.5,3.4]),
               np.array([0.1,0.3,3.4,0.1,2.0,2.0,1.8,3.4]),
               snap_discrete(A_SORA+rng.uniform(-0.3,0.3,N_GRP))]
        fc=[]
        for c in cands:
            cs=snap_discrete(c); w,r,feas,_=evaluate(cs); fc.append((cs,w if feas else np.inf+w))
        return min(fc,key=lambda x:x[1])[0]
    return snap_discrete(rng.uniform(A_MIN,A_MAX,N_GRP))

def coord_descent_discrete(A_init,W_init,R_init,max_passes=20):
    A=snap_discrete(A_init.copy()); W,R=W_init,R_init; improved=True
    for _ in range(max_passes):
        if not improved: break
        improved=False
        for i in range(N_GRP):
            idx_cur=np.argmin(np.abs(DISC_VALS-A[i]))
            if idx_cur==0: continue
            A_try=A.copy(); A_try[i]=DISC_VALS[idx_cur-1]
            W_t,R_t,feas,_=evaluate(A_try)
            if feas and W_t<W: A,W,R=A_try,W_t,R_t; improved=True
    return A,W,R

# ================================================================
# KRIGING / EGO
# ================================================================
def latin_hypercube(n, dim, rng, center=None, spread=None):
    """LHS in [A_MIN,A_MAX]^dim, optionally centered near a warm design."""
    cut = np.linspace(0,1,n+1)
    u = rng.uniform(size=(n,dim))
    pts = cut[:n,None] + u*(cut[1:,None]-cut[:n,None])
    for j in range(dim):
        rng.shuffle(pts[:,j])
    X = A_MIN + pts*(A_MAX-A_MIN)
    if center is not None and spread is not None:
        X = np.clip(center + (X-(A_MIN+A_MAX)/2.0)*spread, A_MIN, A_MAX)
    return X

def expected_improvement(mu, sigma, f_best):
    sigma = np.maximum(sigma, 1e-9)
    z = (f_best - mu)/sigma
    return (f_best - mu)*norm.cdf(z) + sigma*norm.pdf(z)

def run_kriging_ego(seed, init_mode, total_budget):
    rng = np.random.RandomState(seed)
    n_init = max(2*N_GRP, total_budget//4)   # initial DoE
    n_infill = total_budget - n_init

    # cache of (design tuple -> (W,R,feas)) so we never pay for the
    # same true evaluation twice, and the final selection is free
    cache = {}
    def true_eval(A):
        key = tuple(np.round(A, 6))
        if key not in cache:
            W, R, feas, sig = evaluate(A)
            cache[key] = (W, R, feas)
        return cache[key]

    def pen_from_cache(A):
        W, R, feas = true_eval(A)
        if not feas:
            # reconstruct penalty consistent with penalty_fitness
            _, _, _, sig = evaluate(A)  # only when infeasible, to get stress
            if R < TARGET_R: return W + 1e4 + 1e6*(TARGET_R-R)**2
            return W + 1e4 + 1e-1*max(0.0, sig-SIG_LIM)
        return W

    if init_mode == "warm":
        center = init_design("warm", rng)
        X = latin_hypercube(n_init, N_GRP, rng, center=center, spread=0.5)
    else:
        X = latin_hypercube(n_init, N_GRP, rng)
    X = np.array([snap_discrete(x) for x in X])
    y = np.array([pen_from_cache(x) for x in X])

    kernel = ConstantKernel(1.0) * Matern(length_scale=[1.0]*N_GRP, nu=2.5) \
             + WhiteKernel(noise_level=1e-3)

    for _ in range(n_infill):
        try:
            gp = GaussianProcessRegressor(kernel=kernel, normalize_y=True,
                                          n_restarts_optimizer=1, random_state=seed)
            gp.fit(X, y)
        except Exception:
            break
        cand = rng.uniform(A_MIN, A_MAX, (300, N_GRP))
        cand = np.array([snap_discrete(c) for c in cand])
        mu, sigma = gp.predict(cand, return_std=True)
        ei = expected_improvement(mu, sigma, y.min())
        x_next = cand[np.argmax(ei)]
        y_next = pen_from_cache(x_next)
        X = np.vstack([X, x_next]); y = np.append(y, y_next)

    # best feasible found — read straight from the cache, no re-evaluation
    best_W = np.inf; best_A = None; best_R = 0.0
    for i in range(len(X)):
        W, R, feas = true_eval(X[i])
        if feas and W < best_W:
            best_W, best_A, best_R = W, X[i].copy(), R
    if best_A is None:
        return None, None, 0.0, False
    return best_A, best_W, best_R, True

# ================================================================
# ONE RUN
# ================================================================
def run_one(init_mode, budget, seed):
    global CNT
    CNT = Counters()
    t0 = time.time()
    total = NATIVE_TOTAL if budget=="native" else MATCHED_TOTAL
    A_best, W, R, feas = run_kriging_ego(seed, init_mode, total)
    eval_search = CNT.total("eval_calls")

    CNT.set_phase("cd")
    W_cd, R_cd = W, R
    if feas and A_best is not None:
        A_cd, W_cd2, R_cd2 = coord_descent_discrete(A_best, W, R)
        if W_cd2 < W and R_cd2 >= TARGET_R:
            W_cd, R_cd = W_cd2, R_cd2

    elapsed = time.time()-t0
    return {
        "method": "Kriging-EGO", "init": init_mode, "budget": budget, "seed": seed,
        "W_search": W if feas else None,
        "W_final": W_cd if feas else None,
        "R_final": R_cd if feas else 0.0, "feasible": bool(feas),
        "CD_delta": (W - W_cd) if feas else 0.0,
        "eval_search": eval_search, "eval_total": CNT.total("eval_calls"),
        "fem_total": CNT.total("fem_solves"), "time_s": round(elapsed,2),
    }

# ================================================================
# DRIVER
# ================================================================
def append_csv(fname, rows, fieldnames):
    new = not os.path.exists(fname)
    with open(fname, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

INITS   = ["warm", "random"]
BUDGETS = ["native", "matched"]

def rebuild_excel():
    if not os.path.exists(OUT_CSV): print("No data yet."); return
    rows = list(csv.DictReader(open(OUT_CSV)))
    if not rows: return
    from collections import defaultdict
    groups = defaultdict(list)
    for r in rows: groups[(r["init"],r["budget"])].append(r)
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="Summary"
    ws.append(["method","init","budget","n","feasible_rate","W_final_mean","W_final_std","W_final_min","CD_delta_mean","eval_total_mean"])
    for (init,budget), rs in groups.items():
        wf=np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd=np.array([float(r["CD_delta"]) for r in rs]); ev=np.array([float(r["eval_total"]) for r in rs])
        feas=np.mean([r["feasible"]=="True" for r in rs])
        ws.append(["Kriging-EGO",init,budget,len(rs),feas,
                   float(wf.mean()) if len(wf) else None,
                   float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,
                   float(cdd.mean()), float(ev.mean())])
    ws.append([]); ws.append(["timestamp", datetime.datetime.now().isoformat()])
    ws.append(["note","native=5 seeds (500 evals); matched=20 seeds (200 evals)"])
    ws2=wb.create_sheet("PerRun"); keys2=list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])
    wb.save(OUT_XLSX)
    print(f"✓ Saved: {OUT_XLSX}  ({len(rows)} total runs)")

def download_final():
    try:
        from google.colab import files as _c; _c.download(OUT_XLSX); print(f"⬇ Downloaded: {OUT_XLSX}")
    except Exception: pass

def main():
    combos = [(i,b) for i in INITS for b in BUDGETS]
    if len(sys.argv) > 1:
        want = set(sys.argv[1:])
        combos = [c for c in combos if f"{c[0]}_{c[1]}" in want]
    done = {}
    if os.path.exists(OUT_CSV):
        for r in csv.DictReader(open(OUT_CSV)):
            done.setdefault((r["init"],r["budget"]), set()).add(int(r["seed"]))
    print(f"Running {len(combos)} combos")
    for (init, budget) in combos:
        seeds_here = SEEDS_NATIVE if budget=="native" else SEEDS
        already = done.get((init,budget), set())
        remaining = [s for s in seeds_here if s not in already]
        if not remaining:
            print(f"\n=== {init}_{budget}: all done, skipping ==="); continue
        print(f"\n=== {init}_{budget} ({len(remaining)}/{len(seeds_here)} remaining) ===")
        fieldnames = None
        for s in remaining:
            r = run_one(init, budget, s)
            if fieldnames is None: fieldnames = list(r.keys())
            append_csv(OUT_CSV, [r], fieldnames)
            print(f"  seed {s:2d}: W_final={r['W_final']}  R={r['R_final']:.4f}  "
                  f"feas={r['feasible']}  eval={r['eval_total']}  t={r['time_s']}s", flush=True)
            rebuild_excel()
    rebuild_excel()
    download_final()

if __name__ == "__main__":
    main()
