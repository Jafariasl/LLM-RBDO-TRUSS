# ============================================================
#  PHASE 6 — PROMPT WORDING SENSITIVITY — 25-bar space truss
#  Mirrors the 10-bar Phase 6 methodology. Four prompt wordings
#  carry IDENTICAL technical content (same member-group roles,
#  same three worked examples with identical numerical values),
#  differing only in wording, sentence structure, and formality:
#    P0 = original few-shot (same as Phase 1/5 fewshot prompt)
#    P1 = terse, short bulleted statements
#    P2 = verbose, full formal engineering prose
#    P3 = reordered, worked examples before structural description
#
#  All four run over the same 20 random-start seeds with DeepSeek.
# ============================================================

import numpy as np
from scipy.stats import norm
import requests, time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

DEEPSEEK_API_KEY = "YOUR_DEEPSEEK_API_KEY_HERE"
DEEPSEEK_URL     = "https://api.deepseek.com/chat/completions"

N_SEEDS = 20
SEEDS   = list(range(1, N_SEEDS+1))

# ================================================================
# PROBLEM CONSTANTS  (identical to all prior 25-bar phases)
# ================================================================
E_MEAN=1e7; RHO=0.1; SIG_LIM=40e3; DISP_LIM=0.35
P1x_M=1.0e3; P1y_M=10.0e3; P1z_M=10.0e3; P2y_M=10.0e3; P2z_M=10.0e3; P3x_M=0.5e3; P6x_M=0.6e3
TARGET_R=0.99; COV=0.05
DISC_VALS=np.array([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,
                    1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0,
                    2.1,2.2,2.3,2.4,2.5,2.6,2.8,3.0,3.2,3.4])
A_MIN,A_MAX,N_GRP=DISC_VALS[0],DISC_VALS[-1],8
MAX_ITER_LLM=150; STAGNATION_LIMIT=5

OUT_CSV="phase6_perrun_25bar.csv"; OUT_XLSX="phase6_25bar_promptsensitivity.xlsx"

# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS=["fem_solves","ls_evals","form_calls","hlrf_iters","eval_calls","llm_calls"]
    def __init__(self): self.phase="init"; self.data={}
    def _d(self):
        if self.phase not in self.data: self.data[self.phase]={f:0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self,f,n=1): self._d()[f]+=n
    def set_phase(self,p): self.phase=p; self._d()
    def total(self,f): return sum(d[f] for d in self.data.values())
CNT=Counters()

# ================================================================
# GEOMETRY + precomputed matrices (from Phase 3, validated)
# ================================================================
NODES=np.array([[-37.5,0.0,200.0],[37.5,0.0,200.0],[-37.5,37.5,100.0],[37.5,37.5,100.0],
    [37.5,-37.5,100.0],[-37.5,-37.5,100.0],[-100.0,100.0,0.0],[100.0,100.0,0.0],
    [100.0,-100.0,0.0],[-100.0,-100.0,0.0]],dtype=float)
ELEM_N1=np.array([0,0,1,0,1,1,1,0,0,5,3,2,5,2,5,3,4,3,2,4,5,5,2,3,4])
ELEM_N2=np.array([1,3,2,4,5,3,4,2,5,2,4,3,4,9,6,8,7,6,7,9,8,9,6,7,8])
IDA=np.array([0,1,1,1,1,2,2,2,2,3,3,4,4,5,5,5,5,6,6,6,6,7,7,7,7])
N_EL,N_SDOF=25,30; FIXED_DOFS=list(range(18,30))
EL_LE=np.array([np.linalg.norm(NODES[ELEM_N2[i]]-NODES[ELEM_N1[i]]) for i in range(N_EL)])
EL_DIR=np.array([(NODES[ELEM_N2[i]]-NODES[ELEM_N1[i]])/EL_LE[i] for i in range(N_EL)])
_KE,_DOFS,_SROW=[],[],[]
for _i in range(N_EL):
    _lx,_ly,_lz=EL_DIR[_i]; _le=EL_LE[_i]
    _Te=np.array([[_lx,_ly,_lz,0,0,0],[0,0,0,_lx,_ly,_lz]])
    _KE.append(_Te.T@np.array([[1.,-1.],[-1.,1.]])@_Te)
    _n1,_n2=ELEM_N1[_i],ELEM_N2[_i]; _DOFS.append([3*_n1,3*_n1+1,3*_n1+2,3*_n2,3*_n2+1,3*_n2+2])
    _SROW.append(np.array([-1/_le,1/_le])@_Te)
_KE=np.array(_KE); _DOFS=np.array(_DOFS); _SROW=np.array(_SROW)

def snap_discrete(A): return np.array([DISC_VALS[np.argmin(np.abs(DISC_VALS-a))] for a in np.asarray(A,dtype=float)])

def fem_25bar(A_grp,E_v=E_MEAN,p1x=P1x_M,p1y=P1y_M,p1z=P1z_M,p2y=P2y_M,p2z=P2z_M,p3x=P3x_M,p6x=P6x_M):
    CNT.inc("fem_solves")
    A_grp=np.asarray(A_grp,dtype=float).ravel(); A_el=A_grp[IDA]
    K=np.zeros((N_SDOF,N_SDOF)); scale=E_v*A_el/EL_LE
    for i in range(N_EL):
        idx=_DOFS[i]; K[np.ix_(idx,idx)]+=scale[i]*_KE[i]
    wt=RHO*np.sum(EL_LE*A_el)
    F=np.zeros(N_SDOF); F[0]+=p1x;F[1]-=p1y;F[2]-=p1z;F[4]-=p2y;F[5]-=p2z;F[6]+=p3x;F[15]+=p6x
    Kb,Fb=K.copy(),F.copy()
    for d in FIXED_DOFS: Kb[d,:]=0;Kb[:,d]=0;Kb[d,d]=1;Fb[d]=0
    try: U=np.linalg.solve(Kb,Fb)
    except np.linalg.LinAlgError: return np.zeros(N_SDOF),np.zeros(N_EL),np.inf
    stress=np.array([E_v*(_SROW[i]@U[_DOFS[i]]) for i in range(N_EL)])
    return U,stress,wt

def form_25bar(A_grp):
    CNT.inc("form_calls")
    A_grp=np.asarray(A_grp,dtype=float).ravel()
    mu_X=np.array([E_MEAN,P1x_M,P1y_M,P1z_M,P2y_M,P2z_M,P3x_M,P6x_M,*A_grp]); sig_X=COV*mu_X; N_RV=16
    def g(X):
        CNT.inc("ls_evals")
        E_v,p1x,p1y,p1z,p2y,p2z,p3x,p6x=X[:8]
        try:
            U,_,_=fem_25bar(X[8:16],E_v,p1x,p1y,p1z,p2y,p2z,p3x,p6x)
            return DISP_LIM-np.max(np.abs(U[:4]))
        except Exception: return -1.0
    g_mean=g(mu_X); u,b_prev,h=np.zeros(N_RV),0.0,1e-4
    for _ in range(30):
        CNT.inc("hlrf_iters")
        X=mu_X+sig_X*u; g0=g(X)
        dg=np.array([(g(mu_X+sig_X*(u+h*np.eye(N_RV)[j]))-g0)/h for j in range(N_RV)])
        nd=np.linalg.norm(dg)
        if nd<1e-12: break
        alpha=dg/nd; beta_k=-alpha@u+g0/nd; u_new=-alpha*beta_k
        if np.linalg.norm(u_new-u)<1e-4: u=u_new; break
        u=u_new; b_now=np.linalg.norm(u)
        if abs(b_now-b_prev)<1e-4: break
        b_prev=b_now
    beta=np.linalg.norm(u)
    if g_mean<0: beta=-beta
    return float(beta),float(norm.cdf(beta))

def evaluate(A_grp):
    CNT.inc("eval_calls")
    A_grp=np.clip(np.asarray(A_grp,dtype=float).ravel(),A_MIN,A_MAX)
    U,stress,weight=fem_25bar(A_grp); max_stress=np.max(np.abs(stress))
    beta,R=form_25bar(A_grp)
    feasible=(R>=TARGET_R-1e-6) and (max_stress<=SIG_LIM)
    return weight,R,feasible,np.max(np.abs(U[:4])),max_stress

def init_design_random(rng): return snap_discrete(rng.uniform(A_MIN,A_MAX,N_GRP))

def coord_descent_discrete(A_init,W_init,R_init,max_passes=20):
    A=snap_discrete(A_init.copy()); W,R=W_init,R_init; improved=True
    for _ in range(max_passes):
        if not improved: break
        improved=False
        for i in range(N_GRP):
            idx_cur=np.argmin(np.abs(DISC_VALS-A[i]))
            if idx_cur==0: continue
            A_try=A.copy(); A_try[i]=DISC_VALS[idx_cur-1]
            W_t,R_t,feas,_,_=evaluate(A_try)
            if feas and W_t<W: A,W,R=A_try,W_t,R_t; improved=True
    return A,W,R

# ================================================================
# FOUR PROMPT WORDINGS — IDENTICAL technical content
# ================================================================

# ---- P0: original few-shot (same as Phase 1/5 fewshot) ----
P0_TMPL = """You are an expert in structural reliability-based design optimization.

PROBLEM: 25-bar 3D space truss RBDO
  Goal: minimize weight (lb) with Reliability >= {tr} and stress <= {siglim:.0f} psi
  Design: A[1]..A[8] (8 cross-section groups), discrete in [{amin}..{amax}] in^2
  Random variables (16, COV=5%): E, P1x, P1y, P1z, P2y, P2z, P3x, P6x, A1..A8

STRUCTURAL KNOWLEDGE (critical for reliability):
  - Group 3 (A[3]): 4 vertical inner elements, L~107 in -> primary stiffness -> KEEP HIGH (>=3.0)
  - Group 8 (A[8]): 4 short base diagonals, L~133 in -> secondary stiffness -> KEEP HIGH (>=2.5)
  - Group 6 (A[6]): 4 long space diagonals, L~181 in -> tune carefully
  - Group 7 (A[7]): 4 long space diagonals, L~181 in -> tune carefully
  - Group 2 (A[2]): 4 outer diagonals, L~130 in -> can trade with A[6,7]
  - Groups 1,4 (A[1],A[4]): short elements -> often near A_MIN={amin} (light, low influence)

WORKED EXAMPLES (illustrating good update behaviour from DIFFERENT starting
configurations -- use these to learn the PATTERN of good moves, not a fixed
target design; the correct final design depends on where you currently are):

Example A -- far from feasible, stiffness groups too thin:
  state: A=[0.1,0.3,1.0,0.1,2.0,0.3,0.3,1.0]  R=0.30 (infeasible, need >= {tr})
  good update: raise A[3] and A[8] toward their upper range (they carry
    primary/secondary stiffness); nudge A[6],A[7] up moderately; leave
    A[1],A[4] near A_MIN since they contribute little.
  result: R rose to roughly 0.75 -- still infeasible but much closer.

Example B -- feasible but overweight, some groups oversized:
  state: A=[0.1,2.0,3.4,0.1,2.0,2.5,2.0,3.4]  R=0.991  weight=701 lb
  good update: reduce A[5] and A[2] toward lower discrete steps since they
    are not on the primary load path; keep A[3]>=3.0 and A[8]>=2.5 intact;
    trade A[6]/A[7] down by one discrete step at a time if R stays >= {tr}.
  result: weight dropped toward the 650-670 lb range, R stayed above {tr}.

Example C -- feasible and near-optimal, fine-tuning phase:
  state: A=[0.1,1.0,3.4,0.1,0.5,1.5,1.5,3.4]  R=0.995  weight=645 lb
  good update: step down ONE group by the smallest discrete increment
    (0.1), re-check reliability; if it drops below {tr} revert that group
    and try a different one. Never reduce A[3] below 3.0 or A[8] below 2.5.
  result: small, safe weight reductions of a few percent per iteration.

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  max_disp    = {disp:.4f} in  (limit={displim}, violation={gapd:.4f})
  max_stress  = {sig:.1f} psi  (limit={siglim:.0f}, violation={gaps:.1f})
  {areas}

RECENT HISTORY
{hist}

TASK: Using the PATTERN from the worked examples above (not their specific
numbers -- your current state is different from all three), write an
adaptive UPDATE RULE applied ~{stag} times that moves the CURRENT design
toward lower weight while keeping reliability >= {tr} and stress <= {siglim:.0f} psi.

Return ONLY the function below (no markdown fences, no explanation):

def update_operator(A, reliability, weight, disp, stress):
    import numpy as np
    A_new = A.copy()
    # your deterministic strategy here
    return np.clip(A_new, {amin}, {amax})
"""

# ---- P1: terse ----
P1_TMPL = """RBDO task. 25-bar 3D space truss. Minimize weight (lb).
Constraints: Reliability R >= {tr}, stress <= {siglim:.0f} psi.
Design: A[1..8], 8 groups, discrete [{amin},{amax}] in^2.
Random vars (16, COV 5%): E, P1x,P1y,P1z,P2y,P2z,P3x,P6x, A1..A8.

Group roles:
  A[3] = vertical inner, L~107. Primary stiffness. KEEP >=3.0.
  A[8] = short base diagonals, L~133. Secondary stiffness. KEEP >=2.5.
  A[6],A[7] = long space diagonals, L~181. Tune.
  A[2] = outer diagonals, L~130. Trade with A[6,7].
  A[1],A[4] = short. Near {amin}.

3 examples, DIFFERENT start points (learn pattern, not numbers):

EX1: A=[0.1,0.3,1.0,0.1,2.0,0.3,0.3,1.0], R=0.30 (infeasible).
  Fix: push A[3],A[8] up; bump A[6],A[7]; leave A[1],A[4] near {amin}.
  Out: R->0.75.

EX2: A=[0.1,2.0,3.4,0.1,2.0,2.5,2.0,3.4], R=0.991, W=701.
  Fix: cut A[5],A[2] down; hold A[3]>=3.0, A[8]>=2.5; trim A[6],A[7]
  one step if R>={tr}.
  Out: W->650-670, feasible.

EX3: A=[0.1,1.0,3.4,0.1,0.5,1.5,1.5,3.4], R=0.995, W=645.
  Fix: drop ONE group by 0.1; recheck R; revert if R<{tr}. Never
  A[3]<3.0 or A[8]<2.5.
  Out: small safe cuts.

Now, iteration {it}:
  W={W:.2f} lb, R={R:.4f} (target {tr}), disp={disp:.4f} (lim {displim}),
  stress={sig:.1f} (lim {siglim:.0f})
  {areas}

History (last 6):
{hist}

Write update rule (applied ~{stag}x) generalizing the 3 examples' PATTERN
to THIS state. Don't copy example numbers.

Output ONLY:
def update_operator(A, reliability, weight, disp, stress):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

# ---- P2: verbose formal ----
P2_TMPL = """You are acting as a senior structural engineer carrying out a
reliability-based design optimization study of a classical 25-bar
three-dimensional space truss benchmark. The objective of this study is to
minimize the total structural weight of the truss, expressed in pounds,
while ensuring that the computed reliability with respect to the nodal
displacement limit state remains at or above {tr}, and that the maximum
member stress does not exceed {siglim:.0f} pounds per square inch. The
design is parameterized by eight cross-sectional area groups, denoted A[1]
through A[8], each of which may take discrete values within the interval
from {amin} to {amax} square inches. A total of sixteen random variables
are considered, each with a coefficient of variation of five percent,
comprising the modulus of elasticity, seven applied load components, and
the eight group areas.

On the basis of prior structural analysis of this truss topology, certain
member groups are understood to govern the structural response and should
be treated with particular care. The third group, A[3], corresponds to the
four vertical inner elements of approximate length one hundred and seven
inches and provides the primary stiffness of the structure, and should
therefore be kept at or above three point zero. The eighth group, A[8],
corresponds to the four short base diagonals of approximate length one
hundred and thirty three inches, provides secondary stiffness, and should
be kept at or above two point five. The sixth and seventh groups, A[6] and
A[7], are the long space diagonals of approximate length one hundred and
eighty one inches and should be tuned with care. The second group, A[2],
comprises the outer diagonals of approximate length one hundred and thirty
inches and may be traded against A[6] and A[7]. The first and fourth
groups, A[1] and A[4], are short elements of low influence and may
generally be kept close to their lower bound of {amin}.

To illustrate the reasoning expected, three worked examples are provided
below. These originate from three different starting configurations and are
intended to demonstrate the pattern of sound engineering judgment rather
than to provide a fixed target design, since the current state will
generally differ from all three. In the first case, the truss begins in a
substantially under-designed and infeasible state, A=[0.1,0.3,1.0,0.1,2.0,
0.3,0.3,1.0] with a reliability of only 0.30, and the appropriate response
is to raise the stiffness-governing groups A[3] and A[8] toward their upper
range, to increase A[6] and A[7] moderately, and to leave A[1] and A[4]
near their lower bound, following which the reliability improved to
approximately 0.75. In the second case, the design is feasible but
overweight, A=[0.1,2.0,3.4,0.1,2.0,2.5,2.0,3.4] with a reliability of 0.991
and a weight of seven hundred and one pounds, and the appropriate response
is to reduce the non-critical groups A[5] and A[2] toward lower discrete
steps while holding A[3] at or above three point zero and A[8] at or above
two point five, trimming A[6] and A[7] by a single discrete step at a time
provided the reliability remains at or above {tr}, following which the
weight fell into the range of six hundred and fifty to six hundred and
seventy pounds while remaining feasible. In the third case, the design is
feasible and close to optimal, A=[0.1,1.0,3.4,0.1,0.5,1.5,1.5,3.4] with a
reliability of 0.995 and a weight of six hundred and forty five pounds, and
the appropriate response is to reduce a single group by the smallest
discrete increment of zero point one, to re-check the reliability, and to
revert that reduction if the reliability falls below {tr}, never reducing
A[3] below three point zero or A[8] below two point five, following which
small and safe weight reductions of a few percent per iteration were
obtained.

The optimization has now reached iteration {it}. The present state of the
design is a weight of {W:.2f} pounds, a reliability of {R:.4f} against the
required minimum of {tr}, a maximum nodal displacement of {disp:.4f} inches
against a limit of {displim} inches, and a maximum member stress of
{sig:.1f} pounds per square inch against a limit of {siglim:.0f}. The
current group areas are as follows: {areas}. For additional context, the
following record lists the most recent iterations of the present run:
{hist}

Drawing on the pattern illustrated by the three cases above, adapted
appropriately to the current state which differs from all three, please
write an adaptive update rule, intended to be applied approximately {stag}
times in succession, that reduces the structural weight while maintaining
the required reliability and stress constraints. Please return only the
following Python function, with no additional commentary or formatting:

def update_operator(A, reliability, weight, disp, stress):
    import numpy as np
    A_new = A.copy()
    # your deterministic strategy here
    return np.clip(A_new, {amin}, {amax})
"""

# ---- P3: reordered (examples first, then structural description) ----
P3_TMPL = """Here are three examples of good design updates for a 25-bar 3D
space truss RBDO problem, each starting from a different design:

1) Starting point A=[0.1,0.3,1.0,0.1,2.0,0.3,0.3,1.0] gave R=0.30 (below
   the required {tr}). The move that worked: raise A[3] and A[8] toward
   their upper range since they carry the primary and secondary stiffness,
   bump A[6] and A[7] up moderately, and leave A[1] and A[4] near {amin}.
   This brought R up to about 0.75.

2) Starting point A=[0.1,2.0,3.4,0.1,2.0,2.5,2.0,3.4] was feasible
   (R=0.991) but heavy (W=701 lb). The move that worked: cut A[5] and A[2]
   toward lower discrete steps, hold A[3]>=3.0 and A[8]>=2.5, and trim A[6]
   and A[7] one discrete step at a time while R stayed >= {tr}. Result:
   W fell to 650-670 lb, still feasible.

3) Starting point A=[0.1,1.0,3.4,0.1,0.5,1.5,1.5,3.4] was feasible and
   near-optimal (R=0.995, W=645 lb). The move that worked: drop one group
   by the smallest step 0.1, recheck R, undo if R<{tr}, and never reduce
   A[3] below 3.0 or A[8] below 2.5. Small careful weight cuts.

These cover different regimes, so don't copy their numbers, your situation
differs, but the PATTERN (what to touch, by how much, why) carries over.

Background on this truss: 8 area groups A[1]..A[8], discrete in
[{amin},{amax}] in^2, 16 random variables (COV 5%): E, seven load
components, and the 8 areas. Group roles: A[3] are 4 vertical inner
elements (L~107) giving primary stiffness, keep >=3.0; A[8] are 4 short
base diagonals (L~133) giving secondary stiffness, keep >=2.5; A[6],A[7]
are long space diagonals (L~181) to tune; A[2] are outer diagonals (L~130)
tradeable with A[6,7]; A[1],A[4] are short low-influence elements, keep
near {amin}. Goal: minimize weight with R >= {tr} and stress <= {siglim:.0f} psi.

Your current situation, at iteration {it}:
  weight = {W:.2f} lb, reliability = {R:.4f} (must stay >= {tr}),
  displacement = {disp:.4f} in (limit {displim}),
  stress = {sig:.1f} psi (limit {siglim:.0f})
  {areas}

Recent iterations:
{hist}

Please write an update rule (applied roughly {stag} times) that applies the
same reasoning as the three examples to THIS state, cutting weight while
keeping reliability above {tr} and stress within the limit.

Return just the function, nothing else, no markdown:

def update_operator(A, reliability, weight, disp, stress):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

PROMPTS={"P0":P0_TMPL,"P1":P1_TMPL,"P2":P2_TMPL,"P3":P3_TMPL}

def build_prompt(variant,A,R,W,disp,sig,it,history):
    hist="\n".join(f"  iter={h['iter']:3d}  W={h['W']:8.1f}  R={h['R']:.4f}  feasible={h['feasible']}" for h in history[-6:])
    areas=", ".join(f"A[{i+1}]={v:.2f}" for i,v in enumerate(A))
    gapd=max(0.0,disp-DISP_LIM); gaps=max(0.0,sig-SIG_LIM)
    return PROMPTS[variant].format(tr=TARGET_R,amin=A_MIN,amax=A_MAX,siglim=SIG_LIM,
        displim=DISP_LIM,it=it,W=W,R=R,disp=disp,sig=sig,gapd=gapd,gaps=gaps,areas=areas,hist=hist,stag=STAGNATION_LIMIT)

def extract_code(text):
    lines,inside=[],False
    for line in text.splitlines():
        clean=line.replace("```python","").replace("```","")
        if clean.strip().startswith("def update_operator"): inside=True
        if inside: lines.append(clean)
    return "\n".join(lines) if lines else None

# ================================================================
# DEEPSEEK  (retry/backoff)
# ================================================================
def _post_with_retry(url,headers,json_body,timeout=45,max_retries=4):
    last=None
    for attempt in range(max_retries):
        try:
            r=requests.post(url,headers=headers,json=json_body,timeout=timeout)
            if r.status_code>=500: raise requests.exceptions.HTTPError(f"{r.status_code} Server Error",response=r)
            r.raise_for_status(); return r
        except Exception as e:
            last=e
            if attempt<max_retries-1:
                w=(2**attempt)+np.random.uniform(0,1); print(f"    retry {w:.1f}s ({e})"); time.sleep(w)
    raise last

def call_deepseek(prompt,fail_counter=None):
    CNT.inc("llm_calls")
    try:
        r=_post_with_retry(DEEPSEEK_URL,
            headers={"Authorization":f"Bearer {DEEPSEEK_API_KEY}","Content-Type":"application/json"},
            json_body={"model":"deepseek-chat","messages":[{"role":"user","content":prompt}],"temperature":0.7,"max_tokens":700})
        code=extract_code(r.json()["choices"][0]["message"]["content"])
        if code is None and fail_counter is not None: fail_counter[0]+=1
        return code
    except Exception as e:
        print(f"    ⚠ deepseek error after retries: {e}")
        if fail_counter is not None: fail_counter[0]+=1
        return None

def apply_operator(code,A,R,W,disp,sig):
    if code is None:
        f=1.05 if R<TARGET_R else 0.97
        return snap_discrete(np.clip(A*f,A_MIN,A_MAX))
    try:
        ns={"np":np,"numpy":np,"N_GRP":N_GRP,"A_MIN":A_MIN,"A_MAX":A_MAX,"DISC_VALS":DISC_VALS}
        exec(code,ns)
        raw=ns["update_operator"](A.copy(),float(R),float(W),float(disp),float(sig))
        A_new=np.atleast_1d(np.asarray(raw,dtype=float)).flatten()
        if A_new.shape[0]!=N_GRP: raise ValueError("shape")
        return snap_discrete(np.clip(A_new,A_MIN,A_MAX))
    except Exception:
        f=1.05 if R<TARGET_R else 0.97
        return snap_discrete(np.clip(A*f,A_MIN,A_MAX))

# ================================================================
# ONE RUN  (random start only)
# ================================================================
def run_one(variant,seed):
    global CNT
    CNT=Counters(); t0=time.time(); rng=np.random.RandomState(seed)
    CNT.set_phase("init")
    A=init_design_random(rng)
    W,R,feasible,disp,sig=evaluate(A)
    best_A=A.copy(); best_W=W if feasible else np.inf; best_R=R
    history=[{"iter":0,"W":W,"R":R,"disp":disp,"sig":sig,"feasible":feasible}]
    stag=0; fail_counter=[0]
    CNT.set_phase("llm_loop")
    op=call_deepseek(build_prompt(variant,A,R,W,disp,sig,0,history),fail_counter)
    for it in range(1,MAX_ITER_LLM+1):
        try:
            A_new=apply_operator(op,A,R,W,disp,sig)
            W_n,R_n,feas_n,disp_n,sig_n=evaluate(A_new)
        except Exception:
            A_new,W_n,R_n,feas_n,disp_n,sig_n=A.copy(),W,R,feasible,disp,sig
        accept=((not feasible and R_n>R) or (feasible and feas_n and W_n<W))
        if accept:
            A,W,R,disp,sig,feasible=A_new,W_n,R_n,disp_n,sig_n,feas_n
            if feas_n and W_n<best_W: best_A,best_W,best_R=A_new.copy(),W_n,R_n
        history.append({"iter":it,"W":W,"R":R,"disp":disp,"sig":sig,"feasible":feasible})
        stag=0 if accept else stag+1
        if stag>=STAGNATION_LIMIT:
            op=call_deepseek(build_prompt(variant,A,R,W,disp,sig,it,history),fail_counter); stag=0
    W_loop,R_loop=best_W,best_R; eval_loop=CNT.total("eval_calls")
    CNT.set_phase("cd")
    W_cd,R_cd=W_loop,R_loop
    if best_W<np.inf:
        A_cd,W_cd2,R_cd2=coord_descent_discrete(best_A,best_W,best_R)
        if W_cd2<best_W and R_cd2>=TARGET_R: W_cd,R_cd=W_cd2,R_cd2
    elapsed=time.time()-t0
    feasible_final=bool(R_cd>=TARGET_R-1e-6 and W_cd<np.inf)
    row={"prompt_variant":variant,"seed":seed,
        "W_loop_end":W_loop if W_loop<np.inf else None,
        "W_final":W_cd if feasible_final else None,"R_final":R_cd,"feasible":feasible_final,
        "CD_delta":(W_loop-W_cd) if (W_loop<np.inf) else 0.0,
        "eval_loop":eval_loop,"eval_total":CNT.total("eval_calls"),
        "llm_calls":CNT.total("llm_calls"),"llm_fallback_count":fail_counter[0],"time_s":round(elapsed,2)}
    for i in range(N_GRP): row[f"A{i+1}"]=float(best_A[i]) if best_W<np.inf else None
    return row

# ================================================================
# DRIVER
# ================================================================
def append_csv(fname,rows,fieldnames):
    new=not os.path.exists(fname)
    with open(fname,"a",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

VARIANTS=["P0","P1","P2","P3"]

def rebuild_excel():
    if not os.path.exists(OUT_CSV): print("No data yet."); return
    rows=list(csv.DictReader(open(OUT_CSV)))
    if not rows: return
    from collections import defaultdict
    groups=defaultdict(list)
    for r in rows: groups[r["prompt_variant"]].append(r)
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="Summary"
    ws.append(["prompt_variant","n","feasible_rate","W_final_mean","W_final_std","W_final_min","eval_total_mean","llm_calls_mean"])
    for v,rs in groups.items():
        wf=np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        ev=np.array([float(r["eval_total"]) for r in rs]); lc=np.array([float(r["llm_calls"]) for r in rs])
        feas=np.mean([r["feasible"]=="True" for r in rs])
        ws.append([v,len(rs),feas,
                   float(wf.mean()) if len(wf) else None,
                   float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,
                   float(ev.mean()),float(lc.mean())])
    ws.append([]); ws.append(["timestamp",datetime.datetime.now().isoformat()])
    ws2=wb.create_sheet("PerRun"); keys2=list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])
    wb.save(OUT_XLSX)
    print(f"✓ Saved: {OUT_XLSX}  ({len(rows)} total runs)")

def download_final():
    try:
        from google.colab import files as _c; _c.download(OUT_XLSX); print(f"⬇ Downloaded: {OUT_XLSX}")
    except Exception: pass

def main():
    variants=VARIANTS
    if len(sys.argv)>1:
        variants=[v for v in VARIANTS if v in set(sys.argv[1:])]
    done={}
    if os.path.exists(OUT_CSV):
        for r in csv.DictReader(open(OUT_CSV)):
            done.setdefault(r["prompt_variant"],set()).add(int(r["seed"]))
    print(f"Running {len(variants)} prompt variants")
    for v in variants:
        already=done.get(v,set()); remaining=[s for s in SEEDS if s not in already]
        if not remaining:
            print(f"\n=== {v}: all done, skipping ==="); continue
        print(f"\n=== {v} ({len(remaining)}/{N_SEEDS} remaining) ===")
        fieldnames=None
        for s in remaining:
            r=run_one(v,s)
            if fieldnames is None: fieldnames=list(r.keys())
            append_csv(OUT_CSV,[r],fieldnames)
            print(f"  seed {s:2d}: W_final={r['W_final']}  R={r['R_final']:.4f}  "
                  f"feas={r['feasible']}  llm={r['llm_calls']}  fb={r['llm_fallback_count']}  t={r['time_s']}s",flush=True)
            rebuild_excel()
    rebuild_excel(); download_final()

if __name__=="__main__":
    main()
