# ============================================================
#  PHASE 1 — ABLATION STUDY — 25-bar space truss
#  Mirrors the 10-bar Phase 1 methodology exactly (see
#  phase1_10bar_ablation.py), adapted for:
#    - 8 DISCRETE design groups (snap to nearest of 30 values)
#    - 16 random variables (E + 7 load components + 8 areas)
#    - an additional deterministic stress constraint
#  Answers R1-1, R1-7, R1-8, R1-9 (attribution), R2 (CD contribution).
#
#  LESSONS CARRIED OVER FROM THE 10-BAR STUDY (built in from the
#  start here, not discovered the hard way again):
#    - The stagnation-detection bug (abs(inf-inf)=nan silently
#      disabling re-prompting) is ALREADY FIXED below — uses the
#      per-iteration `accept` flag directly.
#    - Both a "full" prompt (fixed reference-design anchor, as in
#      the original script) and a "fewshot" prompt (worked
#      examples, no fixed numeric target) are included from the
#      start, since the 10-bar study found the anchor style can
#      underperform random search from an uninformed start.
#
#  Proposer variants (identical taxonomy to 10-bar):
#    fallback   : fixed heuristic rule (deterministic control)
#    random     : knowledge-free random perturbation (control)
#    none       : coordinate descent only, no search operator
#    llm_full   : DeepSeek-V3, original prompt w/ reference anchor
#    llm_fewshot: DeepSeek-V3, worked-examples prompt (no anchor)
#    llm_generic: DeepSeek-V3, no structural knowledge at all
#

# ============================================================

import numpy as np
from scipy.stats import norm
import requests, time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

# ================================================================
# API KEY
# ================================================================
API_KEY      = "YOUR_DEEPSEEK_API_KEY_HERE"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"

RUN_SET = "local"   # "local" (no API, deterministic controls) | "llm" (Colab + API key)
N_SEEDS = 20
SEEDS   = list(range(1, N_SEEDS + 1))

# ================================================================
# PROBLEM CONSTANTS  (identical to Phase 0, validated)
# ================================================================
E_MEAN   = 1e7
RHO      = 0.1
SIG_LIM  = 40e3
DISP_LIM = 0.35

P1x_M = 1.0e3;  P1y_M = 10.0e3; P1z_M = 10.0e3
P2y_M = 10.0e3; P2z_M = 10.0e3
P3x_M = 0.5e3;  P6x_M = 0.6e3

TARGET_R = 0.99
COV      = 0.05

DISC_VALS = np.array([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,
                      1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0,
                      2.1,2.2,2.3,2.4,2.5,2.6,2.8,3.0,3.2,3.4])
A_MIN, A_MAX, N_GRP = DISC_VALS[0], DISC_VALS[-1], 8

MAX_ITER_LLM     = 150
STAGNATION_LIMIT = 5
FORM_MAX_ITER    = 30
FORM_TOL         = 1e-4

# ================================================================
# COUNTERS  (identical scheme to every phase)
# ================================================================
class Counters:
    FIELDS = ["fem_solves", "ls_evals", "form_calls", "hlrf_iters", "eval_calls", "llm_calls"]
    def __init__(self):
        self.phase = "init"; self.data = {}; self.form_iter_log = []
    def _d(self):
        if self.phase not in self.data:
            self.data[self.phase] = {f: 0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self, f, n=1): self._d()[f] += n
    def set_phase(self, p): self.phase = p; self._d()
    def total(self, f): return sum(d[f] for d in self.data.values())

CNT = Counters()

# ================================================================
# GEOMETRY  (identical to Phase 0, validated against JJ's Colab run)
# ================================================================
NODES = np.array([
    [-37.5,   0.0, 200.0], [ 37.5,   0.0, 200.0],
    [-37.5,  37.5, 100.0], [ 37.5,  37.5, 100.0],
    [ 37.5, -37.5, 100.0], [-37.5, -37.5, 100.0],
    [-100.0, 100.0,  0.0], [ 100.0, 100.0,  0.0],
    [ 100.0,-100.0,  0.0], [-100.0,-100.0,  0.0],
], dtype=float)

ELEM_N1 = np.array([0,0,1,0,1, 1,1,0,0, 5,3,2,5, 2,5,3,4, 3,2,4,5, 5,2,3,4])
ELEM_N2 = np.array([1,3,2,4,5, 3,4,2,5, 2,4,3,4, 9,6,8,7, 6,7,9,8, 9,6,7,8])
IDA     = np.array([0,1,1,1,1, 2,2,2,2, 3,3,4,4, 5,5,5,5, 6,6,6,6, 7,7,7,7])

N_EL, N_SDOF = 25, 30
FIXED_DOFS = list(range(18, 30))
FREE_DOFS  = [d for d in range(N_SDOF) if d not in FIXED_DOFS]

EL_LE  = np.array([np.linalg.norm(NODES[ELEM_N2[i]]-NODES[ELEM_N1[i]]) for i in range(N_EL)])
EL_DIR = np.array([(NODES[ELEM_N2[i]]-NODES[ELEM_N1[i]])/EL_LE[i] for i in range(N_EL)])

def snap_discrete(A):
    return np.array([DISC_VALS[np.argmin(np.abs(DISC_VALS - a))] for a in np.asarray(A, dtype=float)])

# ================================================================
# FEM + FORM + EVALUATE  (identical to Phase 0, validated)
# ================================================================
def fem_25bar(A_grp, E_v=E_MEAN, p1x=P1x_M, p1y=P1y_M, p1z=P1z_M,
              p2y=P2y_M, p2z=P2z_M, p3x=P3x_M, p6x=P6x_M):
    CNT.inc("fem_solves")
    A_grp = np.asarray(A_grp, dtype=float).ravel()
    A_el  = A_grp[IDA]
    K     = np.zeros((N_SDOF, N_SDOF))
    wt    = 0.0
    for i in range(N_EL):
        n1, n2 = ELEM_N1[i], ELEM_N2[i]
        le = EL_LE[i]; lx, ly, lz = EL_DIR[i]; Ai = A_el[i]
        Te = np.array([[lx, ly, lz, 0, 0, 0], [0, 0, 0, lx, ly, lz]])
        ke = Te.T @ (Ai * E_v / le * np.array([[1,-1],[-1,1]])) @ Te
        wt += RHO * le * Ai
        idx = [3*n1, 3*n1+1, 3*n1+2, 3*n2, 3*n2+1, 3*n2+2]
        K[np.ix_(idx, idx)] += ke

    F = np.zeros(N_SDOF)
    F[0] += p1x; F[1] -= p1y; F[2] -= p1z
    F[4] -= p2y; F[5] -= p2z
    F[6] += p3x; F[15] += p6x

    Kb, Fb = K.copy(), F.copy()
    for d in FIXED_DOFS:
        Kb[d,:] = 0; Kb[:,d] = 0; Kb[d,d] = 1; Fb[d] = 0
    try:
        U = np.linalg.solve(Kb, Fb)
    except np.linalg.LinAlgError:
        return np.zeros(N_SDOF), np.zeros(N_EL), np.inf

    stress = np.zeros(N_EL)
    for i in range(N_EL):
        n1, n2 = ELEM_N1[i], ELEM_N2[i]
        le = EL_LE[i]; lx, ly, lz = EL_DIR[i]
        Te = np.array([[lx, ly, lz, 0, 0, 0], [0, 0, 0, lx, ly, lz]])
        idx = [3*n1, 3*n1+1, 3*n1+2, 3*n2, 3*n2+1, 3*n2+2]
        stress[i] = E_v * np.array([-1/le, 1/le]) @ (Te @ U[idx])

    return U, stress, wt

def form_25bar(A_grp):
    CNT.inc("form_calls")
    A_grp = np.asarray(A_grp, dtype=float).ravel()
    mu_X = np.array([E_MEAN, P1x_M, P1y_M, P1z_M, P2y_M, P2z_M, P3x_M, P6x_M, *A_grp])
    sig_X = COV * mu_X
    N_RV = 16

    def g(X):
        CNT.inc("ls_evals")
        E_v, p1x, p1y, p1z, p2y, p2z, p3x, p6x = X[:8]
        try:
            U, _, _ = fem_25bar(X[8:16], E_v, p1x, p1y, p1z, p2y, p2z, p3x, p6x)
            return DISP_LIM - np.max(np.abs(U[:4]))
        except Exception:
            return -1.0

    g_mean = g(mu_X)
    u, b_prev, h = np.zeros(N_RV), 0.0, 1e-4
    n_it = 0
    for _ in range(FORM_MAX_ITER):
        n_it += 1
        CNT.inc("hlrf_iters")
        X = mu_X + sig_X * u
        g0 = g(X)
        dg = np.array([(g(mu_X + sig_X*(u + h*np.eye(N_RV)[j])) - g0)/h for j in range(N_RV)])
        nd = np.linalg.norm(dg)
        if nd < 1e-12: break
        alpha = dg / nd
        beta_k = -alpha @ u + g0/nd
        u_new = -alpha * beta_k
        if np.linalg.norm(u_new-u) < FORM_TOL:
            u = u_new; break
        u = u_new
        b_now = np.linalg.norm(u)
        if abs(b_now-b_prev) < FORM_TOL: break
        b_prev = b_now

    CNT.form_iter_log.append(n_it)
    beta = np.linalg.norm(u)
    if g_mean < 0: beta = -beta
    return float(beta), float(norm.cdf(beta))

def evaluate(A_grp):
    CNT.inc("eval_calls")
    A_grp = np.clip(np.asarray(A_grp, dtype=float).ravel(), A_MIN, A_MAX)
    U, stress, weight = fem_25bar(A_grp)
    max_disp = np.max(np.abs(U[:4]))
    max_stress = np.max(np.abs(stress))
    beta, R = form_25bar(A_grp)
    feasible = (R >= TARGET_R - 1e-6) and (max_stress <= SIG_LIM)
    return weight, R, feasible, max_disp, max_stress

A_SORA = np.array([0.1, 2.0, 3.4, 0.1, 0.1, 1.2, 1.9, 3.4])

def init_design(mode, rng):
    if mode == "warm":
        candidates = [
            np.array([0.1, 1.0, 3.4, 0.1, 0.5, 1.5, 1.5, 3.4]),
            np.array([0.1, 0.3, 3.4, 0.1, 2.0, 2.0, 1.8, 3.4]),
            snap_discrete(A_SORA + rng.uniform(-0.3, 0.3, N_GRP)),
        ]
        feas_costs = []
        for c in candidates:
            cs = snap_discrete(c)
            w, r, feas, _, _ = evaluate(cs)
            feas_costs.append((cs, w if feas else np.inf + w))
        best = min(feas_costs, key=lambda x: x[1])[0]
        return best
    else:
        return snap_discrete(rng.uniform(A_MIN, A_MAX, N_GRP))

def coord_descent_discrete(A_init, W_init, R_init, max_passes=20):
    A = snap_discrete(A_init.copy()); W, R = W_init, R_init
    improved = True
    for _ in range(max_passes):
        if not improved: break
        improved = False
        for i in range(N_GRP):
            idx_cur = np.argmin(np.abs(DISC_VALS - A[i]))
            if idx_cur == 0: continue
            A_try = A.copy()
            A_try[i] = DISC_VALS[idx_cur-1]
            W_t, R_t, feas, _, _ = evaluate(A_try)
            if feas and W_t < W:
                A, W, R = A_try, W_t, R_t; improved = True
    return A, W, R

# ================================================================
# PROMPTS  (full = original w/ anchor, fewshot = worked examples,
# generic = no structural knowledge at all)
# ================================================================
FULL_PROMPT_TMPL = """You are an expert in structural reliability-based design optimization.

PROBLEM: 25-bar 3D space truss RBDO
  Goal: minimize weight (lb) with Reliability >= {tr} and stress <= {siglim:.0f} psi
  Design: A[1]..A[8] (8 cross-section groups), discrete in [{amin}..{amax}] in^2
  Random variables (16, COV=5%): E, P1x, P1y, P1z, P2y, P2z, P3x, P6x, A1..A8

STRUCTURAL KNOWLEDGE (critical for reliability):
  - Group 3 (A[3]): 4 vertical inner elements, L~107 in -> primary stiffness -> KEEP HIGH (>=3.0)
  - Group 8 (A[8]): 4 short base diagonals, L~133 in -> secondary stiffness -> KEEP HIGH (>=2.5)
  - Group 6 (A[6]): 4 long space diagonals, L~181 in -> tune carefully
  - Group 7 (A[7]): 4 long space diagonals, L~181 in -> tune carefully
  - Group 2 (A[2]): 4 outer diagonals, L~130 in -> can trade with A[6,7]
  - Groups 1,4 (A[1],A[4]): short elements -> often A_MIN={amin} (light, low influence)

REFERENCE DESIGNS:
  IGA   [0.1,0.3,3.4,0.1,2.0,1.0,0.5,3.4]: W=483 lb, R=0.49 -- NOT feasible (too light)
  SORA  [0.1,2.0,3.4,0.1,0.1,1.2,1.9,3.4]: W=659 lb, R=0.999 -- feasible but heavy
  Heavy [0.1,0.3,3.4,0.1,2.0,2.5,2.0,3.4]: W=701 lb, R=0.991 -- feasible but heavier
  TARGET: find W < 660 lb with R >= {tr}

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  max_disp    = {disp:.4f} in  (limit={displim}, violation={gapd:.4f})
  max_stress  = {sig:.1f} psi  (limit={siglim:.0f}, violation={gaps:.1f})
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE (Python function) applied ~{stag} times.
Use reliability and weight to make DETERMINISTIC decisions. Do NOT randomize.

Return ONLY the function below (no markdown fences, no explanation):

def update_operator(A, reliability, weight, disp, stress):
    import numpy as np
    A_new = A.copy()
    # your deterministic strategy here
    return np.clip(A_new, {amin}, {amax})
"""

FEWSHOT_PROMPT_TMPL = """You are an expert in structural reliability-based design optimization.

PROBLEM: 25-bar 3D space truss RBDO
  Goal: minimize weight (lb) with Reliability >= {tr} and stress <= {siglim:.0f} psi
  Design: A[1]..A[8] (8 cross-section groups), discrete in [{amin}..{amax}] in^2
  Random variables (16, COV=5%): E, P1x, P1y, P1z, P2y, P2z, P3x, P6x, A1..A8

STRUCTURAL KNOWLEDGE (critical for reliability):
  - Group 3 (A[3]): 4 vertical inner elements, L~107 in -> primary stiffness -> KEEP HIGH (>=3.0)
  - Group 8 (A[8]): 4 short base diagonals, L~133 in -> secondary stiffness -> KEEP HIGH (>=2.5)
  - Group 6 (A[6]): 4 long space diagonals, L~181 in -> tune carefully
  - Group 7 (A[7]): 4 long space diagonals, L~181 in -> tune carefully
  - Group 2 (A[2]): 4 outer diagonals, L~130 in -> can trade with A[6,7]
  - Groups 1,4 (A[1],A[4]): short elements -> often near A_MIN={amin} (light, low influence)

WORKED EXAMPLES (illustrating good update behaviour from DIFFERENT starting
configurations -- use these to learn the PATTERN of good moves, not a fixed
target design; the correct final design depends on where you currently are):

Example A -- far from feasible, stiffness groups too thin:
  state: A=[0.1,0.3,1.0,0.1,2.0,0.3,0.3,1.0]  R=0.30 (infeasible, need >= {tr})
  good update: raise A[3] and A[8] toward their upper range (they carry
    primary/secondary stiffness); nudge A[6],A[7] up moderately; leave
    A[1],A[4] near A_MIN since they contribute little.
  result: R rose to roughly 0.75 -- still infeasible but much closer.

Example B -- feasible but overweight, some groups oversized:
  state: A=[0.1,2.0,3.4,0.1,2.0,2.5,2.0,3.4]  R=0.991  weight=701 lb
  good update: reduce A[5] and A[2] toward lower discrete steps since they
    are not on the primary load path; keep A[3]>=3.0 and A[8]>=2.5 intact;
    trade A[6]/A[7] down by one discrete step at a time if R stays >= {tr}.
  result: weight dropped toward the 650-670 lb range, R stayed above {tr}.

Example C -- feasible and near-optimal, fine-tuning phase:
  state: A=[0.1,1.0,3.4,0.1,0.5,1.5,1.5,3.4]  R=0.995  weight=645 lb
  good update: step down ONE group by the smallest discrete increment
    (0.1), re-check reliability; if it drops below {tr} revert that group
    and try a different one. Never reduce A[3] below 3.0 or A[8] below 2.5.
  result: small, safe weight reductions of a few percent per iteration.

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  max_disp    = {disp:.4f} in  (limit={displim}, violation={gapd:.4f})
  max_stress  = {sig:.1f} psi  (limit={siglim:.0f}, violation={gaps:.1f})
  {areas}

RECENT HISTORY
{hist}

TASK: Using the PATTERN from the worked examples above (not their specific
numbers -- your current state is different from all three), write an
adaptive UPDATE RULE applied ~{stag} times that moves the CURRENT design
toward lower weight while keeping reliability >= {tr} and stress <= {siglim:.0f} psi.

Return ONLY the function below (no markdown fences, no explanation):

def update_operator(A, reliability, weight, disp, stress):
    import numpy as np
    A_new = A.copy()
    # your deterministic strategy here
    return np.clip(A_new, {amin}, {amax})
"""

GENERIC_PROMPT_TMPL = """You are an optimization assistant.

PROBLEM: minimize the weight of a structure with 8 discrete design
  variables A[1]..A[8], each in {{0.1, 0.2, ..., 3.4}} (30 discrete steps),
  subject to a reliability constraint: Reliability >= {tr}, and a stress
  constraint: stress <= {siglim:.0f} psi. Increasing variables generally
  increases reliability and weight; decreasing them does the opposite.
  You have NO other information about the structure.

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  max_stress  = {sig:.1f} psi (limit {siglim:.0f})
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE applied ~{stag} times that improves the
design based only on the numerical feedback above.

Return ONLY the function below (no markdown fences, no explanation):

def update_operator(A, reliability, weight, disp, stress):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

PROMPTS = {"llm_full": FULL_PROMPT_TMPL, "llm_fewshot": FEWSHOT_PROMPT_TMPL,
           "llm_generic": GENERIC_PROMPT_TMPL}

def build_prompt(kind, A, R, W, disp, sig, it, history):
    hist = "\n".join(f"  iter={h['iter']:3d}  W={h['W']:8.1f}  R={h['R']:.4f}  "
                     f"feasible={h['feasible']}" for h in history[-6:])
    areas = ", ".join(f"A[{i+1}]={v:.2f}" for i, v in enumerate(A))
    gapd = max(0.0, disp - DISP_LIM); gaps = max(0.0, sig - SIG_LIM)
    return PROMPTS[kind].format(tr=TARGET_R, amin=A_MIN, amax=A_MAX, siglim=SIG_LIM,
                                displim=DISP_LIM, it=it, W=W, R=R, disp=disp, sig=sig,
                                gapd=gapd, gaps=gaps, areas=areas, hist=hist, stag=STAGNATION_LIMIT)

def extract_code(text):
    lines, inside = [], False
    for line in text.splitlines():
        clean = line.replace("```python", "").replace("```", "")
        if clean.strip().startswith("def update_operator"): inside = True
        if inside: lines.append(clean)
    return "\n".join(lines) if lines else None

# ================================================================
# PROPOSER  (fallback / random / LLM-with-retry, stagnation FIXED)
# ================================================================
def _post_with_retry(url, headers, json_body, timeout=45, max_retries=4):
    last_err = None
    for attempt in range(max_retries):
        try:
            r = requests.post(url, headers=headers, json=json_body, timeout=timeout)
            if r.status_code >= 500:
                raise requests.exceptions.HTTPError(f"{r.status_code} Server Error", response=r)
            r.raise_for_status()
            return r
        except Exception as e:
            last_err = e
            if attempt < max_retries - 1:
                wait = (2**attempt) + np.random.uniform(0,1)
                print(f"    retry in {wait:.1f}s ({e})")
                time.sleep(wait)
    raise last_err

def call_deepseek(prompt):
    r = _post_with_retry(DEEPSEEK_URL,
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
        json_body={"model": "deepseek-chat", "messages": [{"role":"user","content":prompt}],
                   "temperature": 0.7, "max_tokens": 700})
    return extract_code(r.json()["choices"][0]["message"]["content"])

class Proposer:
    LLM_KINDS = ("llm_full", "llm_fewshot", "llm_generic")

    def __init__(self, kind, rng=None):
        self.kind = kind; self.rng = rng

    def get_operator(self, A, R, W, disp, sig, it, history):
        if self.kind in self.LLM_KINDS:
            CNT.inc("llm_calls")
            prompt = build_prompt(self.kind, A, R, W, disp, sig, it, history)
            try:
                return call_deepseek(prompt)
            except Exception as e:
                print(f"    ⚠ DeepSeek API error after retries: {e}")
                return None
        return None

    def apply(self, code, A, R, W, disp, sig):
        if self.kind == "fallback" or (self.kind in self.LLM_KINDS and code is None):
            f = 1.05 if R < TARGET_R else 0.97
            return snap_discrete(np.clip(A*f, A_MIN, A_MAX))
        if self.kind == "random":
            pert = 1.0 + self.rng.uniform(-0.15, 0.15, N_GRP)
            return snap_discrete(np.clip(A*pert, A_MIN, A_MAX))
        try:
            ns = {"np": np, "numpy": np, "N_GRP": N_GRP, "A_MIN": A_MIN,
                  "A_MAX": A_MAX, "DISC_VALS": DISC_VALS}
            exec(code, ns)
            raw = ns["update_operator"](A.copy(), float(R), float(W), float(disp), float(sig))
            A_new = np.atleast_1d(np.asarray(raw, dtype=float)).flatten()
            if A_new.shape[0] != N_GRP: raise ValueError("shape")
            return snap_discrete(np.clip(A_new, A_MIN, A_MAX))
        except Exception:
            f = 1.05 if R < TARGET_R else 0.97
            return snap_discrete(np.clip(A*f, A_MIN, A_MAX))

# ================================================================
# ONE RUN  (proposer_kind, init_mode, cd on/off, seed)
# ================================================================
def run_one(variant, proposer_kind, init_mode, use_cd, seed):
    global CNT
    CNT = Counters()
    t0 = time.time()
    rng = np.random.RandomState(seed)
    prop = Proposer(proposer_kind, rng=rng)

    CNT.set_phase("init")
    A = init_design(init_mode, rng)
    W, R, feasible, disp, sig = evaluate(A)

    best_A = A.copy(); best_W = W if feasible else np.inf; best_R = R
    history = [{"iter":0,"W":W,"R":R,"disp":disp,"sig":sig,"feasible":feasible}]
    stag = 0

    CNT.set_phase("loop")
    if proposer_kind == "none":
        it = 0
        while not feasible and it < MAX_ITER_LLM:
            it += 1
            A = snap_discrete(np.clip(A*1.05, A_MIN, A_MAX))
            W, R, feasible, disp, sig = evaluate(A)
            if feasible: best_A, best_W, best_R = A.copy(), W, R
    else:
        op = prop.get_operator(A, R, W, disp, sig, 0, history)
        for it in range(1, MAX_ITER_LLM+1):
            try:
                A_new = prop.apply(op, A, R, W, disp, sig)
                W_n, R_n, feas_n, disp_n, sig_n = evaluate(A_new)
            except Exception:
                A_new, W_n, R_n, feas_n, disp_n, sig_n = A.copy(), W, R, feasible, disp, sig
            accept = ((not feasible and R_n > R) or (feasible and feas_n and W_n < W))
            if accept:
                A, W, R, disp, sig, feasible = A_new, W_n, R_n, disp_n, sig_n, feas_n
                if feas_n and W_n < best_W:
                    best_A, best_W, best_R = A_new.copy(), W_n, R_n
            history.append({"iter":it,"W":W,"R":R,"disp":disp,"sig":sig,"feasible":feasible})

            # Stagnation FIX (from the 10-bar lesson): use the per-iteration
            # `accept` flag directly, not a best_W-diff comparison that
            # breaks (nan) when best_W stays inf for a never-feasible run.
            stag = 0 if accept else stag + 1
            if stag >= STAGNATION_LIMIT:
                op = prop.get_operator(A, R, W, disp, sig, it, history)
                stag = 0

    W_loop, R_loop = best_W, best_R
    A_loop = best_A.copy()
    eval_loop = CNT.total("eval_calls")

    CNT.set_phase("cd")
    if use_cd and best_W < np.inf:
        A_cd, W_cd, R_cd = coord_descent_discrete(best_A, best_W, best_R)
        if W_cd < best_W and R_cd >= TARGET_R:
            best_A, best_W, best_R = A_cd, W_cd, R_cd

    elapsed = time.time() - t0
    row = {
        "variant": variant, "proposer": proposer_kind, "init": init_mode, "cd": use_cd, "seed": seed,
        "W_loop_end": W_loop if W_loop < np.inf else None,
        "W_final": best_W if best_W < np.inf else None,
        "R_final": best_R,
        "feasible": bool(best_R >= TARGET_R - 1e-6 and best_W < np.inf),
        "CD_delta": (W_loop-best_W) if (use_cd and W_loop < np.inf) else 0.0,
        "eval_loop": eval_loop, "eval_total": CNT.total("eval_calls"),
        "fem_total": CNT.total("fem_solves"), "llm_calls": CNT.total("llm_calls"),
        "time_s": round(elapsed,2),
    }
    for i in range(N_GRP):
        row[f"A{i+1}"] = float(best_A[i]) if best_W < np.inf else None
    return row

# ================================================================
# VARIANT MATRIX  (mirrors the 10-bar taxonomy exactly)
# ================================================================
LOCAL_VARIANTS = [
    ("fallback+CD_warm",   "fallback", "warm",   True),
    ("fallback+CD_rand",   "fallback", "random", True),
    ("fallback-noCD_rand", "fallback", "random", False),
    ("random+CD_warm",     "random",   "warm",   True),
    ("random+CD_rand",     "random",   "random", True),
    ("random-noCD_rand",   "random",   "random", False),
    ("CDonly_warm",        "none",     "warm",   True),
    ("CDonly_rand",        "none",     "random", True),
]
LLM_VARIANTS = [
    ("LLM+CD_warm",         "llm_full",     "warm",   True),
    ("LLM+CD_rand",         "llm_full",     "random", True),
    ("LLM-noCD_rand",       "llm_full",     "random", False),
    ("LLMgeneric+CD_rand",  "llm_generic",  "random", True),
    ("LLMfewshot+CD_rand",  "llm_fewshot",  "random", True),
    ("LLMfewshot+CD_warm",  "llm_fewshot",  "warm",   True),
]

# ================================================================
# DRIVER  (resumable, incremental per-seed save)
# ================================================================
def append_csv(fname, rows, fieldnames):
    new = not os.path.exists(fname)
    with open(fname, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

def rebuild_excel(run_set):
    csv_name = f"phase1_perrun_25bar_{run_set}.csv"
    if not os.path.exists(csv_name):
        print("No data yet."); return
    rows = list(csv.DictReader(open(csv_name)))
    if not rows: return
    from collections import defaultdict
    groups = defaultdict(list)
    for r in rows: groups[r["variant"]].append(r)

    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Summary"
    ws.append(["variant","n","feasible_rate","W_final_mean","W_final_std",
               "W_final_min","W_final_max","CD_delta_mean","eval_total_mean","llm_calls_mean"])
    for name, rs in groups.items():
        wf = np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd = np.array([float(r["CD_delta"]) for r in rs])
        ev  = np.array([float(r["eval_total"]) for r in rs])
        lc  = np.array([float(r["llm_calls"]) for r in rs])
        feas = np.mean([r["feasible"]=="True" for r in rs])
        ws.append([name, len(rs), feas,
                   float(wf.mean()) if len(wf) else None,
                   float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,
                   float(wf.max()) if len(wf) else None,
                   float(cdd.mean()), float(ev.mean()), float(lc.mean())])
    ws.append([]); ws.append(["timestamp", datetime.datetime.now().isoformat()])
    ws.append(["RUN_SET", run_set]); ws.append(["N_SEEDS", N_SEEDS])

    ws2 = wb.create_sheet("PerRun")
    keys2 = list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])

    fname = f"phase1_25bar_{run_set}.xlsx"
    wb.save(fname)
    print(f"✓ Saved: {fname}  ({len(rows)} total runs)")
    try:
        from google.colab import files as _colab_files
        _colab_files.download(fname)
    except Exception:
        pass

def main():
    variants = LOCAL_VARIANTS if RUN_SET == "local" else LLM_VARIANTS
    if len(sys.argv) > 1:
        want = set(sys.argv[1:])
        variants = [v for v in variants if v[0] in want]

    csv_name = f"phase1_perrun_25bar_{RUN_SET}.csv"
    done_seeds = {}
    if os.path.exists(csv_name):
        for r in csv.DictReader(open(csv_name)):
            done_seeds.setdefault(r["variant"], set()).add(int(r["seed"]))

    print(f"RUN_SET={RUN_SET}: {len(variants)} variants")
    for (name, prop, init, cd) in variants:
        already = done_seeds.get(name, set())
        remaining = [s for s in SEEDS if s not in already]
        if not remaining:
            print(f"\n=== {name}: all {N_SEEDS} seeds already done, skipping ===")
            continue
        print(f"\n=== {name} ({len(remaining)}/{N_SEEDS} seeds remaining) ===")
        fieldnames = None
        for s in remaining:
            row = run_one(name, prop, init, cd, s)
            if fieldnames is None: fieldnames = list(row.keys())
            append_csv(csv_name, [row], fieldnames)
            wf = row["W_final"]
            print(f"  seed {s:2d}: W_loop={row['W_loop_end']}  W_final={wf}  "
                  f"R={row['R_final']:.4f}  eval={row['eval_total']}  "
                  f"llm={row['llm_calls']}  t={row['time_s']}s", flush=True)
            rebuild_excel(RUN_SET)   # save + auto-download after EVERY seed

    rebuild_excel(RUN_SET)

if __name__ == "__main__":
    main()
