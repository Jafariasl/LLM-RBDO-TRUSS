# ============================================================
#  PHASE 4 — SURROGATE-ASSISTED RBDO BASELINE  —  10-bar truss
#  Answers R1-3: "no comparison with modern surrogate-assisted
#  RBDO (Kriging/Bayesian optimization/active-learning) methods
#  that specifically target reducing expensive FEM+FORM calls —
#  exactly the claimed advantage of the LLM framework."
# ============================================================

import numpy as np
from scipy.stats import norm, qmc
from scipy.optimize import minimize
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
import time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

# ================================================================
# CONFIG  (identical problem constants to Phase 0/1/3)
# ================================================================
E_MEAN, P_MEAN, RHO   = 1.0e7, 1.0e5, 0.1
COV, DELTA_MAX        = 0.05, 2.0
TARGET_R              = 0.99
A_MIN, A_MAX, N_MEM   = 0.1, 40.0, 10

N_SEEDS        = 20     # matched-budget (statistical comparison)
NATIVE_SEEDS   = 5      # native/larger budget (expensive GP refits — order-of-magnitude only)
SEEDS          = list(range(1, N_SEEDS + 1))
SEEDS_NATIVE   = list(range(1, NATIVE_SEEDS + 1))

MATCHED_EVAL_CAP = 300    # same definition as Phase 3
NATIVE_EVAL_CAP  = 500    # a larger budget for context (still far below PSO/GA's 7500)
N_INIT_FRACTION  = 0.30   # 30% of budget spent on initial DOE, rest on EGO iterations

OUT_CSV   = "phase4_perrun_10bar.csv"
OUT_XLSX  = "phase4_10bar_surrogate.xlsx"

# ================================================================
# COUNTERS  (identical scheme to Phase 0/1/3)
# ================================================================
class Counters:
    FIELDS = ["fem_solves", "ls_evals", "form_calls", "hlrf_iters", "eval_calls"]
    def __init__(self):
        self.phase = "search"; self.data = {}; self.form_iter_log = []
    def _d(self):
        if self.phase not in self.data:
            self.data[self.phase] = {f: 0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self, f, n=1): self._d()[f] += n
    def set_phase(self, p): self.phase = p; self._d()
    def total(self, f): return sum(d[f] for d in self.data.values())

CNT = Counters()

# ================================================================
# GEOMETRY + FEM + FORM + EVALUATE  (identical to Phase 0/1/3)
# ================================================================
NODES = np.array([[720.,360.],[720.,0.],[360.,360.],
                  [360.,0.],[0.,360.],[0.,0.]])
MEMBERS = np.array([[4,2],[2,0],[5,3],[3,1],[3,2],
                    [0,1],[3,4],[2,5],[1,2],[0,3]])
FIXED_DOFS = [8,9,10,11]
FREE_DOFS  = [d for d in range(12) if d not in FIXED_DOFS]
MEMBER_LENGTHS = np.array([np.linalg.norm(NODES[j]-NODES[i]) for i,j in MEMBERS])

def fem_10bar(A, E=E_MEAN, P=P_MEAN):
    CNT.inc("fem_solves")
    A = np.asarray(A, dtype=float)
    K = np.zeros((12,12))
    for m,(i,j) in enumerate(MEMBERS):
        L = MEMBER_LENGTHS[m]
        c = (NODES[j,0]-NODES[i,0])/L; s = (NODES[j,1]-NODES[i,1])/L
        k = E*A[m]/L
        ke = k*np.array([[c*c,c*s,-c*c,-c*s],[c*s,s*s,-c*s,-s*s],
                         [-c*c,-c*s,c*c,c*s],[-c*s,-s*s,c*s,s*s]])
        dofs=[2*i,2*i+1,2*j,2*j+1]
        for a in range(4):
            for b in range(4):
                K[dofs[a],dofs[b]] += ke[a,b]
    F = np.zeros(12); F[3] = -P; F[7] = -P
    Kff = K[np.ix_(FREE_DOFS,FREE_DOFS)]
    try:
        uf = np.linalg.solve(Kff, F[FREE_DOFS])
    except np.linalg.LinAlgError:
        return np.inf, np.inf, np.inf, None
    U = np.zeros(12); U[FREE_DOFS] = uf
    disp = abs(U[3])
    W = RHO*np.sum(A*MEMBER_LENGTHS)
    return W, disp, disp-DELTA_MAX, None

def limit_state(x):
    CNT.inc("ls_evals")
    E_v = max(x[0], E_MEAN*0.01); P_v = max(x[1], P_MEAN*0.01)
    A_v = np.maximum(x[2:], A_MIN*0.01)
    _, disp, _, _ = fem_10bar(A_v, E=E_v, P=P_v)
    return DELTA_MAX - disp

def form_reliability(A_design):
    CNT.inc("form_calls")
    A_design = np.clip(A_design, A_MIN, A_MAX)
    muy = np.concatenate([[E_MEAN, P_MEAN], A_design])
    sig = COV*muy; dmuy = 1e-4*muy
    X = muy.copy(); Z = (X-muy)/sig; beta = np.linalg.norm(Z)
    eZ, eB, n_it = 100., 100., 0
    for _ in range(100):
        if abs(eZ) <= 1e-3 and abs(eB) <= 1e-3: break
        n_it += 1; CNT.inc("hlrf_iters")
        bp, znp = beta, np.linalg.norm(Z)
        g0 = limit_state(X); G = np.zeros(len(X))
        for i in range(len(X)):
            xp = X.copy(); xp[i] += dmuy[i]
            G[i] = -(limit_state(xp)-g0)/dmuy[i]*sig[i]
        gn = np.linalg.norm(G)
        if gn < 1e-12: break
        beta = beta + g0/gn; Z = (G/gn)*beta; X = muy + sig*Z
        eB = beta-bp; eZ = np.linalg.norm(Z)-znp
    CNT.form_iter_log.append(n_it)
    return float(beta), float(norm.cdf(beta)), float(1.-norm.cdf(beta))

def evaluate(A):
    CNT.inc("eval_calls")
    A = np.atleast_1d(np.asarray(A, dtype=float)).flatten()
    if A.shape[0] != N_MEM: return np.inf, 0.0, False, np.inf
    A = np.clip(A, A_MIN, A_MAX)
    W, disp, cstr, _ = fem_10bar(A)
    _, ps, _ = form_reliability(A)
    return W, ps, (ps >= TARGET_R - 1e-6) and (cstr <= 1e-6), disp

def penalty_fitness(A):
    """Same penalty structure used for PSO/GA in Phase 3 — the surrogate
    is trained on THIS scalar objective, exactly like a real Kriging-RBDO
    paper would (single merit function combining weight + constraints)."""
    W, R, _, disp = evaluate(A)
    if R < TARGET_R:
        return W + 1e5 + 1e7*(TARGET_R - R)**2
    if disp > DELTA_MAX:
        return W + 1e5 + 1e5*(disp - DELTA_MAX)
    return W

def init_center(mode, rng):
    if mode == "warm":
        A = np.array([30.0, 0.1, 25.0, 20.0, 0.1, 0.1, 3.0, 25.0, 25.0, 0.1])
        A += rng.uniform(-0.5, 0.5, N_MEM)
    else:
        A = rng.uniform(A_MIN, A_MAX, N_MEM)
    return np.clip(A, A_MIN, A_MAX)

# ================================================================
# COORDINATE DESCENT  (identical to Phase 0/1/3)
# ================================================================
def coord_descent(A_init, W_init, R_init, max_passes=20):
    A = A_init.copy(); W, R = W_init, R_init
    improved = True
    for _ in range(max_passes):
        if not improved: break
        improved = False
        for i in range(N_MEM):
            for delta in [0.5, 1.0, 2.0, 5.0]:
                A_try = A.copy()
                A_try[i] = max(A_MIN, A[i]-delta)
                if A_try[i] >= A[i]: continue
                W_t, R_t, feas, _ = evaluate(A_try)
                if feas and W_t < W:
                    A, W, R = A_try, W_t, R_t; improved = True; break
    return A, W, R

# ================================================================
# EGO / KRIGING SURROGATE-ASSISTED SEARCH
# ================================================================
def build_gp():
    kernel = (ConstantKernel(1.0, (1e-3, 1e3)) *
              Matern(length_scale=np.ones(N_MEM)*5.0,
                     length_scale_bounds=(0.5, 50.0), nu=2.5) +
              WhiteKernel(noise_level=1e-3, noise_level_bounds=(1e-6, 1e1)))
    return GaussianProcessRegressor(kernel=kernel, normalize_y=True,
                                    n_restarts_optimizer=2, alpha=1e-8)

def expected_improvement(X, gp, y_best, xi=0.01):
    mu, sigma = gp.predict(X, return_std=True)
    sigma = np.maximum(sigma, 1e-9)
    imp = y_best - mu - xi          # minimization: improvement = current best - predicted
    Z = imp / sigma
    ei = imp*norm.cdf(Z) + sigma*norm.pdf(Z)
    ei[sigma < 1e-9] = 0.0
    return ei

def propose_next(gp, y_best, rng, n_candidates=500, n_local=2):
    cand = rng.uniform(A_MIN, A_MAX, (n_candidates, N_MEM))
    ei = expected_improvement(cand, gp, y_best)
    top_idx = np.argsort(-ei)[:n_local]
    best_x, best_ei = cand[top_idx[0]], ei[top_idx[0]]
    for idx in top_idx:
        x0 = cand[idx]
        res = minimize(lambda x: -expected_improvement(x.reshape(1,-1), gp, y_best)[0],
                       x0, method="L-BFGS-B",
                       bounds=[(A_MIN, A_MAX)]*N_MEM,
                       options={"maxiter": 30})
        if -res.fun > best_ei:
            best_ei, best_x = -res.fun, res.x
    return np.clip(best_x, A_MIN, A_MAX)

REFIT_EVERY = 4   # refit GP hyperparameters every N iterations (not every single one)
                  # — standard practical EGO shortcut; between refits we still add
                  # new points to X,y but reuse the last fitted kernel to propose,
                  # then do a full refit periodically to keep the surrogate honest.

def run_ego(seed, init_mode, eval_cap):
    rng = np.random.RandomState(seed)
    n_init = max(2*N_MEM, int(eval_cap * N_INIT_FRACTION))

    center = init_center(init_mode, rng)
    sampler = qmc.LatinHypercube(d=N_MEM, seed=seed)
    unit = sampler.random(n=n_init)
    if init_mode == "warm":
        spread = 6.0
        lo = np.clip(center - spread, A_MIN, A_MAX)
        hi = np.clip(center + spread, A_MIN, A_MAX)
    else:
        lo = np.full(N_MEM, A_MIN); hi = np.full(N_MEM, A_MAX)
    X = qmc.scale(unit, lo, hi)

    y = np.array([penalty_fitness(x) for x in X])

    gp = build_gp()
    best_idx = np.argmin(y)
    best_x, best_y = X[best_idx].copy(), y[best_idx]

    it = 0
    while CNT.total("eval_calls") < eval_cap:
        if it % REFIT_EVERY == 0:
            gp.fit(X, y)
        x_next = propose_next(gp, best_y, rng)
        y_next = penalty_fitness(x_next)
        X = np.vstack([X, x_next]); y = np.append(y, y_next)
        if y_next < best_y:
            best_x, best_y = x_next.copy(), y_next
        it += 1

    W_f, R_f, feas_f, _ = evaluate(best_x)
    return best_x, W_f, R_f, feas_f

# ================================================================
# ONE RUN
# ================================================================
def run_one(init_mode, budget, seed):
    global CNT
    CNT = Counters()
    t0 = time.time()
    eval_cap = MATCHED_EVAL_CAP if budget == "matched" else NATIVE_EVAL_CAP

    A_best, W_search, R_search, feas_search = run_ego(seed, init_mode, eval_cap)
    eval_search = CNT.total("eval_calls")

    CNT.set_phase("cd")
    W_cd, R_cd = W_search, R_search
    if feas_search and W_search < np.inf:
        A_cd, W_cd2, R_cd2 = coord_descent(A_best, W_search, R_search)
        if W_cd2 < W_search and R_cd2 >= TARGET_R:
            W_cd, R_cd = W_cd2, R_cd2

    elapsed = time.time() - t0
    return {
        "method": "Kriging-EGO", "init": init_mode, "budget": budget, "seed": seed,
        "W_search": W_search if feas_search else None,
        "W_final": W_cd if feas_search else None,
        "R_final": R_cd, "feasible": bool(feas_search),
        "CD_delta": (W_search - W_cd) if feas_search else 0.0,
        "eval_search": eval_search, "eval_total": CNT.total("eval_calls"),
        "fem_total": CNT.total("fem_solves"), "time_s": round(elapsed, 2),
    }

# ================================================================
# DRIVER  (resumable: skips seeds already present in the CSV)
# ================================================================
def append_csv(fname, rows, fieldnames):
    new = not os.path.exists(fname)
    with open(fname, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

COMBOS = [("warm","matched"), ("random","matched"),
          ("warm","native"),  ("random","native")]

def rebuild_excel():
    rows = list(csv.DictReader(open(OUT_CSV))) if os.path.exists(OUT_CSV) else []
    if not rows:
        print("No data yet — nothing to save."); return
    from collections import defaultdict
    groups = defaultdict(list)
    for r in rows: groups[(r["init"], r["budget"])].append(r)

    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Summary"
    ws.append(["method","init","budget","n","feasible_rate",
               "W_final_mean","W_final_std","W_final_min","W_final_max",
               "CD_delta_mean","eval_total_mean"])
    for (init, budget), rs in groups.items():
        wf = np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd = np.array([float(r["CD_delta"]) for r in rs])
        ev  = np.array([float(r["eval_total"]) for r in rs])
        feas = np.mean([r["feasible"]=="True" for r in rs])
        ws.append(["Kriging-EGO", init, budget, len(rs), feas,
                   float(wf.mean()) if len(wf) else None,
                   float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,
                   float(wf.max()) if len(wf) else None,
                   float(cdd.mean()), float(ev.mean())])
    ws.append([]); ws.append(["timestamp", datetime.datetime.now().isoformat()])
    ws.append(["note", "Kriging/EGO surrogate-assisted RBDO baseline (R1-3). "
                       "matched budget=300 evals (20 seeds); native budget=500 evals (5 seeds)."])

    ws2 = wb.create_sheet("PerRun")
    keys2 = list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])

    wb.save(OUT_XLSX)
    print(f"✓ Saved: {OUT_XLSX}  ({len(rows)} total runs)")
    try:
        from google.colab import files as _colab_files
        _colab_files.download(OUT_XLSX)
    except Exception:
        pass

def main():
    combos = COMBOS
    if len(sys.argv) > 1:
        want = set(sys.argv[1:])
        combos = [c for c in combos if f"{c[0]}_{c[1]}" in want]

    done_seeds = {}
    if os.path.exists(OUT_CSV):
        existing = list(csv.DictReader(open(OUT_CSV)))
        for r in existing:
            key = (r["init"], r["budget"])
            done_seeds.setdefault(key, set()).add(int(r["seed"]))

    for (init, budget) in combos:
        name = f"{init}_{budget}"
        seeds_here = SEEDS_NATIVE if budget == "native" else SEEDS
        already = done_seeds.get((init, budget), set())
        remaining = [s for s in seeds_here if s not in already]
        if not remaining:
            print(f"\n=== {name}: all {len(seeds_here)} seeds already done, skipping ===")
            continue
        print(f"\n=== Kriging-EGO {name} ({len(remaining)}/{len(seeds_here)} seeds remaining) ===")
        fieldnames = None
        for s in remaining:
            r = run_one(init, budget, s)
            if fieldnames is None: fieldnames = list(r.keys())
            append_csv(OUT_CSV, [r], fieldnames)
            wf = r["W_final"]
            print(f"  seed {s:2d}: W_search={r['W_search']}  W_final={wf}  "
                  f"R={r['R_final']:.4f}  eval={r['eval_total']}  t={r['time_s']}s", flush=True)
            rebuild_excel()   # save + auto-download after EVERY seed — crash-safe

    rebuild_excel()

if __name__ == "__main__":
    main()
