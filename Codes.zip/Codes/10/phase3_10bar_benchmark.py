# ============================================================
#  PHASE 3 — FAIR BENCHMARKING  —  10-bar truss
#  Answers R1-2, R3-2 (equal budgets, same CD refinement for all
#  methods, before/after CD reported) + reuses R3-3 granular counters.
#
#  Methods : PSO | GA (differential evolution) | SLSQP
#  Init    : warm | random          (SAME two inits used for LLM in Phase 1
#                                    — original code only gave SLSQP a warm
#                                    start while PSO/GA got random: an
#                                    additional unfairness now corrected)
#  Budget  : native   (original paper settings: 150 iters, full pop)
#            matched  (capped so eval_total ≈ same order as LLM's ~150-460)
#  CD      : applied identically to ALL methods post-hoc (same function
#            as Phase 0/1), before/after weight reported separately.

# ============================================================

import numpy as np
from scipy.stats import norm
from scipy.optimize import minimize, differential_evolution
import time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

# ================================================================
# CONFIG  (identical constants to Phase 0/1 — same problem)
# ================================================================
E_MEAN, P_MEAN, RHO   = 1.0e7, 1.0e5, 0.1
COV, DELTA_MAX        = 0.05, 2.0
TARGET_R              = 0.99
A_MIN, A_MAX, N_MEM   = 0.1, 40.0, 10

N_SEEDS = 20                       # matched-budget comparisons (statistical power)
NATIVE_SEEDS = 3                   # native (paper) budget — expensive, order-of-magnitude only
SEEDS = list(range(1, N_SEEDS + 1))
SEEDS_NATIVE = list(range(1, NATIVE_SEEDS + 1))

# native (paper's original) budgets
NATIVE_ITERS_PSO_GA = 150
NATIVE_PSO_PARTICLES = 50
NATIVE_GA_POPSIZE    = 5        # popsize * N_MEM = 50 individuals
NATIVE_SLSQP_MAXITER = 500

# matched budget: cap total eval_calls to ~same order as LLM (150-460)
MATCHED_EVAL_CAP = 300

# ================================================================
# COUNTERS  (identical scheme to Phase 0/1)
# ================================================================
class Counters:
    FIELDS = ["fem_solves", "ls_evals", "form_calls", "hlrf_iters", "eval_calls"]
    def __init__(self):
        self.phase = "search"; self.data = {}; self.form_iter_log = []
    def _d(self):
        if self.phase not in self.data:
            self.data[self.phase] = {f: 0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self, f, n=1): self._d()[f] += n
    def set_phase(self, p): self.phase = p; self._d()
    def total(self, f): return sum(d[f] for d in self.data.values())
    def phase_val(self, ph, f): return self.data.get(ph, {}).get(f, 0)

CNT = Counters()

# ================================================================
# GEOMETRY + FEM + FORM + EVALUATE  (identical to Phase 0/1)
# ================================================================
NODES = np.array([[720.,360.],[720.,0.],[360.,360.],
                  [360.,0.],[0.,360.],[0.,0.]])
MEMBERS = np.array([[4,2],[2,0],[5,3],[3,1],[3,2],
                    [0,1],[3,4],[2,5],[1,2],[0,3]])
FIXED_DOFS = [8,9,10,11]
FREE_DOFS  = [d for d in range(12) if d not in FIXED_DOFS]
MEMBER_LENGTHS = np.array([np.linalg.norm(NODES[j]-NODES[i]) for i,j in MEMBERS])

def fem_10bar(A, E=E_MEAN, P=P_MEAN):
    CNT.inc("fem_solves")
    A = np.asarray(A, dtype=float)
    K = np.zeros((12,12))
    for m,(i,j) in enumerate(MEMBERS):
        L = MEMBER_LENGTHS[m]
        c = (NODES[j,0]-NODES[i,0])/L; s = (NODES[j,1]-NODES[i,1])/L
        k = E*A[m]/L
        ke = k*np.array([[c*c,c*s,-c*c,-c*s],[c*s,s*s,-c*s,-s*s],
                         [-c*c,-c*s,c*c,c*s],[-c*s,-s*s,c*s,s*s]])
        dofs=[2*i,2*i+1,2*j,2*j+1]
        for a in range(4):
            for b in range(4):
                K[dofs[a],dofs[b]] += ke[a,b]
    F = np.zeros(12); F[3] = -P; F[7] = -P
    Kff = K[np.ix_(FREE_DOFS,FREE_DOFS)]
    try:
        uf = np.linalg.solve(Kff, F[FREE_DOFS])
    except np.linalg.LinAlgError:
        return np.inf, np.inf, np.inf, None
    U = np.zeros(12); U[FREE_DOFS] = uf
    disp = abs(U[3])
    W = RHO*np.sum(A*MEMBER_LENGTHS)
    return W, disp, disp-DELTA_MAX, None

def limit_state(x):
    CNT.inc("ls_evals")
    E_v = max(x[0], E_MEAN*0.01); P_v = max(x[1], P_MEAN*0.01)
    A_v = np.maximum(x[2:], A_MIN*0.01)
    _, disp, _, _ = fem_10bar(A_v, E=E_v, P=P_v)
    return DELTA_MAX - disp

def form_reliability(A_design):
    CNT.inc("form_calls")
    A_design = np.clip(A_design, A_MIN, A_MAX)
    muy = np.concatenate([[E_MEAN, P_MEAN], A_design])
    sig = COV*muy; dmuy = 1e-4*muy
    X = muy.copy(); Z = (X-muy)/sig; beta = np.linalg.norm(Z)
    eZ, eB, n_it = 100., 100., 0
    for _ in range(100):
        if abs(eZ) <= 1e-3 and abs(eB) <= 1e-3: break
        n_it += 1; CNT.inc("hlrf_iters")
        bp, znp = beta, np.linalg.norm(Z)
        g0 = limit_state(X); G = np.zeros(len(X))
        for i in range(len(X)):
            xp = X.copy(); xp[i] += dmuy[i]
            G[i] = -(limit_state(xp)-g0)/dmuy[i]*sig[i]
        gn = np.linalg.norm(G)
        if gn < 1e-12: break
        beta = beta + g0/gn; Z = (G/gn)*beta; X = muy + sig*Z
        eB = beta-bp; eZ = np.linalg.norm(Z)-znp
    CNT.form_iter_log.append(n_it)
    return float(beta), float(norm.cdf(beta)), float(1.-norm.cdf(beta))

def evaluate(A):
    CNT.inc("eval_calls")
    A = np.atleast_1d(np.asarray(A, dtype=float)).flatten()
    if A.shape[0] != N_MEM: return np.inf, 0.0, False, np.inf
    A = np.clip(A, A_MIN, A_MAX)
    W, disp, cstr, _ = fem_10bar(A)
    _, ps, _ = form_reliability(A)
    return W, ps, (ps >= TARGET_R - 1e-6) and (cstr <= 1e-6), disp

def penalty_fitness(A):
    """Same penalty structure as the original paper code."""
    W, R, _, disp = evaluate(A)
    if R < TARGET_R:
        return W + 1e5 + 1e7*(TARGET_R - R)**2
    if disp > DELTA_MAX:
        return W + 1e5 + 1e5*(disp - DELTA_MAX)
    return W

def init_design(mode, rng):
    if mode == "warm":
        A = np.array([30.0, 0.1, 25.0, 20.0, 0.1, 0.1, 3.0, 25.0, 25.0, 0.1])  # exact paper A0
        A += rng.uniform(-0.5, 0.5, N_MEM)   # small perturbation for seed variability
    else:
        A = rng.uniform(A_MIN, A_MAX, N_MEM)
    return np.clip(A, A_MIN, A_MAX)

# ================================================================
# COORDINATE DESCENT  (identical to Phase 0/1 — applied post-hoc
# to EVERY method identically, per R1-2 / R3-2)
# ================================================================
def coord_descent(A_init, W_init, R_init, max_passes=20):
    A = A_init.copy(); W, R = W_init, R_init
    improved = True
    for _ in range(max_passes):
        if not improved: break
        improved = False
        for i in range(N_MEM):
            for delta in [0.5, 1.0, 2.0, 5.0]:
                A_try = A.copy()
                A_try[i] = max(A_MIN, A[i]-delta)
                if A_try[i] >= A[i]: continue
                W_t, R_t, feas, _ = evaluate(A_try)
                if feas and W_t < W:
                    A, W, R = A_try, W_t, R_t; improved = True; break
    return A, W, R

# ================================================================
# PSO  (budget-parameterized; eval budget stopped via eval_cap)
# ================================================================
def run_pso(seed, init_mode, n_iters, n_particles, eval_cap=None):
    rng = np.random.RandomState(seed)
    n = n_particles
    X0 = init_design(init_mode, rng)
    X = np.tile(X0, (n,1)) + rng.uniform(-3, 3, (n, N_MEM))
    if init_mode == "random":
        X = rng.uniform(A_MIN, A_MAX, (n, N_MEM))
    X = np.clip(X, A_MIN, A_MAX)
    V = rng.uniform(-2, 2, (n, N_MEM))
    fit = np.array([penalty_fitness(X[i]) for i in range(n)])
    pb, pb_fit = X.copy(), fit.copy()
    gi = np.argmin(pb_fit); gb, gb_fit = pb[gi].copy(), pb_fit[gi]
    w, c1, c2 = 0.72, 1.49, 1.49
    conv = []
    for it in range(n_iters):
        if eval_cap and CNT.total("eval_calls") >= eval_cap: break
        r1 = rng.rand(n, N_MEM); r2 = rng.rand(n, N_MEM)
        V = w*V + c1*r1*(pb-X) + c2*r2*(gb-X)
        X = np.clip(X+V, A_MIN, A_MAX)
        for i in range(n):
            f = penalty_fitness(X[i])
            if f < pb_fit[i]:
                pb[i], pb_fit[i] = X[i].copy(), f
                if f < gb_fit: gb, gb_fit = X[i].copy(), f
            if eval_cap and CNT.total("eval_calls") >= eval_cap: break
        W_b, R_b, _, _ = evaluate(gb)
        conv.append({"iter": it, "best_W": W_b, "R": R_b})
    W_f, R_f, feas_f, _ = evaluate(gb)
    return gb, W_f, R_f, feas_f, conv

# ================================================================
# GA — Differential Evolution
# ================================================================
def run_ga(seed, init_mode, maxiter, popsize, eval_cap=None):
    rng = np.random.RandomState(seed)
    calls = [0]
    def obj(A):
        calls[0] += 1
        if eval_cap and calls[0] > eval_cap:
            return 1e12   # effectively stop contributing further improvement
        return penalty_fitness(A)
    bounds = [(A_MIN, A_MAX)]*N_MEM
    x0 = init_design(init_mode, rng) if init_mode == "warm" else None
    kwargs = dict(maxiter=maxiter, popsize=popsize, seed=seed,
                  mutation=(0.5,1.0), recombination=0.7, tol=1e-6, polish=False)
    if x0 is not None:
        init_pop = np.clip(x0 + rng.uniform(-3,3,(popsize*N_MEM, N_MEM)), A_MIN, A_MAX)
        kwargs["init"] = init_pop
    res = differential_evolution(obj, bounds, **kwargs)
    W_f, R_f, feas_f, _ = evaluate(res.x)
    return res.x, W_f, R_f, feas_f, []

# ================================================================
# SLSQP  (same init policy as everyone else now — warm OR random)
# ================================================================
def run_slsqp(seed, init_mode, maxiter, eval_cap=None):
    rng = np.random.RandomState(seed)
    calls = [0]
    def obj(A):
        calls[0] += 1
        W, _, _, _ = fem_10bar(A)
        return W
    def con_r(A):
        _, R, _ = form_reliability(A); return R - TARGET_R
    def con_d(A):
        _, disp, _, _ = fem_10bar(A); return DELTA_MAX - disp
    A0 = init_design(init_mode, rng)
    bounds = [(A_MIN, A_MAX)]*N_MEM
    cons = [{"type":"ineq","fun":con_r}, {"type":"ineq","fun":con_d}]
    res = minimize(obj, A0, method="SLSQP", bounds=bounds, constraints=cons,
                   options={"maxiter": maxiter, "ftol": 1e-6})
    W_f, R_f, feas_f, _ = evaluate(res.x)
    return res.x, W_f, R_f, feas_f, []

# ================================================================
# ONE RUN  (method, init, budget) -> row with before/after CD
# ================================================================
def run_one(method, init_mode, budget, seed):
    global CNT
    CNT = Counters()
    t0 = time.time()

    if budget == "native":
        if method == "PSO":
            A_best, W, R, feas, conv = run_pso(seed, init_mode, NATIVE_ITERS_PSO_GA, NATIVE_PSO_PARTICLES)
        elif method == "GA":
            A_best, W, R, feas, conv = run_ga(seed, init_mode, NATIVE_ITERS_PSO_GA, NATIVE_GA_POPSIZE)
        else:
            A_best, W, R, feas, conv = run_slsqp(seed, init_mode, NATIVE_SLSQP_MAXITER)
    else:  # matched budget ≈ LLM's eval_total range
        if method == "PSO":
            n_part = 15
            n_iter = max(1, MATCHED_EVAL_CAP // n_part)
            A_best, W, R, feas, conv = run_pso(seed, init_mode, n_iter, n_part, eval_cap=MATCHED_EVAL_CAP)
        elif method == "GA":
            popsize = 5
            n_iter = max(1, MATCHED_EVAL_CAP // (popsize*N_MEM))
            A_best, W, R, feas, conv = run_ga(seed, init_mode, n_iter, popsize, eval_cap=MATCHED_EVAL_CAP)
        else:
            A_best, W, R, feas, conv = run_slsqp(seed, init_mode, maxiter=30, eval_cap=MATCHED_EVAL_CAP)

    W_search, R_search, feas_search = W, R, feas
    eval_search = CNT.total("eval_calls")

    CNT.set_phase("cd")
    W_cd, R_cd = W_search, R_search
    if feas_search and W_search < np.inf:
        A_cd, W_cd2, R_cd2 = coord_descent(A_best, W_search, R_search)
        if W_cd2 < W_search and R_cd2 >= TARGET_R:
            W_cd, R_cd = W_cd2, R_cd2

    elapsed = time.time()-t0
    return {
        "method": method, "init": init_mode, "budget": budget, "seed": seed,
        "W_search": W_search if feas_search else None,
        "W_final": W_cd if feas_search else None,
        "R_final": R_cd, "feasible": bool(feas_search),
        "CD_delta": (W_search - W_cd) if feas_search else 0.0,
        "eval_search": eval_search, "eval_total": CNT.total("eval_calls"),
        "fem_total": CNT.total("fem_solves"), "time_s": round(elapsed,2),
    }

# ================================================================
# DRIVER
# ================================================================
def append_csv(fname, rows, fieldnames):
    new = not os.path.exists(fname)
    with open(fname, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

METHODS = ["PSO", "GA", "SLSQP"]
INITS   = ["warm", "random"]
BUDGETS = ["native", "matched"]

def main():
    combos = [(m,i,b) for m in METHODS for i in INITS for b in BUDGETS]
    if len(sys.argv) > 1:
        want = set(sys.argv[1:])
        combos = [c for c in combos if f"{c[0]}_{c[1]}_{c[2]}" in want or c[0] in want]
    print(f"Running {len(combos)} (method,init,budget) combos")
    all_new = []
    done_seeds = {}
    if os.path.exists("phase3_perrun_10bar.csv"):
        existing = list(csv.DictReader(open("phase3_perrun_10bar.csv")))
        for r in existing:
            key = (r["method"], r["init"], r["budget"])
            done_seeds.setdefault(key, set()).add(int(r["seed"]))

    for (method, init, budget) in combos:
        name = f"{method}_{init}_{budget}"
        seeds_here = SEEDS_NATIVE if budget == "native" else SEEDS
        already = done_seeds.get((method, init, budget), set())
        remaining = [s for s in seeds_here if s not in already]
        if not remaining:
            print(f"\n=== {name}: all {len(seeds_here)} seeds already done, skipping ===")
            continue
        print(f"\n=== {name} ({len(remaining)}/{len(seeds_here)} seeds remaining) ===")
        fieldnames = None
        for s in remaining:
            r = run_one(method, init, budget, s)
            if fieldnames is None: fieldnames = list(r.keys())
            append_csv("phase3_perrun_10bar.csv", [r], fieldnames)
            wf = r["W_final"]
            print(f"  seed {s:2d}: W_search={r['W_search']}  W_final={wf}  "
                  f"R={r['R_final']:.4f}  eval={r['eval_total']}  t={r['time_s']}s", flush=True)
        print(f"  ✓ {name} done (appended incrementally)", flush=True)

    # ---- rebuild full summary from cumulative CSV ----
    import numpy as _np
    all_rows = list(csv.DictReader(open("phase3_perrun_10bar.csv")))
    from collections import defaultdict
    groups = defaultdict(list)
    for r in all_rows:
        groups[(r["method"], r["init"], r["budget"])].append(r)

    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Summary"
    ws.append(["method","init","budget","n","feasible_rate",
               "W_search_mean","W_final_mean","W_final_std","W_final_min",
               "CD_delta_mean","eval_search_mean","eval_total_mean"])
    for (method,init,budget), rs in groups.items():
        wf = _np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        ws_ = _np.array([float(r["W_search"]) for r in rs if r["W_search"] not in ("","None")])
        cdd = _np.array([float(r["CD_delta"]) for r in rs])
        ev  = _np.array([float(r["eval_total"]) for r in rs])
        evs = _np.array([float(r["eval_search"]) for r in rs])
        feas = _np.mean([r["feasible"]=="True" for r in rs])
        ws.append([method, init, budget, len(rs), feas,
                   float(ws_.mean()) if len(ws_) else None,
                   float(wf.mean()) if len(wf) else None,
                   float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,
                   float(cdd.mean()), float(evs.mean()), float(ev.mean())])
    ws.append([]); ws.append(["timestamp", datetime.datetime.now().isoformat()])
    ws.append(["note","N_SEEDS=20; native=paper's original budget; matched=eval_total capped ~300 to match LLM"])

    ws2 = wb.create_sheet("PerRun")
    keys2 = list(all_rows[0].keys()); ws2.append(keys2)
    for r in all_rows: ws2.append([r[k] for k in keys2])

    fname = "phase3_10bar_benchmark.xlsx"
    wb.save(fname)
    print(f"\n✓ Saved: {fname}")
    try:
        from google.colab import files as _colab_files
        _colab_files.download(fname)
    except Exception:
        pass

if __name__ == "__main__":
    main()
