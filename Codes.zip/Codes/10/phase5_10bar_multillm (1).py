# ============================================================
#  PHASE 5 — MULTI-LLM COMPARISON  —  10-bar truss

#    - OpenAI  GPT-4o-mini
#    - Anthropic Claude Haiku 4.5
#
#  Two configurations are reused from Phase 1 (the two that
#  mattered most for the paper's central claim):
#    "warm"  = FULL prompt (structural knowledge + fixed
#              "known good reference" anchor), warm-start init
#              = the paper's ORIGINAL configuration
#    "rand"  = FEW-SHOT prompt (worked examples, NO fixed
#              anchor), random-start init
#              = the configuration where DeepSeek showed its
#                clearest, statistically significant advantage
#
#  20 seeds each, per provider, per config = 80 runs total.
#

import numpy as np
from scipy.stats import norm
import requests, time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

# ================================================================
# API KEYS  — fill these in before running
# ================================================================
OPENAI_API_KEY    = "YOUR_OPENAI_API_KEY_HERE"
ANTHROPIC_API_KEY = "YOUR_ANTHROPIC_API_KEY_HERE"

OPENAI_MODEL    = "gpt-4o-mini"
ANTHROPIC_MODEL = "claude-haiku-4-5-20251001"

# ================================================================
# CONFIG  (identical problem constants to every previous phase)
# ================================================================
E_MEAN, P_MEAN, RHO   = 1.0e7, 1.0e5, 0.1
COV, DELTA_MAX        = 0.05, 2.0
TARGET_R              = 0.99
A_MIN, A_MAX, N_MEM   = 0.1, 40.0, 10
STAGNATION_LIMIT      = 5
MAX_ITER_LLM          = 150

N_SEEDS = 20
SEEDS   = list(range(1, N_SEEDS + 1))

OUT_CSV  = "phase5_perrun_10bar.csv"
OUT_XLSX = "phase5_10bar_multillm.xlsx"

# ================================================================
# COUNTERS  (identical scheme to every previous phase)
# ================================================================
class Counters:
    FIELDS = ["fem_solves", "ls_evals", "form_calls", "hlrf_iters",
              "eval_calls", "llm_calls"]
    def __init__(self):
        self.phase = "init"; self.data = {}; self.form_iter_log = []
    def _d(self):
        if self.phase not in self.data:
            self.data[self.phase] = {f: 0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self, f, n=1): self._d()[f] += n
    def set_phase(self, p): self.phase = p; self._d()
    def total(self, f): return sum(d[f] for d in self.data.values())

CNT = Counters()

# ================================================================
# GEOMETRY + FEM + FORM + EVALUATE  (identical to every phase)
# ================================================================
NODES = np.array([[720.,360.],[720.,0.],[360.,360.],
                  [360.,0.],[0.,360.],[0.,0.]])
MEMBERS = np.array([[4,2],[2,0],[5,3],[3,1],[3,2],
                    [0,1],[3,4],[2,5],[1,2],[0,3]])
FIXED_DOFS = [8,9,10,11]
FREE_DOFS  = [d for d in range(12) if d not in FIXED_DOFS]
MEMBER_LENGTHS = np.array([np.linalg.norm(NODES[j]-NODES[i]) for i,j in MEMBERS])

def fem_10bar(A, E=E_MEAN, P=P_MEAN):
    CNT.inc("fem_solves")
    A = np.asarray(A, dtype=float)
    K = np.zeros((12,12))
    for m,(i,j) in enumerate(MEMBERS):
        L = MEMBER_LENGTHS[m]
        c = (NODES[j,0]-NODES[i,0])/L; s = (NODES[j,1]-NODES[i,1])/L
        k = E*A[m]/L
        ke = k*np.array([[c*c,c*s,-c*c,-c*s],[c*s,s*s,-c*s,-s*s],
                         [-c*c,-c*s,c*c,c*s],[-c*s,-s*s,c*s,s*s]])
        dofs=[2*i,2*i+1,2*j,2*j+1]
        for a in range(4):
            for b in range(4):
                K[dofs[a],dofs[b]] += ke[a,b]
    F = np.zeros(12); F[3] = -P; F[7] = -P
    Kff = K[np.ix_(FREE_DOFS,FREE_DOFS)]
    try:
        uf = np.linalg.solve(Kff, F[FREE_DOFS])
    except np.linalg.LinAlgError:
        return np.inf, np.inf, np.inf, None
    U = np.zeros(12); U[FREE_DOFS] = uf
    disp = abs(U[3])
    W = RHO*np.sum(A*MEMBER_LENGTHS)
    return W, disp, disp-DELTA_MAX, None

def limit_state(x):
    CNT.inc("ls_evals")
    E_v = max(x[0], E_MEAN*0.01); P_v = max(x[1], P_MEAN*0.01)
    A_v = np.maximum(x[2:], A_MIN*0.01)
    _, disp, _, _ = fem_10bar(A_v, E=E_v, P=P_v)
    return DELTA_MAX - disp

def form_reliability(A_design):
    CNT.inc("form_calls")
    A_design = np.clip(A_design, A_MIN, A_MAX)
    muy = np.concatenate([[E_MEAN, P_MEAN], A_design])
    sig = COV*muy; dmuy = 1e-4*muy
    X = muy.copy(); Z = (X-muy)/sig; beta = np.linalg.norm(Z)
    eZ, eB, n_it = 100., 100., 0
    for _ in range(100):
        if abs(eZ) <= 1e-3 and abs(eB) <= 1e-3: break
        n_it += 1; CNT.inc("hlrf_iters")
        bp, znp = beta, np.linalg.norm(Z)
        g0 = limit_state(X); G = np.zeros(len(X))
        for i in range(len(X)):
            xp = X.copy(); xp[i] += dmuy[i]
            G[i] = -(limit_state(xp)-g0)/dmuy[i]*sig[i]
        gn = np.linalg.norm(G)
        if gn < 1e-12: break
        beta = beta + g0/gn; Z = (G/gn)*beta; X = muy + sig*Z
        eB = beta-bp; eZ = np.linalg.norm(Z)-znp
    CNT.form_iter_log.append(n_it)
    return float(beta), float(norm.cdf(beta)), float(1.-norm.cdf(beta))

def evaluate(A):
    CNT.inc("eval_calls")
    A = np.atleast_1d(np.asarray(A, dtype=float)).flatten()
    if A.shape[0] != N_MEM: return np.inf, 0.0, False, np.inf
    A = np.clip(A, A_MIN, A_MAX)
    W, disp, cstr, _ = fem_10bar(A)
    _, ps, _ = form_reliability(A)
    return W, ps, (ps >= TARGET_R - 1e-6) and (cstr <= 1e-6), disp

# ================================================================
# PROMPTS  (identical text to Phase 1 — FULL = paper's original
# with fixed anchor; FEWSHOT = worked examples, no fixed anchor)
# ================================================================
FULL_PROMPT_TMPL = """You are an expert in structural reliability optimization.

PROBLEM: 10-bar truss RBDO — minimize weight, keep Reliability >= {tr}
  A[1]..A[10]: cross-sectional areas (in²), bounds [{amin}, {amax}]

STRUCTURAL INFO (critical for good solutions):
  - Members 1,3,4 (A[0],A[2],A[3]): horizontal top/bottom chords → CRITICAL
  - Members 8,9 (A[7],A[8]): diagonal tension members → CRITICAL
  - Members 2,5,6 (A[1],A[4],A[5]): near-zero force → keep at {amin}
  - Members 7,10 (A[6],A[9]): secondary diagonals → moderate

KNOWN GOOD REFERENCE: W≈6076 lb at A≈[39,0.1,27,19,0.1,0.1,3.2,28,27,0.1]

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  Displacement= {disp:.4f} in (limit=2.0)
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE applied ~{stag} times.

Rules:
  1. If reliability < {tr}: increase A[0],A[2],A[3],A[7],A[8] proportionally
     to violation; keep A[1],A[4],A[5] at {amin}.
  2. If reliability >= {tr} and weight > 6500: reduce A[0],A[2],A[3],A[7],A[8]
     by 1-3%; set A[1],A[4],A[5] = {amin}.
  3. If reliability >= {tr} and weight <= 6500: reduce the LARGEST area by
     1-2% per iteration; revert if reliability drops below 0.9950.

Use step sizes proportional to how far from target you are.

Return ONLY this function, no extra text, no markdown fences:

def update_operator(A, reliability, weight, disp):
    import numpy as np
    A_new = A.copy()
    # your adaptive logic
    return np.clip(A_new, {amin}, {amax})
"""

FEWSHOT_PROMPT_TMPL = """You are an expert in structural reliability optimization.

PROBLEM: 10-bar truss RBDO — minimize weight, keep Reliability >= {tr}
  A[1]..A[10]: cross-sectional areas (in²), bounds [{amin}, {amax}]

STRUCTURAL INFO (critical for good solutions):
  - Members 1,3,4 (A[0],A[2],A[3]): horizontal top/bottom chords → CRITICAL
  - Members 8,9 (A[7],A[8]): diagonal tension members → CRITICAL
  - Members 2,5,6 (A[1],A[4],A[5]): near-zero force → keep at {amin}
  - Members 7,10 (A[6],A[9]): secondary diagonals → moderate

WORKED EXAMPLES (illustrating good update behaviour from DIFFERENT starting
configurations — use these to learn the PATTERN of good moves, not a fixed
target design; the correct final design depends on where you currently are):

Example A — far from feasible, critical members too thin:
  state:  A=[8,15,6,7,20,18,5,9,8,22]  R=0.41  (infeasible, need >= {tr})
  good update: increase A[0],A[2],A[3],A[7],A[8] by ~40-60% each (they are
    under-sized relative to the load path); decrease A[1],A[4],A[5] toward
    {amin} since they carry negligible force; leave A[6],A[9] roughly as is.
  result: R rose to 0.87 (still infeasible but much closer), weight rose
    moderately — this is an acceptable intermediate trade.

Example B — feasible but overweight, redundant members oversized:
  state:  A=[35,12,30,28,15,10,20,32,29,14]  R=0.996  weight=9400 lb
  good update: reduce A[1],A[4],A[5],A[6],A[9] sharply toward {amin} (they
    are not on the critical load path and are wasting weight); reduce
    A[0],A[2],A[3],A[7],A[8] only slightly (2-4%) since they are close to
    the reliability boundary.
  result: weight dropped to ~6900 lb, R stayed above {tr}.

Example C — feasible and near-optimal, fine-tuning phase:
  state:  A=[24,0.3,18,15,0.2,0.2,4,19,18,0.3]  R=0.9915  weight=6350 lb
  good update: identify the single largest-area critical member and reduce
    it by 1-2%; re-check reliability; if it drops below 0.9950 revert that
    member and try a different one. Do not change near-zero members further.
  result: small, safe weight reductions of a few percent per iteration.

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  Displacement= {disp:.4f} in (limit=2.0)
  {areas}

RECENT HISTORY
{hist}

TASK: Using the PATTERN from the worked examples above (not their specific
numbers — your current state is different from all three), write an
adaptive UPDATE RULE applied ~{stag} times that moves the CURRENT design
toward lower weight while keeping reliability >= {tr}.

Return ONLY this function, no extra text, no markdown fences:

def update_operator(A, reliability, weight, disp):
    import numpy as np
    A_new = A.copy()
    # your adaptive logic
    return np.clip(A_new, {amin}, {amax})
"""

def init_design(mode, rng):
    if mode == "warm":
        A = np.array([30.0, 0.1, 25.0, 20.0, 0.1, 0.1, 3.0, 25.0, 25.0, 0.1])
        A += rng.uniform(-0.5, 0.5, N_MEM)
    else:
        A = rng.uniform(A_MIN, A_MAX, N_MEM)
    return np.clip(A, A_MIN, A_MAX)

# ================================================================
# COORDINATE DESCENT  (identical to every previous phase)
# ================================================================
def coord_descent(A_init, W_init, R_init, max_passes=20):
    A = A_init.copy(); W, R = W_init, R_init
    improved = True
    for _ in range(max_passes):
        if not improved: break
        improved = False
        for i in range(N_MEM):
            for delta in [0.5, 1.0, 2.0, 5.0]:
                A_try = A.copy()
                A_try[i] = max(A_MIN, A[i]-delta)
                if A_try[i] >= A[i]: continue
                W_t, R_t, feas, _ = evaluate(A_try)
                if feas and W_t < W:
                    A, W, R = A_try, W_t, R_t; improved = True; break
    return A, W, R

# ================================================================
# MULTI-PROVIDER LLM CALLER
# ================================================================
def build_prompt(kind, A, R, W, disp, it, history):
    hist = "\n".join(f"  iter={h['iter']:3d}  W={h['W']:9.1f}  R={h['R']:.4f}  "
                     f"feasible={h['feasible']}" for h in history[-6:])
    areas = ", ".join(f"A[{i+1}]={v:.3f}" for i,v in enumerate(A))
    tmpl = FULL_PROMPT_TMPL if kind == "warm" else FEWSHOT_PROMPT_TMPL
    return tmpl.format(tr=TARGET_R, amin=A_MIN, amax=A_MAX, it=it,
                       W=W, R=R, disp=disp, areas=areas, hist=hist,
                       stag=STAGNATION_LIMIT)

def extract_code(text):
    lines, inside = [], False
    for line in text.splitlines():
        clean = line.replace("```python", "").replace("```", "")
        if clean.strip().startswith("def update_operator"): inside = True
        if inside: lines.append(clean)
    return "\n".join(lines) if lines else None

def _post_with_retry(url, headers, json_body, timeout=45, max_retries=4):
    """Retry on transient server errors (e.g. Anthropic 529 'overloaded',
    or any 5xx) with exponential backoff. Does NOT retry on 4xx (auth/
    bad-request errors — those won't fix themselves)."""
    last_err = None
    for attempt in range(max_retries):
        try:
            r = requests.post(url, headers=headers, json=json_body, timeout=timeout)
            if r.status_code >= 500:
                raise requests.exceptions.HTTPError(
                    f"{r.status_code} Server Error", response=r)
            r.raise_for_status()
            return r
        except Exception as e:
            last_err = e
            if attempt < max_retries - 1:
                wait = (2 ** attempt) + np.random.uniform(0, 1)
                print(f"    ⚠ retryable error ({e}); retrying in {wait:.1f}s "
                      f"[{attempt+1}/{max_retries}]")
                time.sleep(wait)
    raise last_err

def call_openai(prompt):
    r = _post_with_retry(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {OPENAI_API_KEY}",
                 "Content-Type": "application/json"},
        json_body={"model": OPENAI_MODEL,
              "messages": [{"role": "user", "content": prompt}],
              "temperature": 0.7, "max_tokens": 600})
    content = r.json()["choices"][0]["message"]["content"]
    return extract_code(content)

def call_anthropic(prompt):
    r = _post_with_retry(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": ANTHROPIC_API_KEY,
                 "anthropic-version": "2023-06-01",
                 "Content-Type": "application/json"},
        json_body={"model": ANTHROPIC_MODEL, "max_tokens": 600,
              "temperature": 0.7,
              "messages": [{"role": "user", "content": prompt}]})
    blocks = r.json().get("content", [])
    text = "".join(b.get("text","") for b in blocks if b.get("type") == "text")
    return extract_code(text)

def call_llm(provider, prompt, fail_counter=None):
    CNT.inc("llm_calls")
    try:
        if provider == "openai":
            code = call_openai(prompt)
        elif provider == "anthropic":
            code = call_anthropic(prompt)
        else:
            raise ValueError(provider)
        if code is None and fail_counter is not None:
            fail_counter[0] += 1
        return code
    except Exception as e:
        print(f"    ⚠ {provider} API error after retries: {e}")
        if fail_counter is not None:
            fail_counter[0] += 1
        return None

def apply_operator(code, A, R, W, disp):
    if code is None:
        f = 1.05 if R < TARGET_R else 0.97
        return np.clip(A*f, A_MIN, A_MAX)
    try:
        ns = {"np": np, "numpy": np, "N_MEM": N_MEM, "A_MIN": A_MIN, "A_MAX": A_MAX}
        exec(code, ns)
        raw = ns["update_operator"](A.copy(), float(R), float(W), float(disp))
        A_new = np.atleast_1d(np.asarray(raw, dtype=float)).flatten()
        if A_new.shape[0] != N_MEM: raise ValueError("shape")
        return np.clip(A_new, A_MIN, A_MAX)
    except Exception:
        f = 1.05 if R < TARGET_R else 0.97
        return np.clip(A*f, A_MIN, A_MAX)

# ================================================================
# ONE FULL RUN  (provider, config="warm"|"rand", seed)
# ================================================================
def run_one(provider, config, seed):
    global CNT
    CNT = Counters()
    t0 = time.time()
    rng = np.random.RandomState(seed)
    init_mode = "warm" if config == "warm" else "random"

    CNT.set_phase("init")
    A = init_design(init_mode, rng)
    W, R, feasible, disp = evaluate(A)

    best_A, best_W, best_R = A.copy(), (W if feasible else np.inf), R
    history = [{"iter":0,"W":W,"R":R,"disp":disp,"feasible":feasible}]
    stag, prev_bw = 0, best_W

    CNT.set_phase("llm_loop")
    fail_counter = [0]
    prompt = build_prompt(config, A, R, W, disp, 0, history)
    code = call_llm(provider, prompt, fail_counter)

    for it in range(1, MAX_ITER_LLM + 1):
        try:
            A_new = apply_operator(code, A, R, W, disp)
            W_n, R_n, feas_n, disp_n = evaluate(A_new)
        except Exception:
            A_new, W_n, R_n, feas_n, disp_n = A.copy(), W, R, feasible, disp
        accept = ((not feasible and R_n > R) or
                  (feasible and feas_n and W_n < W))
        if accept:
            A, W, R, disp, feasible = A_new, W_n, R_n, disp_n, feas_n
            if feas_n and W_n < best_W:
                best_A, best_W, best_R = A_new.copy(), W_n, R_n
        history.append({"iter":it,"W":W,"R":R,"disp":disp,"feasible":feasible})
        stag = (stag+1) if abs(best_W - prev_bw) < 0.5 else 0
        prev_bw = best_W
        if stag >= STAGNATION_LIMIT:
            prompt = build_prompt(config, A, R, W, disp, it, history)
            code = call_llm(provider, prompt, fail_counter)
            stag = 0

    W_loop, R_loop = best_W, best_R
    eval_loop = CNT.total("eval_calls")

    CNT.set_phase("cd")
    W_cd, R_cd = W_loop, R_loop
    if best_W < np.inf:
        A_cd, W_cd2, R_cd2 = coord_descent(best_A, best_W, best_R)
        if W_cd2 < best_W and R_cd2 >= TARGET_R:
            W_cd, R_cd = W_cd2, R_cd2

    elapsed = time.time() - t0
    feasible_final = bool(R_cd >= TARGET_R - 1e-6 and W_cd < np.inf)
    return {
        "provider": provider, "config": config, "seed": seed,
        "W_loop_end": W_loop if W_loop < np.inf else None,
        "W_final": W_cd if feasible_final else None,
        "R_final": R_cd, "feasible": feasible_final,
        "CD_delta": (W_loop - W_cd) if feasible_final else 0.0,
        "eval_loop": eval_loop, "eval_total": CNT.total("eval_calls"),
        "llm_calls": CNT.total("llm_calls"),
        "llm_fallback_count": fail_counter[0],
        "time_s": round(elapsed, 2),
    }

# ================================================================
# DRIVER  (resumable: skips seeds already present in the CSV)
# ================================================================
def append_csv(fname, rows, fieldnames):
    if not os.path.exists(fname):
        with open(fname, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            for r in rows: w.writerow(r)
        return
    # file exists — check for a schema change (e.g. new llm_fallback_count field)
    with open(fname, newline="") as f:
        existing_header = next(csv.reader(f))
    if list(existing_header) == list(fieldnames):
        with open(fname, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            for r in rows: w.writerow(r)
        return
    # schema changed: migrate old rows (missing new columns get "") then re-append
    old_rows = list(csv.DictReader(open(fname)))
    with open(fname, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in old_rows:
            for k in fieldnames:
                r.setdefault(k, "")
            w.writerow({k: r.get(k, "") for k in fieldnames})
        for r in rows:
            w.writerow(r)
    print(f"  (note: {fname} schema updated — old rows kept, padded with blanks for new columns)")

COMBOS = [("openai","warm"), ("openai","rand"),
          ("anthropic","warm"), ("anthropic","rand")]

def rebuild_excel():
    if not os.path.exists(OUT_CSV):
        print("No data yet — nothing to save."); return
    rows = list(csv.DictReader(open(OUT_CSV)))
    if not rows:
        print("No data yet — nothing to save."); return
    from collections import defaultdict
    groups = defaultdict(list)
    for r in rows: groups[(r["provider"], r["config"])].append(r)

    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Summary"
    ws.append(["provider","config","n","feasible_rate",
               "W_final_mean","W_final_std","W_final_min","W_final_max",
               "CD_delta_mean","eval_total_mean","llm_calls_mean"])
    for (provider, config), rs in groups.items():
        wf = np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd = np.array([float(r["CD_delta"]) for r in rs])
        ev  = np.array([float(r["eval_total"]) for r in rs])
        lc  = np.array([float(r["llm_calls"]) for r in rs])
        feas = np.mean([r["feasible"]=="True" for r in rs])
        ws.append([provider, config, len(rs), feas,
                   float(wf.mean()) if len(wf) else None,
                   float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,
                   float(wf.max()) if len(wf) else None,
                   float(cdd.mean()), float(ev.mean()), float(lc.mean())])
    ws.append([]); ws.append(["timestamp", datetime.datetime.now().isoformat()])
    ws.append(["note", "warm = full prompt+anchor, warm-start init (paper's original config). "
                       "rand = few-shot prompt, random-start init (config where DeepSeek showed "
                       "its clearest advantage in Phase 1). Directly comparable to DeepSeek numbers "
                       "in phase1_perrun_llm_consolidated.csv (variants LLM+CD_warm / LLMfewshot+CD_rand)."])

    ws2 = wb.create_sheet("PerRun")
    keys2 = list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])

    wb.save(OUT_XLSX)
    print(f"✓ Saved: {OUT_XLSX}  ({len(rows)} total runs)")
    try:
        from google.colab import files as _colab_files
        _colab_files.download(OUT_XLSX)
    except Exception:
        pass

def main():
    combos = COMBOS
    if len(sys.argv) > 1:
        want = set(sys.argv[1:])
        combos = [c for c in combos if f"{c[0]}_{c[1]}" in want]

    done_seeds = {}
    if os.path.exists(OUT_CSV):
        existing = list(csv.DictReader(open(OUT_CSV)))
        for r in existing:
            key = (r["provider"], r["config"])
            done_seeds.setdefault(key, set()).add(int(r["seed"]))

    for (provider, config) in combos:
        name = f"{provider}_{config}"
        already = done_seeds.get((provider, config), set())
        remaining = [s for s in SEEDS if s not in already]
        if not remaining:
            print(f"\n=== {name}: all {len(SEEDS)} seeds already done, skipping ===")
            continue
        print(f"\n=== {name} ({len(remaining)}/{len(SEEDS)} seeds remaining) ===")
        fieldnames = None
        for s in remaining:
            r = run_one(provider, config, s)
            if fieldnames is None: fieldnames = list(r.keys())
            append_csv(OUT_CSV, [r], fieldnames)
            wf = r["W_final"]
            print(f"  seed {s:2d}: W_loop={r['W_loop_end']}  W_final={wf}  "
                  f"R={r['R_final']:.4f}  eval={r['eval_total']}  "
                  f"llm={r['llm_calls']}  t={r['time_s']}s", flush=True)
            rebuild_excel()   # save + auto-download after EVERY seed — crash-safe

    rebuild_excel()

if __name__ == "__main__":
    main()
