# ============================================================
#  PHASE 6b — DETERMINISM DIAGNOSTIC  —  10-bar truss (DeepSeek)
#  Follow-up to Phase 6: is run-to-run variability under an
#  IDENTICAL seed caused by the LLM's own sampling temperature,
#  or by something else (API non-determinism, floating point, etc)?
#
#  Design: take 5 seeds from the original random-start P0 set.
#  For each seed, run the FULL pipeline TWICE — once at
#  temperature=0.0, once at temperature=0.7 (the original
#  setting) — two independent repeats each. If temperature=0
#  makes repeats of the SAME seed nearly identical, temperature
#  is confirmed as the main driver of run-to-run variability.
#  If repeats still differ substantially even at temperature=0,
#  some other source of non-determinism is at play (and worth
#  reporting honestly).
#
#  5 seeds × 2 temperatures × 2 repeats = 20 runs total. Cheap.
#
#  RESULTS SAVED INCREMENTALLY AFTER EVERY RUN — crash-safe,
#  resumable exactly like every previous phase.
#
#  Output: phase6b_10bar_determinism.xlsx
#    Sheets: Summary | PerRun
# ============================================================

import numpy as np
from scipy.stats import norm
import requests, time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

# ================================================================
# API KEY
# ================================================================
API_KEY      = "YOUR_DEEPSEEK_API_KEY_HERE"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"

# ================================================================
# CONFIG
# ================================================================
E_MEAN, P_MEAN, RHO   = 1.0e7, 1.0e5, 0.1
COV, DELTA_MAX        = 0.05, 2.0
TARGET_R              = 0.99
A_MIN, A_MAX, N_MEM   = 0.1, 40.0, 10
STAGNATION_LIMIT      = 5
MAX_ITER_LLM          = 150

TEST_SEEDS = [1, 2, 3, 4, 5]     # subset of the original 20 seeds
TEMPS      = [0.0, 0.7]
REPEATS    = [1, 2]               # run each (seed, temp) combo twice

OUT_CSV  = "phase6b_perrun_10bar.csv"
OUT_XLSX = "phase6b_10bar_determinism.xlsx"

# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS = ["fem_solves", "ls_evals", "form_calls", "hlrf_iters",
              "eval_calls", "llm_calls"]
    def __init__(self):
        self.phase = "init"; self.data = {}; self.form_iter_log = []
    def _d(self):
        if self.phase not in self.data:
            self.data[self.phase] = {f: 0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self, f, n=1): self._d()[f] += n
    def set_phase(self, p): self.phase = p; self._d()
    def total(self, f): return sum(d[f] for d in self.data.values())

CNT = Counters()

# ================================================================
# GEOMETRY + FEM + FORM + EVALUATE  (identical to every phase)
# ================================================================
NODES = np.array([[720.,360.],[720.,0.],[360.,360.],
                  [360.,0.],[0.,360.],[0.,0.]])
MEMBERS = np.array([[4,2],[2,0],[5,3],[3,1],[3,2],
                    [0,1],[3,4],[2,5],[1,2],[0,3]])
FIXED_DOFS = [8,9,10,11]
FREE_DOFS  = [d for d in range(12) if d not in FIXED_DOFS]
MEMBER_LENGTHS = np.array([np.linalg.norm(NODES[j]-NODES[i]) for i,j in MEMBERS])

def fem_10bar(A, E=E_MEAN, P=P_MEAN):
    CNT.inc("fem_solves")
    A = np.asarray(A, dtype=float)
    K = np.zeros((12,12))
    for m,(i,j) in enumerate(MEMBERS):
        L = MEMBER_LENGTHS[m]
        c = (NODES[j,0]-NODES[i,0])/L; s = (NODES[j,1]-NODES[i,1])/L
        k = E*A[m]/L
        ke = k*np.array([[c*c,c*s,-c*c,-c*s],[c*s,s*s,-c*s,-s*s],
                         [-c*c,-c*s,c*c,c*s],[-c*s,-s*s,c*s,s*s]])
        dofs=[2*i,2*i+1,2*j,2*j+1]
        for a in range(4):
            for b in range(4):
                K[dofs[a],dofs[b]] += ke[a,b]
    F = np.zeros(12); F[3] = -P; F[7] = -P
    Kff = K[np.ix_(FREE_DOFS,FREE_DOFS)]
    try:
        uf = np.linalg.solve(Kff, F[FREE_DOFS])
    except np.linalg.LinAlgError:
        return np.inf, np.inf, np.inf, None
    U = np.zeros(12); U[FREE_DOFS] = uf
    disp = abs(U[3])
    W = RHO*np.sum(A*MEMBER_LENGTHS)
    return W, disp, disp-DELTA_MAX, None

def limit_state(x):
    CNT.inc("ls_evals")
    E_v = max(x[0], E_MEAN*0.01); P_v = max(x[1], P_MEAN*0.01)
    A_v = np.maximum(x[2:], A_MIN*0.01)
    _, disp, _, _ = fem_10bar(A_v, E=E_v, P=P_v)
    return DELTA_MAX - disp

def form_reliability(A_design):
    CNT.inc("form_calls")
    A_design = np.clip(A_design, A_MIN, A_MAX)
    muy = np.concatenate([[E_MEAN, P_MEAN], A_design])
    sig = COV*muy; dmuy = 1e-4*muy
    X = muy.copy(); Z = (X-muy)/sig; beta = np.linalg.norm(Z)
    eZ, eB, n_it = 100., 100., 0
    for _ in range(100):
        if abs(eZ) <= 1e-3 and abs(eB) <= 1e-3: break
        n_it += 1; CNT.inc("hlrf_iters")
        bp, znp = beta, np.linalg.norm(Z)
        g0 = limit_state(X); G = np.zeros(len(X))
        for i in range(len(X)):
            xp = X.copy(); xp[i] += dmuy[i]
            G[i] = -(limit_state(xp)-g0)/dmuy[i]*sig[i]
        gn = np.linalg.norm(G)
        if gn < 1e-12: break
        beta = beta + g0/gn; Z = (G/gn)*beta; X = muy + sig*Z
        eB = beta-bp; eZ = np.linalg.norm(Z)-znp
    CNT.form_iter_log.append(n_it)
    return float(beta), float(norm.cdf(beta)), float(1.-norm.cdf(beta))

def evaluate(A):
    CNT.inc("eval_calls")
    A = np.atleast_1d(np.asarray(A, dtype=float)).flatten()
    if A.shape[0] != N_MEM: return np.inf, 0.0, False, np.inf
    A = np.clip(A, A_MIN, A_MAX)
    W, disp, cstr, _ = fem_10bar(A)
    _, ps, _ = form_reliability(A)
    return W, ps, (ps >= TARGET_R - 1e-6) and (cstr <= 1e-6), disp

def init_design(rng):
    return np.clip(rng.uniform(A_MIN, A_MAX, N_MEM), A_MIN, A_MAX)

# ================================================================
# COORDINATE DESCENT
# ================================================================
def coord_descent(A_init, W_init, R_init, max_passes=20):
    A = A_init.copy(); W, R = W_init, R_init
    improved = True
    for _ in range(max_passes):
        if not improved: break
        improved = False
        for i in range(N_MEM):
            for delta in [0.5, 1.0, 2.0, 5.0]:
                A_try = A.copy()
                A_try[i] = max(A_MIN, A[i]-delta)
                if A_try[i] >= A[i]: continue
                W_t, R_t, feas, _ = evaluate(A_try)
                if feas and W_t < W:
                    A, W, R = A_try, W_t, R_t; improved = True; break
    return A, W, R

# ================================================================
# P0 PROMPT (exact original few-shot wording — unchanged)
# ================================================================
P0_TMPL = """You are an expert in structural reliability optimization.

PROBLEM: 10-bar truss RBDO — minimize weight, keep Reliability >= {tr}
  A[1]..A[10]: cross-sectional areas (in²), bounds [{amin}, {amax}]

STRUCTURAL INFO (critical for good solutions):
  - Members 1,3,4 (A[0],A[2],A[3]): horizontal top/bottom chords → CRITICAL
  - Members 8,9 (A[7],A[8]): diagonal tension members → CRITICAL
  - Members 2,5,6 (A[1],A[4],A[5]): near-zero force → keep at {amin}
  - Members 7,10 (A[6],A[9]): secondary diagonals → moderate

WORKED EXAMPLES (illustrating good update behaviour from DIFFERENT starting
configurations — use these to learn the PATTERN of good moves, not a fixed
target design; the correct final design depends on where you currently are):

Example A — far from feasible, critical members too thin:
  state:  A=[8,15,6,7,20,18,5,9,8,22]  R=0.41  (infeasible, need >= {tr})
  good update: increase A[0],A[2],A[3],A[7],A[8] by ~40-60% each (they are
    under-sized relative to the load path); decrease A[1],A[4],A[5] toward
    {amin} since they carry negligible force; leave A[6],A[9] roughly as is.
  result: R rose to 0.87 (still infeasible but much closer), weight rose
    moderately — this is an acceptable intermediate trade.

Example B — feasible but overweight, redundant members oversized:
  state:  A=[35,12,30,28,15,10,20,32,29,14]  R=0.996  weight=9400 lb
  good update: reduce A[1],A[4],A[5],A[6],A[9] sharply toward {amin} (they
    are not on the critical load path and are wasting weight); reduce
    A[0],A[2],A[3],A[7],A[8] only slightly (2-4%) since they are close to
    the reliability boundary.
  result: weight dropped to ~6900 lb, R stayed above {tr}.

Example C — feasible and near-optimal, fine-tuning phase:
  state:  A=[24,0.3,18,15,0.2,0.2,4,19,18,0.3]  R=0.9915  weight=6350 lb
  good update: identify the single largest-area critical member and reduce
    it by 1-2%; re-check reliability; if it drops below 0.9950 revert that
    member and try a different one. Do not change near-zero members further.
  result: small, safe weight reductions of a few percent per iteration.

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  Displacement= {disp:.4f} in (limit=2.0)
  {areas}

RECENT HISTORY
{hist}

TASK: Using the PATTERN from the worked examples above (not their specific
numbers — your current state is different from all three), write an
adaptive UPDATE RULE applied ~{stag} times that moves the CURRENT design
toward lower weight while keeping reliability >= {tr}.

Return ONLY this function, no extra text, no markdown fences:

def update_operator(A, reliability, weight, disp):
    import numpy as np
    A_new = A.copy()
    # your adaptive logic
    return np.clip(A_new, {amin}, {amax})
"""

def build_prompt(A, R, W, disp, it, history):
    hist = "\n".join(f"  iter={h['iter']:3d}  W={h['W']:9.1f}  R={h['R']:.4f}  "
                     f"feasible={h['feasible']}" for h in history[-6:])
    areas = ", ".join(f"A[{i+1}]={v:.3f}" for i,v in enumerate(A))
    return P0_TMPL.format(tr=TARGET_R, amin=A_MIN, amax=A_MAX, it=it,
                          W=W, R=R, disp=disp, areas=areas, hist=hist,
                          stag=STAGNATION_LIMIT)

def extract_code(text):
    lines, inside = [], False
    for line in text.splitlines():
        clean = line.replace("```python", "").replace("```", "")
        if clean.strip().startswith("def update_operator"): inside = True
        if inside: lines.append(clean)
    return "\n".join(lines) if lines else None

# ================================================================
# DEEPSEEK CALLER  (temperature is now a parameter, not fixed)
# ================================================================
def _post_with_retry(url, headers, json_body, timeout=45, max_retries=4):
    last_err = None
    for attempt in range(max_retries):
        try:
            r = requests.post(url, headers=headers, json=json_body, timeout=timeout)
            if r.status_code >= 500:
                raise requests.exceptions.HTTPError(f"{r.status_code} Server Error", response=r)
            r.raise_for_status()
            return r
        except Exception as e:
            last_err = e
            if attempt < max_retries - 1:
                wait = (2 ** attempt) + np.random.uniform(0, 1)
                print(f"    ⚠ retryable error ({e}); retrying in {wait:.1f}s [{attempt+1}/{max_retries}]")
                time.sleep(wait)
    raise last_err

def call_deepseek(prompt, temperature):
    r = _post_with_retry(
        DEEPSEEK_URL,
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
        json_body={"model": "deepseek-chat",
              "messages": [{"role": "user", "content": prompt}],
              "temperature": temperature, "max_tokens": 600})
    content = r.json()["choices"][0]["message"]["content"]
    return extract_code(content)

def call_llm(prompt, temperature, fail_counter=None):
    CNT.inc("llm_calls")
    try:
        code = call_deepseek(prompt, temperature)
        if code is None and fail_counter is not None:
            fail_counter[0] += 1
        return code
    except Exception as e:
        print(f"    ⚠ DeepSeek API error after retries: {e}")
        if fail_counter is not None:
            fail_counter[0] += 1
        return None

def apply_operator(code, A, R, W, disp):
    if code is None:
        f = 1.05 if R < TARGET_R else 0.97
        return np.clip(A*f, A_MIN, A_MAX)
    try:
        ns = {"np": np, "numpy": np, "N_MEM": N_MEM, "A_MIN": A_MIN, "A_MAX": A_MAX}
        exec(code, ns)
        raw = ns["update_operator"](A.copy(), float(R), float(W), float(disp))
        A_new = np.atleast_1d(np.asarray(raw, dtype=float)).flatten()
        if A_new.shape[0] != N_MEM: raise ValueError("shape")
        return np.clip(A_new, A_MIN, A_MAX)
    except Exception:
        f = 1.05 if R < TARGET_R else 0.97
        return np.clip(A*f, A_MIN, A_MAX)

# ================================================================
# ONE FULL RUN  (seed, temperature, repeat_id)
# ================================================================
def run_one(seed, temperature, repeat_id):
    global CNT
    CNT = Counters()
    t0 = time.time()
    # IMPORTANT: rng is seeded identically every time for a given `seed` —
    # this guarantees the INITIAL design point is IDENTICAL across repeats.
    # Any difference in outcome between repeat_id=1 and repeat_id=2 (same
    # seed, same temperature) must therefore come from the LLM's own
    # response variability, not from a different starting point.
    rng = np.random.RandomState(seed)

    CNT.set_phase("init")
    A = init_design(rng)
    W, R, feasible, disp = evaluate(A)

    best_A, best_W, best_R = A.copy(), (W if feasible else np.inf), R
    history = [{"iter":0,"W":W,"R":R,"disp":disp,"feasible":feasible}]
    stag, prev_bw = 0, best_W

    CNT.set_phase("llm_loop")
    fail_counter = [0]
    prompt = build_prompt(A, R, W, disp, 0, history)
    code = call_llm(prompt, temperature, fail_counter)

    for it in range(1, MAX_ITER_LLM + 1):
        try:
            A_new = apply_operator(code, A, R, W, disp)
            W_n, R_n, feas_n, disp_n = evaluate(A_new)
        except Exception:
            A_new, W_n, R_n, feas_n, disp_n = A.copy(), W, R, feasible, disp
        accept = ((not feasible and R_n > R) or
                  (feasible and feas_n and W_n < W))
        if accept:
            A, W, R, disp, feasible = A_new, W_n, R_n, disp_n, feas_n
            if feas_n and W_n < best_W:
                best_A, best_W, best_R = A_new.copy(), W_n, R_n
        history.append({"iter":it,"W":W,"R":R,"disp":disp,"feasible":feasible})
        stag = (stag+1) if abs(best_W - prev_bw) < 0.5 else 0
        prev_bw = best_W
        if stag >= STAGNATION_LIMIT:
            prompt = build_prompt(A, R, W, disp, it, history)
            code = call_llm(prompt, temperature, fail_counter)
            stag = 0

    W_loop, R_loop = best_W, best_R
    eval_loop = CNT.total("eval_calls")

    CNT.set_phase("cd")
    W_cd, R_cd = W_loop, R_loop
    if best_W < np.inf:
        A_cd, W_cd2, R_cd2 = coord_descent(best_A, best_W, best_R)
        if W_cd2 < best_W and R_cd2 >= TARGET_R:
            W_cd, R_cd = W_cd2, R_cd2

    elapsed = time.time() - t0
    feasible_final = bool(R_cd >= TARGET_R - 1e-6 and W_cd < np.inf)
    return {
        "seed": seed, "temperature": temperature, "repeat_id": repeat_id,
        "W_loop_end": W_loop if W_loop < np.inf else None,
        "W_final": W_cd if feasible_final else None,
        "R_final": R_cd, "feasible": feasible_final,
        "CD_delta": (W_loop - W_cd) if feasible_final else 0.0,
        "eval_loop": eval_loop, "eval_total": CNT.total("eval_calls"),
        "llm_calls": CNT.total("llm_calls"),
        "llm_fallback_count": fail_counter[0],
        "time_s": round(elapsed, 2),
    }

# ================================================================
# DRIVER
# ================================================================
def append_csv(fname, rows, fieldnames):
    new = not os.path.exists(fname)
    with open(fname, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

def rebuild_excel():
    if not os.path.exists(OUT_CSV):
        print("No data yet."); return
    rows = list(csv.DictReader(open(OUT_CSV)))
    if not rows:
        print("No data yet."); return
    from collections import defaultdict
    groups = defaultdict(list)
    for r in rows:
        groups[(float(r["seed"]), float(r["temperature"]))].append(r)

    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Summary"
    ws.append(["seed","temperature","n_repeats","W_final_repeat1","W_final_repeat2",
               "abs_diff","feasible_both"])
    for (seed, temp), rs in sorted(groups.items()):
        rs_sorted = sorted(rs, key=lambda r: int(r["repeat_id"]))
        w_vals = [float(r["W_final"]) if r["W_final"] not in ("","None") else None for r in rs_sorted]
        feas_both = all(r["feasible"]=="True" for r in rs_sorted)
        diff = (abs(w_vals[0]-w_vals[1]) if len(w_vals)==2 and None not in w_vals else None)
        ws.append([int(seed), temp, len(rs_sorted),
                   w_vals[0] if len(w_vals)>0 else None,
                   w_vals[1] if len(w_vals)>1 else None,
                   diff, feas_both])
    ws.append([]); ws.append(["timestamp", datetime.datetime.now().isoformat()])
    ws.append(["note", "Same seed = identical initial design point across repeats. "
                       "If temperature=0.0 repeats are near-identical but temperature=0.7 "
                       "repeats differ substantially, LLM sampling temperature is confirmed "
                       "as the main driver of run-to-run variability."])

    ws2 = wb.create_sheet("PerRun")
    keys2 = list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])

    wb.save(OUT_XLSX)
    print(f"✓ Saved: {OUT_XLSX}  ({len(rows)} total runs)")
    try:
        from google.colab import files as _colab_files
        _colab_files.download(OUT_XLSX)
    except Exception:
        pass

def main():
    done = set()
    if os.path.exists(OUT_CSV):
        existing = list(csv.DictReader(open(OUT_CSV)))
        for r in existing:
            done.add((int(r["seed"]), float(r["temperature"]), int(r["repeat_id"])))

    combos = [(s, t, rep) for s in TEST_SEEDS for t in TEMPS for rep in REPEATS]
    remaining = [c for c in combos if c not in done]
    print(f"{len(remaining)}/{len(combos)} runs remaining")

    fieldnames = None
    for (seed, temp, rep) in remaining:
        print(f"\n--- seed={seed} temp={temp} repeat={rep} ---")
        r = run_one(seed, temp, rep)
        if fieldnames is None: fieldnames = list(r.keys())
        append_csv(OUT_CSV, [r], fieldnames)
        print(f"  W_final={r['W_final']}  R={r['R_final']:.4f}  "
              f"feasible={r['feasible']}  llm={r['llm_calls']}  t={r['time_s']}s", flush=True)
        rebuild_excel()

    rebuild_excel()

if __name__ == "__main__":
    main()
