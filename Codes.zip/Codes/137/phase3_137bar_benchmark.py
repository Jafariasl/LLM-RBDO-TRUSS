# ============================================================
#  PHASE 3 — FAIR BENCHMARKING — 137-bar plane truss (Burro Creek)
#  Mirrors the 10/25/120-bar Phase 3 methodology, adapted for the
#  CONTINUOUS 4-group design space in SI units, with a
#  probabilistic displacement constraint (FORM, 14 RVs) and a
#  deterministic 400 MPa stress constraint.
#
#  PSO, GA, SLSQP each run under NATIVE budget and MATCHED budget
#  (~250 evaluations, the order the LLM operator uses), with the
#  SAME coordinate-descent refinement applied to every method's
#  output. Answers R1-2, R3-2 for this benchmark.
#
#  FEM/FORM identical to the validated reference (Option C
#  reproduces the published 786,697 kg exactly). Warm start uses
#  the feasible FDM-selected design of Moradinik et al. (2025).

# ============================================================

import numpy as np
from scipy.stats import norm
from scipy.optimize import minimize, differential_evolution
import time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

N_SEEDS=20; NATIVE_SEEDS=5
SEEDS=list(range(1,N_SEEDS+1)); SEEDS_NATIVE=list(range(1,NATIVE_SEEDS+1))
MATCHED_EVAL_CAP=250

OUT_CSV="phase3_perrun_137bar.csv"; OUT_XLSX="phase3_137bar_benchmark.xlsx"

# ================================================================
# CONSTANTS  (SI, exact from the reference implementation)
# ================================================================
E_MEAN   = 200e9        # Pa
RHO      = 7850         # kg/m^3
SIGMA_A  = 400e6        # Pa
DISP_LIM = 0.25         # m
P_MEAN = np.array([2033193.129, 1016596.564, 1016596.564, 1016596.564,
                   1016596.564, 1016596.564, 1016596.564, 1016596.564,
                   1016596.564])
TARGET_R = 0.99
COV      = 0.05
A_MIN, A_MAX, N_GRP = 0.001, 0.5, 4
FORM_MAX_ITER = 40
FORM_TOL = 1e-3


# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS=["fem_solves","ls_evals","form_calls","hlrf_iters","eval_calls","llm_calls"]
    def __init__(self): self.phase="init"; self.data={}
    def _d(self):
        if self.phase not in self.data: self.data[self.phase]={f:0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self,f,n=1): self._d()[f]+=n
    def set_phase(self,p): self.phase=p; self._d()
    def total(self,f): return sum(d[f] for d in self.data.values())
CNT=Counters()

# ================================================================
# GEOMETRY  (exact from Analyze_bar137str.m)
# ================================================================
NODE_COORDS = np.array([
    [103.632,0],[97.536,4.6986],[91.440,9.1124],[85.344,13.2414],
    [79.248,17.0857],[73.152,20.6452],[67.056,23.9199],[60.960,26.9099],
    [54.864,29.6152],[48.768,32.0356],[42.672,34.1713],[36.576,36.0223],
    [30.480,37.5885],[24.384,38.8700],[18.288,39.8666],[12.192,40.5785],
    [6.096,41.0056],[0,41.1480],[-6.096,41.0056],[-12.192,40.5785],
    [-18.288,39.8666],[-24.384,38.8700],[-30.480,37.5885],[-36.576,36.0223],
    [-42.672,34.1713],[-48.768,32.0356],[-54.864,29.6152],[-60.960,26.9099],
    [-67.056,23.9199],[-73.152,20.6452],[-79.248,17.0857],[-85.344,13.2414],
    [-91.440,9.1124],[-97.536,4.6986],[-103.632,0],
    [103.632,10.9728],[97.536,15.1145],[91.440,19.0052],[85.344,22.6448],
    [79.248,26.0335],[73.152,29.1712],[67.056,32.0578],[60.960,34.6934],
    [54.864,37.0780],[48.768,39.2116],[42.672,41.0942],[36.576,42.7258],
    [30.480,44.1064],[24.384,45.2359],[18.288,46.1144],[12.192,46.7420],
    [6.096,47.1185],[0,47.2440],[-6.096,47.1185],[-12.192,46.7420],
    [-18.288,46.1144],[-24.384,45.2359],[-30.480,44.1064],[-36.576,42.7258],
    [-42.672,41.0942],[-48.768,39.2116],[-54.864,37.0780],[-60.960,34.6934],
    [-67.056,32.0578],[-73.152,29.1712],[-79.248,26.0335],[-85.344,22.6448],
    [-91.440,19.0052],[-97.536,15.1145],[-103.632,10.9728]
])

def _mk(pairs): return np.array([[a-1,b-1] for a,b in pairs])
g1=_mk([(i,i+1) for i in range(1,35)])                    # lower chord, 34
g2=_mk([(i,i+1) for i in range(36,70)])                   # upper chord, 34
g3=_mk([(i,i+35) for i in range(1,36)])                   # verticals, 35
g4=_mk([(2,36),(3,37),(4,38),(5,39),(6,40),(7,41),(8,42),(9,43),(10,44),
        (11,45),(12,46),(13,47),(14,48),(15,49),(16,50),(17,51),(18,52),
        (18,54),(19,55),(20,56),(21,57),(22,58),(23,59),(24,60),(25,61),
        (26,62),(27,63),(28,64),(29,65),(30,66),(31,67),(32,68),(33,69),
        (34,70)])                                          # diagonals, 34
ELEMS=np.vstack([g1,g2,g3,g4])
N_EL=ELEMS.shape[0]
assert N_EL==137, f"expected 137 elements, got {N_EL}"
IDA=np.array([0]*34+[1]*34+[2]*35+[3]*34)
N_NODE=70; SDOF=N_NODE*2
FIXED_DOFS=[0,1,68,69]
FREE_DOFS=[d for d in range(SDOF) if d not in FIXED_DOFS]

EL_LEN=np.array([np.linalg.norm(NODE_COORDS[ELEMS[i,1]]-NODE_COORDS[ELEMS[i,0]]) for i in range(N_EL)])
EL_DIR=np.array([(NODE_COORDS[ELEMS[i,1]]-NODE_COORDS[ELEMS[i,0]])/EL_LEN[i] for i in range(N_EL)])

LOAD_NODES_0=[35,37,39,41,43,45,47,49,51,53,55,57,59,61,63,65,67,69]
LOAD_PATTERN_IDX=[0,1,2,3,4,5,6,7,8,8,7,6,5,4,3,2,1,0]

# precomputed element matrices (speedup only, identical numerics)
_KE,_DOFS,_SROW=[],[],[]
for _i in range(N_EL):
    _lx,_ly=EL_DIR[_i]; _le=EL_LEN[_i]
    _Te=np.array([[_lx,_ly,0,0],[0,0,_lx,_ly]])
    _KE.append(_Te.T@np.array([[1.,-1.],[-1.,1.]])@_Te)
    _n1,_n2=ELEMS[_i]; _DOFS.append([2*_n1,2*_n1+1,2*_n2,2*_n2+1])
    _SROW.append(np.array([-_lx,-_ly,_lx,_ly])/_le)
_KE=np.array(_KE); _DOFS=np.array(_DOFS); _SROW=np.array(_SROW)

# ================================================================
# FEM (accelerated, identical to reference)
# ================================================================
def fem_137bar(A_grp,E_v=E_MEAN,P_vec=None):
    CNT.inc("fem_solves")
    if P_vec is None: P_vec=P_MEAN
    A_grp=np.asarray(A_grp,dtype=float).ravel(); A_el=A_grp[IDA]
    K=np.zeros((SDOF,SDOF)); scale=E_v*A_el/EL_LEN
    for i in range(N_EL):
        idx=_DOFS[i]; K[np.ix_(idx,idx)]+=scale[i]*_KE[i]
    wt=RHO*np.sum(EL_LEN*A_el)
    F=np.zeros(SDOF)
    for k,node0 in enumerate(LOAD_NODES_0):
        F[2*node0+1]=-P_vec[LOAD_PATTERN_IDX[k]]
    Kb,Fb=K.copy(),F.copy()
    for d in FIXED_DOFS: Kb[d,:]=0;Kb[:,d]=0;Kb[d,d]=1;Fb[d]=0
    try: U=np.linalg.solve(Kb,Fb)
    except np.linalg.LinAlgError: return np.zeros(SDOF),np.zeros(N_EL),np.inf
    stress=np.array([E_v*(_SROW[i]@U[_DOFS[i]]) for i in range(N_EL)])
    return U,stress,wt

# ================================================================
# FORM (HLRF, 14 RVs, displacement limit state)
# ================================================================
def form_137bar(A_grp):
    CNT.inc("form_calls")
    A_grp=np.asarray(A_grp,dtype=float).ravel()
    mu=np.concatenate([P_MEAN,[E_MEAN],A_grp]); sig=COV*mu; N_RV=14; dmuy=1e-4*mu
    def g(X):
        CNT.inc("ls_evals")
        P_v=X[:9]; E_v=X[9]; A_v=X[10:14]
        try:
            U,_,_=fem_137bar(A_v,E_v,P_v)
            return DISP_LIM-np.max(np.abs(U[FREE_DOFS]))
        except Exception: return -1.0
    X=mu.copy(); Z=np.zeros(N_RV); beta=0.0; eps_Z=100.0; eps_beta=100.0
    for _ in range(FORM_MAX_ITER):
        if abs(eps_Z)<=FORM_TOL and abs(eps_beta)<=FORM_TOL: break
        CNT.inc("hlrf_iters"); temp=beta; tmp=np.linalg.norm(Z)
        g0=g(X); G=np.zeros(N_RV)
        for i in range(N_RV):
            x_p=X.copy(); x_p[i]+=dmuy[i]; G[i]=-(g(x_p)-g0)/dmuy[i]*sig[i]
        norm_G=np.linalg.norm(G)
        if norm_G<1e-10: break
        beta=beta+g0/norm_G; alpha=G/norm_G; Z=alpha*beta
        eps_beta=beta-temp; eps_Z=np.linalg.norm(Z)-tmp; X=mu+sig*Z
        if abs(beta)>50: break
    return float(beta),float(norm.cdf(beta))

def evaluate(A_grp):
    CNT.inc("eval_calls")
    A_grp=np.clip(np.asarray(A_grp,dtype=float).ravel(),A_MIN,A_MAX)
    U,stress,weight=fem_137bar(A_grp)
    max_disp=np.max(np.abs(U[FREE_DOFS])); max_stress=np.max(np.abs(stress))
    beta,R=form_137bar(A_grp)
    feasible=(R>=TARGET_R-1e-6) and (max_stress<=SIGMA_A)
    return weight,R,feasible,max_disp,max_stress

# Reference designs (Moradinik et al. 2025, Table 7)
A_OPT_B=np.array([0.100,0.020,0.017,0.017])   # FDM-selected, feasible here
A_OPT_C=np.array([0.100,0.100,0.100,0.100])   # heaviest, feasible

def init_design(mode,rng):
    if mode=="warm":
        cand=[A_OPT_B.copy(),
              np.clip(A_OPT_B*np.array([0.85,1.0,1.0,1.0]),A_MIN,A_MAX),
              np.clip(A_OPT_B+rng.uniform(-0.005,0.005,N_GRP),A_MIN,A_MAX)]
        fc=[]
        for c in cand:
            cs=np.clip(c,A_MIN,A_MAX); w,r,feas,_,_=evaluate(cs)
            fc.append((cs,w if feas else np.inf))
        best=min(fc,key=lambda x:x[1])
        return best[0] if best[1]<np.inf else A_OPT_B.copy()
    return np.clip(rng.uniform(A_MIN,A_MAX,N_GRP),A_MIN,A_MAX)

def coord_descent(A_init,W_init,R_init,max_passes=20):
    A=A_init.copy(); W,R=W_init,R_init; improved=True
    for _ in range(max_passes):
        if not improved: break
        improved=False
        for i in range(N_GRP):
            for delta in [0.001,0.002,0.005,0.010]:
                A_try=A.copy(); A_try[i]=max(A_MIN,A[i]-delta)
                if A_try[i]>=A[i]: continue
                W_t,R_t,feas,_,_=evaluate(A_try)
                if feas and W_t<W: A,W,R=A_try,W_t,R_t; improved=True; break
    return A,W,R


def penalty_fitness(A_grp):
    W,R,feas,disp,sig=evaluate(A_grp)
    if R<TARGET_R: return W+1e7+1e9*(TARGET_R-R)**2
    if sig>SIGMA_A: return W+1e7+1e-1*(sig-SIGMA_A)
    return W

# ================================================================
# PSO / GA / SLSQP  (continuous)
# ================================================================
def run_pso(seed,init_mode,n_iters,n_particles,eval_cap=None):
    rng=np.random.RandomState(seed); n=n_particles
    if init_mode=="warm":
        X0=init_design("warm",rng)
        X=np.tile(X0,(n,1))*(1.0+rng.uniform(-0.3,0.3,(n,N_GRP)))
    else:
        X=rng.uniform(A_MIN,A_MAX,(n,N_GRP))
    X=np.clip(X,A_MIN,A_MAX); V=rng.uniform(-0.01,0.01,(n,N_GRP))
    fit=np.array([penalty_fitness(X[i]) for i in range(n)])
    pb,pb_fit=X.copy(),fit.copy(); gi=np.argmin(pb_fit); gb,gb_fit=pb[gi].copy(),pb_fit[gi]
    w,c1,c2=0.72,1.49,1.49
    for it in range(n_iters):
        if eval_cap and CNT.total("eval_calls")>=eval_cap: break
        r1_=rng.rand(n,N_GRP); r2_=rng.rand(n,N_GRP)
        V=w*V+c1*r1_*(pb-X)+c2*r2_*(gb-X); X=np.clip(X+V,A_MIN,A_MAX)
        for i in range(n):
            f=penalty_fitness(X[i])
            if f<pb_fit[i]:
                pb[i],pb_fit[i]=X[i].copy(),f
                if f<gb_fit: gb,gb_fit=X[i].copy(),f
            if eval_cap and CNT.total("eval_calls")>=eval_cap: break
    W_f,R_f,feas_f,_,_=evaluate(gb); return gb,W_f,R_f,feas_f

def run_ga(seed,init_mode,maxiter,popsize,eval_cap=None):
    rng=np.random.RandomState(seed); calls=[0]
    def obj(A):
        calls[0]+=1
        if eval_cap and calls[0]>eval_cap: return 1e15
        return penalty_fitness(A)
    bounds=[(A_MIN,A_MAX)]*N_GRP
    kwargs=dict(maxiter=maxiter,popsize=popsize,seed=seed,mutation=(0.5,1.0),
                recombination=0.7,tol=1e-6,polish=False)
    if init_mode=="warm":
        x0=init_design("warm",rng)
        kwargs["init"]=np.clip(x0*(1.0+rng.uniform(-0.3,0.3,(popsize*N_GRP,N_GRP))),A_MIN,A_MAX)
    res=differential_evolution(obj,bounds,**kwargs)
    W_f,R_f,feas_f,_,_=evaluate(res.x); return res.x,W_f,R_f,feas_f

def run_slsqp(seed,init_mode,maxiter,eval_cap=None):
    rng=np.random.RandomState(seed)
    def obj(A):
        _,_,wt=fem_137bar(np.clip(A,A_MIN,A_MAX)); return wt
    def con_r(A):
        _,R,_,_,_=evaluate(A); return R-TARGET_R
    def con_s(A):
        _,_,_,_,sig=evaluate(A); return SIGMA_A-sig
    A0=init_design(init_mode,rng); bounds=[(A_MIN,A_MAX)]*N_GRP
    cons=[{"type":"ineq","fun":con_r},{"type":"ineq","fun":con_s}]
    res=minimize(obj,A0,method="SLSQP",bounds=bounds,constraints=cons,
                 options={"maxiter":maxiter,"ftol":1e-6})
    W_f,R_f,feas_f,_,_=evaluate(res.x); return res.x,W_f,R_f,feas_f

NATIVE_ITERS=100; NATIVE_PSO_PART=25; NATIVE_GA_POP=12; NATIVE_SLSQP_MAXITER=300

def run_one(method,init_mode,budget,seed):
    global CNT
    CNT=Counters(); t0=time.time()
    if budget=="native":
        if method=="PSO": A_best,W,R,feas=run_pso(seed,init_mode,NATIVE_ITERS,NATIVE_PSO_PART)
        elif method=="GA": A_best,W,R,feas=run_ga(seed,init_mode,NATIVE_ITERS,NATIVE_GA_POP)
        else: A_best,W,R,feas=run_slsqp(seed,init_mode,NATIVE_SLSQP_MAXITER)
    else:
        if method=="PSO":
            n_part=10; n_iter=max(1,MATCHED_EVAL_CAP//n_part)
            A_best,W,R,feas=run_pso(seed,init_mode,n_iter,n_part,eval_cap=MATCHED_EVAL_CAP)
        elif method=="GA":
            popsize=4; n_iter=max(1,MATCHED_EVAL_CAP//(popsize*N_GRP))
            A_best,W,R,feas=run_ga(seed,init_mode,n_iter,popsize,eval_cap=MATCHED_EVAL_CAP)
        else:
            A_best,W,R,feas=run_slsqp(seed,init_mode,maxiter=15,eval_cap=MATCHED_EVAL_CAP)
    W_search,R_search,feas_search=W,R,feas; eval_search=CNT.total("eval_calls")
    CNT.set_phase("cd")
    W_cd,R_cd=W_search,R_search
    if feas_search and W_search<np.inf:
        A_cd,W_cd2,R_cd2=coord_descent(A_best,W_search,R_search)
        if W_cd2<W_search and R_cd2>=TARGET_R: W_cd,R_cd=W_cd2,R_cd2
    elapsed=time.time()-t0
    return {"method":method,"init":init_mode,"budget":budget,"seed":seed,
        "W_search":W_search if feas_search else None,"W_final":W_cd if feas_search else None,
        "R_final":R_cd,"feasible":bool(feas_search),
        "CD_delta":(W_search-W_cd) if feas_search else 0.0,
        "eval_search":eval_search,"eval_total":CNT.total("eval_calls"),
        "fem_total":CNT.total("fem_solves"),"time_s":round(elapsed,2)}

METHODS=["PSO","GA","SLSQP"]; INITS=["warm","random"]; BUDGETS=["native","matched"]

def append_csv(fname,rows,fieldnames):
    new=not os.path.exists(fname)
    with open(fname,"a",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

def rebuild_excel():
    if not os.path.exists(OUT_CSV): print("No data yet."); return
    rows=list(csv.DictReader(open(OUT_CSV)))
    if not rows: return
    from collections import defaultdict
    groups=defaultdict(list)
    for r in rows: groups[(r["method"],r["init"],r["budget"])].append(r)
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="Summary"
    ws.append(["method","init","budget","n","feasible_rate","W_final_mean","W_final_std","W_final_min","CD_delta_mean","eval_total_mean"])
    for (method,init,budget),rs in groups.items():
        wf=np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd=np.array([float(r["CD_delta"]) for r in rs]); ev=np.array([float(r["eval_total"]) for r in rs])
        feas=np.mean([r["feasible"]=="True" for r in rs])
        ws.append([method,init,budget,len(rs),feas,
                   float(wf.mean()) if len(wf) else None,float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,float(cdd.mean()),float(ev.mean())])
    ws.append([]); ws.append(["timestamp",datetime.datetime.now().isoformat()])
    ws.append(["note","native=5 seeds; matched=~250 eval cap, 20 seeds"])
    ws.append(["units","weight in kg, areas in m^2 (SI benchmark)"])
    ws2=wb.create_sheet("PerRun"); keys2=list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])
    wb.save(OUT_XLSX); print(f"\u2713 Saved: {OUT_XLSX}  ({len(rows)} runs)")

def download_final():
    try:
        from google.colab import files as _c; _c.download(OUT_XLSX); print("\u2b07 Downloaded")
    except Exception: pass

def main():
    combos=[(m,i,b) for m in METHODS for i in INITS for b in BUDGETS]
    if len(sys.argv)>1:
        want=set(sys.argv[1:]); combos=[c for c in combos if f"{c[0]}_{c[1]}_{c[2]}" in want or c[0] in want]
    done={}
    if os.path.exists(OUT_CSV):
        for r in csv.DictReader(open(OUT_CSV)):
            done.setdefault((r["method"],r["init"],r["budget"]),set()).add(int(r["seed"]))
    print(f"Running {len(combos)} combos")
    for (method,init,budget) in combos:
        name=f"{method}_{init}_{budget}"; seeds_here=SEEDS_NATIVE if budget=="native" else SEEDS
        already=done.get((method,init,budget),set()); remaining=[s for s in seeds_here if s not in already]
        if not remaining: print(f"\n=== {name}: all done ==="); continue
        print(f"\n=== {name} ({len(remaining)}/{len(seeds_here)}) ===")
        fieldnames=None
        for s in remaining:
            r=run_one(method,init,budget,s)
            if fieldnames is None: fieldnames=list(r.keys())
            append_csv(OUT_CSV,[r],fieldnames)
            print(f"  seed {s:2d}: W_final={r['W_final']}  R={r['R_final']:.4f}  eval={r['eval_total']}  t={r['time_s']}s",flush=True)
            rebuild_excel()
    rebuild_excel(); download_final()

if __name__=="__main__":
    main()
