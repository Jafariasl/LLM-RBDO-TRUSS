# ============================================================
#  PHASE 1 — ABLATION STUDY — 137-bar plane truss (Burro Creek)
#  Mirrors the 10/25/120-bar Phase 1 methodology, adapted for:
#    - 4 CONTINUOUS design groups, bounds [0.001, 0.5] m^2
#    - 14 random variables (P1..P9, E, A1..A4), COV 5%
#    - SI units throughout (m, N, Pa, kg) — this benchmark is
#      already metric, unlike the three preceding ones
#    - PROBABILISTIC displacement constraint (via FORM)
#    - DETERMINISTIC stress constraint (400 MPa)
#
#  FEM/FORM translated from the validated reference
#  (Analyze_bar137str.m); FEM assembly accelerated with
#  precomputed element matrices, numerics identical to the
#  reference to ~1e-9. Reference check: Option C (uniform 0.1 m^2)
#  reproduces the published 786,697 kg exactly.
#
#  WARM START uses Option B (the FDM-selected design of
#  Moradinik et al. 2025), which is feasible under the adopted
#  constraints (W=287,111 kg, max_disp=0.167 m < 0.25 m). Option A
#  of that reference is not used as a warm start because it
#  violates the displacement limit under the present constraint
#  set (max_disp=0.411 m), so it cannot seed a feasible search.

# ============================================================

import numpy as np
from scipy.stats import norm
import requests, time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

API_KEY      = "YOUR_DEEPSEEK_API_KEY_HERE"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"

RUN_SET = "llm"   # "local" (no API) | "llm" (needs API key)
N_SEEDS = 20
SEEDS   = list(range(1, N_SEEDS+1))

# ================================================================
# CONSTANTS  (SI, exact from the reference implementation)
# ================================================================
E_MEAN   = 200e9        # Pa
RHO      = 7850         # kg/m^3
SIGMA_A  = 400e6        # Pa
DISP_LIM = 0.25         # m
P_MEAN = np.array([2033193.129, 1016596.564, 1016596.564, 1016596.564,
                   1016596.564, 1016596.564, 1016596.564, 1016596.564,
                   1016596.564])
TARGET_R = 0.99
COV      = 0.05
A_MIN, A_MAX, N_GRP = 0.001, 0.5, 4
MAX_ITER_LLM = 150
STAGNATION_LIMIT = 5
FORM_MAX_ITER = 40
FORM_TOL = 1e-3

OUT_CSV = f"phase1_perrun_137bar_{RUN_SET}.csv"

# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS=["fem_solves","ls_evals","form_calls","hlrf_iters","eval_calls","llm_calls"]
    def __init__(self): self.phase="init"; self.data={}
    def _d(self):
        if self.phase not in self.data: self.data[self.phase]={f:0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self,f,n=1): self._d()[f]+=n
    def set_phase(self,p): self.phase=p; self._d()
    def total(self,f): return sum(d[f] for d in self.data.values())
CNT=Counters()

# ================================================================
# GEOMETRY  (exact from Analyze_bar137str.m)
# ================================================================
NODE_COORDS = np.array([
    [103.632,0],[97.536,4.6986],[91.440,9.1124],[85.344,13.2414],
    [79.248,17.0857],[73.152,20.6452],[67.056,23.9199],[60.960,26.9099],
    [54.864,29.6152],[48.768,32.0356],[42.672,34.1713],[36.576,36.0223],
    [30.480,37.5885],[24.384,38.8700],[18.288,39.8666],[12.192,40.5785],
    [6.096,41.0056],[0,41.1480],[-6.096,41.0056],[-12.192,40.5785],
    [-18.288,39.8666],[-24.384,38.8700],[-30.480,37.5885],[-36.576,36.0223],
    [-42.672,34.1713],[-48.768,32.0356],[-54.864,29.6152],[-60.960,26.9099],
    [-67.056,23.9199],[-73.152,20.6452],[-79.248,17.0857],[-85.344,13.2414],
    [-91.440,9.1124],[-97.536,4.6986],[-103.632,0],
    [103.632,10.9728],[97.536,15.1145],[91.440,19.0052],[85.344,22.6448],
    [79.248,26.0335],[73.152,29.1712],[67.056,32.0578],[60.960,34.6934],
    [54.864,37.0780],[48.768,39.2116],[42.672,41.0942],[36.576,42.7258],
    [30.480,44.1064],[24.384,45.2359],[18.288,46.1144],[12.192,46.7420],
    [6.096,47.1185],[0,47.2440],[-6.096,47.1185],[-12.192,46.7420],
    [-18.288,46.1144],[-24.384,45.2359],[-30.480,44.1064],[-36.576,42.7258],
    [-42.672,41.0942],[-48.768,39.2116],[-54.864,37.0780],[-60.960,34.6934],
    [-67.056,32.0578],[-73.152,29.1712],[-79.248,26.0335],[-85.344,22.6448],
    [-91.440,19.0052],[-97.536,15.1145],[-103.632,10.9728]
])

def _mk(pairs): return np.array([[a-1,b-1] for a,b in pairs])
g1=_mk([(i,i+1) for i in range(1,35)])                    # lower chord, 34
g2=_mk([(i,i+1) for i in range(36,70)])                   # upper chord, 34
g3=_mk([(i,i+35) for i in range(1,36)])                   # verticals, 35
g4=_mk([(2,36),(3,37),(4,38),(5,39),(6,40),(7,41),(8,42),(9,43),(10,44),
        (11,45),(12,46),(13,47),(14,48),(15,49),(16,50),(17,51),(18,52),
        (18,54),(19,55),(20,56),(21,57),(22,58),(23,59),(24,60),(25,61),
        (26,62),(27,63),(28,64),(29,65),(30,66),(31,67),(32,68),(33,69),
        (34,70)])                                          # diagonals, 34
ELEMS=np.vstack([g1,g2,g3,g4])
N_EL=ELEMS.shape[0]
assert N_EL==137, f"expected 137 elements, got {N_EL}"
IDA=np.array([0]*34+[1]*34+[2]*35+[3]*34)
N_NODE=70; SDOF=N_NODE*2
FIXED_DOFS=[0,1,68,69]
FREE_DOFS=[d for d in range(SDOF) if d not in FIXED_DOFS]

EL_LEN=np.array([np.linalg.norm(NODE_COORDS[ELEMS[i,1]]-NODE_COORDS[ELEMS[i,0]]) for i in range(N_EL)])
EL_DIR=np.array([(NODE_COORDS[ELEMS[i,1]]-NODE_COORDS[ELEMS[i,0]])/EL_LEN[i] for i in range(N_EL)])

LOAD_NODES_0=[35,37,39,41,43,45,47,49,51,53,55,57,59,61,63,65,67,69]
LOAD_PATTERN_IDX=[0,1,2,3,4,5,6,7,8,8,7,6,5,4,3,2,1,0]

# precomputed element matrices (speedup only, identical numerics)
_KE,_DOFS,_SROW=[],[],[]
for _i in range(N_EL):
    _lx,_ly=EL_DIR[_i]; _le=EL_LEN[_i]
    _Te=np.array([[_lx,_ly,0,0],[0,0,_lx,_ly]])
    _KE.append(_Te.T@np.array([[1.,-1.],[-1.,1.]])@_Te)
    _n1,_n2=ELEMS[_i]; _DOFS.append([2*_n1,2*_n1+1,2*_n2,2*_n2+1])
    _SROW.append(np.array([-_lx,-_ly,_lx,_ly])/_le)
_KE=np.array(_KE); _DOFS=np.array(_DOFS); _SROW=np.array(_SROW)

# ================================================================
# FEM (accelerated, identical to reference)
# ================================================================
def fem_137bar(A_grp,E_v=E_MEAN,P_vec=None):
    CNT.inc("fem_solves")
    if P_vec is None: P_vec=P_MEAN
    A_grp=np.asarray(A_grp,dtype=float).ravel(); A_el=A_grp[IDA]
    K=np.zeros((SDOF,SDOF)); scale=E_v*A_el/EL_LEN
    for i in range(N_EL):
        idx=_DOFS[i]; K[np.ix_(idx,idx)]+=scale[i]*_KE[i]
    wt=RHO*np.sum(EL_LEN*A_el)
    F=np.zeros(SDOF)
    for k,node0 in enumerate(LOAD_NODES_0):
        F[2*node0+1]=-P_vec[LOAD_PATTERN_IDX[k]]
    Kb,Fb=K.copy(),F.copy()
    for d in FIXED_DOFS: Kb[d,:]=0;Kb[:,d]=0;Kb[d,d]=1;Fb[d]=0
    try: U=np.linalg.solve(Kb,Fb)
    except np.linalg.LinAlgError: return np.zeros(SDOF),np.zeros(N_EL),np.inf
    stress=np.array([E_v*(_SROW[i]@U[_DOFS[i]]) for i in range(N_EL)])
    return U,stress,wt

# ================================================================
# FORM (HLRF, 14 RVs, displacement limit state)
# ================================================================
def form_137bar(A_grp):
    CNT.inc("form_calls")
    A_grp=np.asarray(A_grp,dtype=float).ravel()
    mu=np.concatenate([P_MEAN,[E_MEAN],A_grp]); sig=COV*mu; N_RV=14; dmuy=1e-4*mu
    def g(X):
        CNT.inc("ls_evals")
        P_v=X[:9]; E_v=X[9]; A_v=X[10:14]
        try:
            U,_,_=fem_137bar(A_v,E_v,P_v)
            return DISP_LIM-np.max(np.abs(U[FREE_DOFS]))
        except Exception: return -1.0
    X=mu.copy(); Z=np.zeros(N_RV); beta=0.0; eps_Z=100.0; eps_beta=100.0
    for _ in range(FORM_MAX_ITER):
        if abs(eps_Z)<=FORM_TOL and abs(eps_beta)<=FORM_TOL: break
        CNT.inc("hlrf_iters"); temp=beta; tmp=np.linalg.norm(Z)
        g0=g(X); G=np.zeros(N_RV)
        for i in range(N_RV):
            x_p=X.copy(); x_p[i]+=dmuy[i]; G[i]=-(g(x_p)-g0)/dmuy[i]*sig[i]
        norm_G=np.linalg.norm(G)
        if norm_G<1e-10: break
        beta=beta+g0/norm_G; alpha=G/norm_G; Z=alpha*beta
        eps_beta=beta-temp; eps_Z=np.linalg.norm(Z)-tmp; X=mu+sig*Z
        if abs(beta)>50: break
    return float(beta),float(norm.cdf(beta))

def evaluate(A_grp):
    CNT.inc("eval_calls")
    A_grp=np.clip(np.asarray(A_grp,dtype=float).ravel(),A_MIN,A_MAX)
    U,stress,weight=fem_137bar(A_grp)
    max_disp=np.max(np.abs(U[FREE_DOFS])); max_stress=np.max(np.abs(stress))
    beta,R=form_137bar(A_grp)
    feasible=(R>=TARGET_R-1e-6) and (max_stress<=SIGMA_A)
    return weight,R,feasible,max_disp,max_stress

# Reference designs (Moradinik et al. 2025, Table 7)
A_OPT_B=np.array([0.100,0.020,0.017,0.017])   # FDM-selected, feasible here
A_OPT_C=np.array([0.100,0.100,0.100,0.100])   # heaviest, feasible

def init_design(mode,rng):
    if mode=="warm":
        cand=[A_OPT_B.copy(),
              np.clip(A_OPT_B*np.array([0.85,1.0,1.0,1.0]),A_MIN,A_MAX),
              np.clip(A_OPT_B+rng.uniform(-0.005,0.005,N_GRP),A_MIN,A_MAX)]
        fc=[]
        for c in cand:
            cs=np.clip(c,A_MIN,A_MAX); w,r,feas,_,_=evaluate(cs)
            fc.append((cs,w if feas else np.inf))
        best=min(fc,key=lambda x:x[1])
        return best[0] if best[1]<np.inf else A_OPT_B.copy()
    return np.clip(rng.uniform(A_MIN,A_MAX,N_GRP),A_MIN,A_MAX)

def coord_descent(A_init,W_init,R_init,max_passes=20):
    A=A_init.copy(); W,R=W_init,R_init; improved=True
    for _ in range(max_passes):
        if not improved: break
        improved=False
        for i in range(N_GRP):
            for delta in [0.001,0.002,0.005,0.010]:
                A_try=A.copy(); A_try[i]=max(A_MIN,A[i]-delta)
                if A_try[i]>=A[i]: continue
                W_t,R_t,feas,_,_=evaluate(A_try)
                if feas and W_t<W: A,W,R=A_try,W_t,R_t; improved=True; break
    return A,W,R

# ================================================================
# PROMPTS
# ================================================================
FULL_PROMPT_TMPL="""You are an expert in structural reliability-based design optimization.

PROBLEM: 137-bar plane truss bridge (Burro Creek) RBDO
  Goal: minimize weight (kg), Reliability >= {tr} (displacement), stress <= 400 MPa
  Design: A[1]..A[4] (4 continuous groups), bounds [{amin}, {amax}] m^2
  Random variables (14, COV 5%): P1..P9, E, A1..A4

STRUCTURAL KNOWLEDGE:
  - A[1]: lower chord, 34 elements, total length ~227 m -> carries the main
    span action, DOMINANT for both stiffness and weight
  - A[2]: upper chord, 34 elements, ~223 m -> important, works with A[1]
  - A[3]: vertical members, 35 elements, ~274 m -> moderate influence
  - A[4]: diagonal members, 34 elements, ~278 m -> moderate influence

REFERENCE DESIGN (feasible): A=[0.100, 0.020, 0.017, 0.017]
  W=287111 kg, max_disp=0.167 m (limit 0.25) -- feasible but heavy.
  TARGET: find a lighter design with R >= {tr}

CURRENT STATE (iteration {it})
  Weight={W:.1f} kg  Reliability={R:.4f} (need>={tr})
  max_disp={disp:.4f} m (limit={displim})  max_stress={sig:.1f} MPa (limit=400)
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE applied ~{stag} times. Deterministic only.
Return ONLY the function (no markdown, no text):

def update_operator(A, reliability, weight, disp, stress_mpa):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

FEWSHOT_PROMPT_TMPL="""You are an expert in structural reliability-based design optimization.

PROBLEM: 137-bar plane truss bridge (Burro Creek) RBDO
  Goal: minimize weight (kg), Reliability >= {tr} (displacement), stress <= 400 MPa
  Design: A[1]..A[4] (4 continuous groups), bounds [{amin}, {amax}] m^2
  Random variables (14, COV 5%): P1..P9, E, A1..A4

STRUCTURAL KNOWLEDGE:
  - A[1]: lower chord, 34 elements, ~227 m -> DOMINANT for stiffness and weight
  - A[2]: upper chord, 34 elements, ~223 m -> important, works with A[1]
  - A[3]: vertical members, 35 elements, ~274 m -> moderate influence
  - A[4]: diagonal members, 34 elements, ~278 m -> moderate influence

WORKED EXAMPLES (different starting configurations -- learn the PATTERN of
good moves, not a fixed target; the right final design depends on where you are):

Example A -- infeasible, chords too thin:
  state: A=[0.020, 0.010, 0.008, 0.008]  R=0.15 (need >= {tr})
  good update: raise A[1] strongly since the lower chord governs the
    deflection of the span, raise A[2] moderately, and increase A[3],A[4]
    only slightly since they contribute less per unit of added weight.
  result: R rose toward 0.8 -- much closer to feasible.

Example B -- feasible but heavy:
  state: A=[0.100, 0.020, 0.017, 0.017]  R=0.999  W=287111 kg
  good update: reduce A[1] by 10 to 20 percent since it dominates the
    weight and the design sits well above the reliability boundary; leave
    A[2],A[3],A[4] roughly unchanged at first and only trim them once A[1]
    approaches the boundary.
  result: weight fell substantially while R stayed >= {tr}.

Example C -- feasible, near-optimal, fine-tuning:
  state: A=[0.045, 0.018, 0.015, 0.015]  R=0.992  W=190000 kg
  good update: reduce whichever group currently contributes most weight by
    1 to 3 percent, re-check R, and revert that step and try another group
    if R falls below {tr}.
  result: small, safe weight reductions per iteration.

CURRENT STATE (iteration {it})
  Weight={W:.1f} kg  Reliability={R:.4f} (need>={tr})
  max_disp={disp:.4f} m (limit={displim})  max_stress={sig:.1f} MPa (limit=400)
  {areas}

RECENT HISTORY
{hist}

TASK: Using the PATTERN from the examples (not their numbers -- your state
differs), write an adaptive UPDATE RULE applied ~{stag} times that lowers
weight while keeping reliability >= {tr} and stress <= 400 MPa.
Return ONLY the function (no markdown, no text):

def update_operator(A, reliability, weight, disp, stress_mpa):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

GENERIC_PROMPT_TMPL="""You are an optimization assistant.

PROBLEM: minimize weight of a structure with 4 continuous variables
  A[1]..A[4] in [{amin}, {amax}], subject to Reliability >= {tr} and a
  stress limit of 400 MPa. Increasing variables generally raises
  reliability and weight. You have NO other structural information.

CURRENT STATE (iteration {it})
  Weight={W:.1f}  Reliability={R:.4f} (need>={tr})  stress={sig:.1f} MPa
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE applied ~{stag} times from the feedback.
Return ONLY the function (no markdown, no text):

def update_operator(A, reliability, weight, disp, stress_mpa):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

PROMPTS={"llm_full":FULL_PROMPT_TMPL,"llm_fewshot":FEWSHOT_PROMPT_TMPL,"llm_generic":GENERIC_PROMPT_TMPL}

def build_prompt(kind,A,R,W,disp,sig_pa,it,history):
    hist="\n".join(f"  iter={h['iter']:3d}  W={h['W']:10.1f}  R={h['R']:.4f}  feasible={h['feasible']}" for h in history[-6:])
    areas=", ".join(f"A[{i+1}]={v:.5f}" for i,v in enumerate(A))
    return PROMPTS[kind].format(tr=TARGET_R,amin=A_MIN,amax=A_MAX,displim=DISP_LIM,
        it=it,W=W,R=R,disp=disp,sig=sig_pa/1e6,areas=areas,hist=hist,stag=STAGNATION_LIMIT)

def extract_code(text):
    lines,inside=[],False
    for line in text.splitlines():
        clean=line.replace("```python","").replace("```","")
        if clean.strip().startswith("def update_operator"): inside=True
        if inside: lines.append(clean)
    return "\n".join(lines) if lines else None

# ================================================================
# PROPOSER
# ================================================================
def _post_with_retry(url,headers,json_body,timeout=45,max_retries=4):
    last=None
    for attempt in range(max_retries):
        try:
            r=requests.post(url,headers=headers,json=json_body,timeout=timeout)
            if r.status_code>=500: raise requests.exceptions.HTTPError(f"{r.status_code} Server Error",response=r)
            r.raise_for_status(); return r
        except Exception as e:
            last=e
            if attempt<max_retries-1:
                w=(2**attempt)+np.random.uniform(0,1); print(f"    retry {w:.1f}s ({e})"); time.sleep(w)
    raise last

def call_deepseek(prompt):
    r=_post_with_retry(DEEPSEEK_URL,
        headers={"Authorization":f"Bearer {API_KEY}","Content-Type":"application/json"},
        json_body={"model":"deepseek-chat","messages":[{"role":"user","content":prompt}],"temperature":0.7,"max_tokens":700})
    return extract_code(r.json()["choices"][0]["message"]["content"])

class Proposer:
    LLM_KINDS=("llm_full","llm_fewshot","llm_generic")
    def __init__(self,kind,rng=None): self.kind=kind; self.rng=rng
    def get_operator(self,A,R,W,disp,sig,it,history):
        if self.kind in self.LLM_KINDS:
            CNT.inc("llm_calls")
            try: return call_deepseek(build_prompt(self.kind,A,R,W,disp,sig,it,history))
            except Exception as e: print(f"    ⚠ DeepSeek error after retries: {e}"); return None
        return None
    def apply(self,code,A,R,W,disp,sig):
        if self.kind=="fallback" or (self.kind in self.LLM_KINDS and code is None):
            f=1.05 if R<TARGET_R else 0.97
            return np.clip(A*f,A_MIN,A_MAX)
        if self.kind=="random":
            return np.clip(A*(1.0+self.rng.uniform(-0.15,0.15,N_GRP)),A_MIN,A_MAX)
        try:
            ns={"np":np,"numpy":np,"N_GRP":N_GRP,"A_MIN":A_MIN,"A_MAX":A_MAX}
            exec(code,ns)
            raw=ns["update_operator"](A.copy(),float(R),float(W),float(disp),float(sig/1e6))
            A_new=np.atleast_1d(np.asarray(raw,dtype=float)).flatten()
            if A_new.shape[0]!=N_GRP: raise ValueError("shape")
            return np.clip(A_new,A_MIN,A_MAX)
        except Exception:
            f=1.05 if R<TARGET_R else 0.97
            return np.clip(A*f,A_MIN,A_MAX)

# ================================================================
# ONE RUN
# ================================================================
def run_one(variant,proposer_kind,init_mode,use_cd,seed):
    global CNT
    CNT=Counters(); t0=time.time(); rng=np.random.RandomState(seed)
    prop=Proposer(proposer_kind,rng=rng)
    CNT.set_phase("init")
    A=init_design(init_mode,rng)
    W,R,feasible,disp,sig=evaluate(A)
    best_A=A.copy(); best_W=W if feasible else np.inf; best_R=R
    history=[{"iter":0,"W":W,"R":R,"disp":disp,"sig":sig,"feasible":feasible}]
    # running best after each iteration, used only to plot convergence
    conv=[{"iter":0,"best_W":(best_W if best_W<np.inf else None),"R":best_R}]
    stag=0
    CNT.set_phase("loop")
    if proposer_kind=="none":
        it=0
        while not feasible and it<MAX_ITER_LLM:
            it+=1; A=np.clip(A*1.05,A_MIN,A_MAX); W,R,feasible,disp,sig=evaluate(A)
            if feasible: best_A,best_W,best_R=A.copy(),W,R
            conv.append({"iter":it,"best_W":(best_W if best_W<np.inf else None),"R":best_R})
    else:
        op=prop.get_operator(A,R,W,disp,sig,0,history)
        for it in range(1,MAX_ITER_LLM+1):
            try:
                A_new=prop.apply(op,A,R,W,disp,sig)
                W_n,R_n,feas_n,disp_n,sig_n=evaluate(A_new)
            except Exception:
                A_new,W_n,R_n,feas_n,disp_n,sig_n=A.copy(),W,R,feasible,disp,sig
            accept=((not feasible and R_n>R) or (feasible and feas_n and W_n<W))
            if accept:
                A,W,R,disp,sig,feasible=A_new,W_n,R_n,disp_n,sig_n,feas_n
                if feas_n and W_n<best_W: best_A,best_W,best_R=A_new.copy(),W_n,R_n
            history.append({"iter":it,"W":W,"R":R,"disp":disp,"sig":sig,"feasible":feasible})
            conv.append({"iter":it,"best_W":(best_W if best_W<np.inf else None),"R":best_R})
            stag=0 if accept else stag+1
            if stag>=STAGNATION_LIMIT:
                op=prop.get_operator(A,R,W,disp,sig,it,history); stag=0
    W_loop,R_loop=best_W,best_R; eval_loop=CNT.total("eval_calls")
    CNT.set_phase("cd")
    if use_cd and best_W<np.inf:
        A_cd,W_cd,R_cd=coord_descent(best_A,best_W,best_R)
        if W_cd<best_W and R_cd>=TARGET_R: best_A,best_W,best_R=A_cd,W_cd,R_cd
    elapsed=time.time()-t0
    row={"variant":variant,"proposer":proposer_kind,"init":init_mode,"cd":use_cd,"seed":seed,
        "W_loop_end":W_loop if W_loop<np.inf else None,
        "W_final":best_W if best_W<np.inf else None,"R_final":best_R,
        "feasible":bool(best_R>=TARGET_R-1e-6 and best_W<np.inf),
        "CD_delta":(W_loop-best_W) if (use_cd and W_loop<np.inf) else 0.0,
        "eval_loop":eval_loop,"eval_total":CNT.total("eval_calls"),
        "fem_total":CNT.total("fem_solves"),"llm_calls":CNT.total("llm_calls"),"time_s":round(elapsed,2)}
    for i in range(N_GRP): row[f"A{i+1}"]=float(best_A[i]) if best_W<np.inf else None

    conv_name=f"phase1_conv_137bar_{RUN_SET}.csv"
    conv_new=not os.path.exists(conv_name)
    with open(conv_name,"a",newline="") as cf:
        cw=csv.DictWriter(cf,fieldnames=["variant","seed","iter","best_W","R"])
        if conv_new: cw.writeheader()
        for c in conv:
            cw.writerow({"variant":variant,"seed":seed,"iter":c["iter"],
                         "best_W":c["best_W"],"R":c["R"]})
    return row

LOCAL_VARIANTS=[
    ("fallback+CD_warm","fallback","warm",True),("fallback+CD_rand","fallback","random",True),
    ("fallback-noCD_rand","fallback","random",False),
    ("random+CD_warm","random","warm",True),("random+CD_rand","random","random",True),
    ("random-noCD_rand","random","random",False),
    ("CDonly_warm","none","warm",True),("CDonly_rand","none","random",True)]
LLM_VARIANTS=[
    ("LLM+CD_warm","llm_full","warm",True),("LLM+CD_rand","llm_full","random",True),
    ("LLM-noCD_rand","llm_full","random",False),("LLMgeneric+CD_rand","llm_generic","random",True),
    ("LLMfewshot+CD_rand","llm_fewshot","random",True),("LLMfewshot+CD_warm","llm_fewshot","warm",True)]

def append_csv(fname,rows,fieldnames):
    new=not os.path.exists(fname)
    with open(fname,"a",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

def rebuild_excel(run_set):
    csv_name=f"phase1_perrun_137bar_{run_set}.csv"
    if not os.path.exists(csv_name): print("No data yet."); return
    rows=list(csv.DictReader(open(csv_name)))
    if not rows: return
    from collections import defaultdict
    groups=defaultdict(list)
    for r in rows: groups[r["variant"]].append(r)
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="Summary"
    ws.append(["variant","n","feasible_rate","W_final_mean","W_final_std","W_final_min","W_final_max","CD_delta_mean","eval_total_mean","llm_calls_mean"])
    for name,rs in groups.items():
        wf=np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd=np.array([float(r["CD_delta"]) for r in rs]); ev=np.array([float(r["eval_total"]) for r in rs])
        lc=np.array([float(r["llm_calls"]) for r in rs]); feas=np.mean([r["feasible"]=="True" for r in rs])
        ws.append([name,len(rs),feas,
                   float(wf.mean()) if len(wf) else None,float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,float(wf.max()) if len(wf) else None,
                   float(cdd.mean()),float(ev.mean()),float(lc.mean())])
    ws.append([]); ws.append(["timestamp",datetime.datetime.now().isoformat()])
    ws.append(["RUN_SET",run_set]); ws.append(["N_SEEDS",N_SEEDS])
    ws.append(["units","weight in kg, areas in m^2 (SI benchmark)"])
    ws2=wb.create_sheet("PerRun"); keys2=list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])

    conv_name=f"phase1_conv_137bar_{run_set}.csv"
    if os.path.exists(conv_name):
        crows=list(csv.DictReader(open(conv_name)))
        if crows:
            ws3=wb.create_sheet("Convergence")
            keys3=list(crows[0].keys()); ws3.append(keys3)
            for r in crows: ws3.append([r[k] for k in keys3])

    fname=f"phase1_137bar_{run_set}.xlsx"; wb.save(fname)
    print(f"✓ Saved: {fname}  ({len(rows)} runs)")

def download_final(run_set):
    try:
        from google.colab import files as _c; _c.download(f"phase1_137bar_{run_set}.xlsx"); print("⬇ Downloaded")
    except Exception: pass

def main():
    variants=LOCAL_VARIANTS if RUN_SET=="local" else LLM_VARIANTS
    if len(sys.argv)>1:
        want=set(sys.argv[1:]); variants=[v for v in variants if v[0] in want]
    csv_name=f"phase1_perrun_137bar_{RUN_SET}.csv"; done_seeds={}
    if os.path.exists(csv_name):
        for r in csv.DictReader(open(csv_name)):
            done_seeds.setdefault(r["variant"],set()).add(int(r["seed"]))
    print(f"RUN_SET={RUN_SET}: {len(variants)} variants")
    for (name,prop,init,cd) in variants:
        already=done_seeds.get(name,set()); remaining=[s for s in SEEDS if s not in already]
        if not remaining: print(f"\n=== {name}: all done ==="); continue
        print(f"\n=== {name} ({len(remaining)}/{N_SEEDS}) ===")
        fieldnames=None
        for s in remaining:
            row=run_one(name,prop,init,cd,s)
            if fieldnames is None: fieldnames=list(row.keys())
            append_csv(csv_name,[row],fieldnames)
            print(f"  seed {s:2d}: W_loop={row['W_loop_end']}  W_final={row['W_final']}  "
                  f"R={row['R_final']:.4f}  eval={row['eval_total']}  llm={row['llm_calls']}  t={row['time_s']}s",flush=True)
            rebuild_excel(RUN_SET)
    rebuild_excel(RUN_SET); download_final(RUN_SET)

if __name__=="__main__":
    main()
