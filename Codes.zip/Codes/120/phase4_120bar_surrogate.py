# ============================================================
#  PHASE 4 — SURROGATE-ASSISTED BASELINE (Kriging / EGO) — 120-bar
#  Mirrors the 10-bar / 25-bar Phase 4 methodology, adapted for the
#  CONTINUOUS 7-group design space of the 120-bar dome, with the
#  probabilistic displacement constraint (FORM) and the
#  deterministic stress/buckling constraint.
#
#  A Kriging surrogate of the penalized objective is built over an
#  initial Latin-hypercube design and refined by expected-improvement
#  infill; the same coordinate-descent refinement used for every
#  other method is applied to the final design. Answers R1-3 for
#  this benchmark.
#
#  Two budgets, matching Phase 3:
#    matched : ~200 true evaluations (init DoE + infill)
#    native  : ~500 true evaluations
#
#  FEM/FORM identical to the validated reference (SORA W=39070.1,
#  R=0.9987). Evaluations are cached so the final best-feasible

# ============================================================

import numpy as np
from scipy.stats import norm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
import time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

# ================================================================
# CONSTANTS  (exact from Analyze_bar120.m, validated)
# ================================================================
E_MEAN=30450e3; P1_M=13.49e3; P2_M=6.744e3; P3_M=2.248e3
RHO=0.288; Fi=58e3; SIG_T=0.6*Fi; DISP_LIM=0.1969
z1,z2,z3=118.11,196.85,275.59
r1,r2,r3=273.26,492.12,625.59
TARGET_R=0.99; COV=0.05
A_MIN,A_MAX,N_GRP=0.755,20.0,7
FORM_MAX_ITER=40; FORM_TOL=1e-3

N_SEEDS=20; NATIVE_SEEDS=5
SEEDS=list(range(1,N_SEEDS+1)); SEEDS_NATIVE=list(range(1,NATIVE_SEEDS+1))
MATCHED_TOTAL=200; NATIVE_TOTAL=500

OUT_CSV="phase4_perrun_120bar.csv"; OUT_XLSX="phase4_120bar_surrogate.xlsx"

# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS=["fem_solves","ls_evals","form_calls","hlrf_iters","eval_calls"]
    def __init__(self): self.phase="search"; self.data={}
    def _d(self):
        if self.phase not in self.data: self.data[self.phase]={f:0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self,f,n=1): self._d()[f]+=n
    def set_phase(self,p): self.phase=p; self._d()
    def total(self,f): return sum(d[f] for d in self.data.values())
CNT=Counters()

# ================================================================
# GEOMETRY  (exact from Analyze_bar120.m)
# ================================================================
NODES=np.zeros((49,3)); NODES[0]=[0,0,z3]
for i,a in enumerate([np.pi/2,np.pi/3,np.pi/6,0,-np.pi/6,-np.pi/3,-np.pi/2,
                      8*np.pi/6,7*np.pi/6,np.pi,5*np.pi/6,4*np.pi/6]):
    NODES[1+i]=[r1*np.cos(a),r1*np.sin(a),z2]
for i,a in enumerate([np.pi/2,5*np.pi/12,4*np.pi/12,3*np.pi/12,2*np.pi/12,np.pi/12,0,
                      -np.pi/12,-2*np.pi/12,-3*np.pi/12,-4*np.pi/12,-5*np.pi/12,-np.pi/2,
                      -7*np.pi/12,-8*np.pi/12,-9*np.pi/12,-10*np.pi/12,-11*np.pi/12,np.pi,
                      11*np.pi/12,10*np.pi/12,9*np.pi/12,8*np.pi/12,7*np.pi/12]):
    NODES[13+i]=[r2*np.cos(a),r2*np.sin(a),z1]
for i,a in enumerate([np.pi/2,np.pi/3,np.pi/6,0,-np.pi/6,-np.pi/3,-np.pi/2,
                      -4*np.pi/6,-5*np.pi/6,np.pi,5*np.pi/6,4*np.pi/6]):
    NODES[37+i]=[r3*np.cos(a),r3*np.sin(a),0]
def _p(pairs): return np.array([[a-1,b-1] for a,b in pairs])
g1=_p([(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13)])
g2=_p([(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(9,10),(10,11),(11,12),(12,13),(13,2)])
g3=_p([(2,14),(3,16),(4,18),(5,20),(6,22),(7,24),(8,26),(9,28),(10,30),(11,32),(12,34),(13,36)])
g4=_p([(2,15),(3,15),(3,17),(4,17),(4,19),(5,19),(5,21),(6,21),(6,23),(7,23),(7,25),(8,25),
       (8,27),(9,27),(9,29),(10,29),(10,31),(11,31),(11,33),(12,33),(12,35),(13,35),(13,37),(2,37)])
g5=_p([(14,15),(15,16),(16,17),(17,18),(18,19),(19,20),(20,21),(21,22),(22,23),(23,24),(24,25),(25,26),
       (26,27),(27,28),(28,29),(29,30),(30,31),(31,32),(32,33),(33,34),(34,35),(35,36),(36,37),(37,14)])
g6=_p([(14,38),(16,39),(18,40),(20,41),(22,42),(24,43),(26,44),(28,45),(30,46),(32,47),(34,48),(36,49)])
g7=_p([(15,38),(15,39),(17,39),(17,40),(19,40),(19,41),(21,41),(21,42),(23,42),(23,43),(25,43),(25,44),
       (27,44),(27,45),(29,45),(29,46),(31,46),(31,47),(33,47),(33,48),(35,48),(35,49),(37,49),(37,38)])
ELEMS=np.vstack([g1,g2,g3,g4,g5,g6,g7])
IDA=np.array([0]*12+[1]*12+[2]*12+[3]*24+[4]*24+[5]*12+[6]*24)
N_EL,N_SDOF=120,147; FIXED_DOFS=list(range(37*3,49*3))
EL_LE=np.array([np.linalg.norm(NODES[ELEMS[i,1]]-NODES[ELEMS[i,0]]) for i in range(N_EL)])
EL_DIR=np.array([(NODES[ELEMS[i,1]]-NODES[ELEMS[i,0]])/EL_LE[i] for i in range(N_EL)])
_KE,_DOFS,_SROW=[],[],[]
for _i in range(N_EL):
    _lx,_ly,_lz=EL_DIR[_i]; _le=EL_LE[_i]
    _Te=np.array([[_lx,_ly,_lz,0,0,0],[0,0,0,_lx,_ly,_lz]])
    _KE.append(_Te.T@np.array([[1.,-1.],[-1.,1.]])@_Te)
    _n1,_n2=ELEMS[_i]; _DOFS.append([3*_n1,3*_n1+1,3*_n1+2,3*_n2,3*_n2+1,3*_n2+2])
    _SROW.append(np.array([-1/_le,1/_le])@_Te)
_KE=np.array(_KE); _DOFS=np.array(_DOFS); _SROW=np.array(_SROW)

def fem_120bar(A_grp,E_v=E_MEAN,p1=P1_M,p2=P2_M,p3=P3_M):
    CNT.inc("fem_solves")
    A_grp=np.asarray(A_grp,dtype=float).ravel(); A_el=A_grp[IDA]
    K=np.zeros((N_SDOF,N_SDOF)); scale=E_v*A_el/EL_LE
    for i in range(N_EL):
        idx=_DOFS[i]; K[np.ix_(idx,idx)]+=scale[i]*_KE[i]
    wt=RHO*np.sum(EL_LE*A_el)
    F=np.zeros(N_SDOF); F[2]-=p1
    for i in range(1,13): F[i*3+2]-=p2
    for i in range(13,37): F[i*3+2]-=p3
    Kb,Fb=K.copy(),F.copy()
    for d in FIXED_DOFS: Kb[d,:]=0;Kb[:,d]=0;Kb[d,d]=1;Fb[d]=0
    try: U=np.linalg.solve(Kb,Fb)
    except np.linalg.LinAlgError: return np.zeros(N_SDOF),np.zeros(N_EL),np.inf
    stress=np.array([E_v*(_SROW[i]@U[_DOFS[i]]) for i in range(N_EL)])
    return U,stress,wt

def compressive_limit(le,Ae,E_v=E_MEAN):
    ri=0.4993*Ae**0.677; lam=le/ri; C=np.sqrt(2*np.pi**2*E_v/Fi)
    if lam<C: return (1-lam**2/(2*C**2))*Fi/(5/3+3*lam/(8*C)-lam**3/(8*C**3))
    return 12*np.pi**2*E_v/(23*lam**2)

def stress_ratio_all(A_grp,U,stress):
    A_el=A_grp[IDA]; ratios=np.zeros(N_EL)
    for i in range(N_EL):
        s=stress[i]; Ai=A_el[i]; le=EL_LE[i]
        if s>=0: ratios[i]=s/SIG_T
        else: ratios[i]=abs(s)/abs(compressive_limit(le,Ai))
    return ratios

def form_120bar(A_grp):
    CNT.inc("form_calls")
    A_grp=np.asarray(A_grp,dtype=float).ravel()
    mu=np.array([E_MEAN,P1_M,P2_M,P3_M,*A_grp]); sig=COV*mu; N_RV=11; dmuy=1e-4*mu
    def g(X):
        CNT.inc("ls_evals")
        E_v,p1,p2,p3=X[0],X[1],X[2],X[3]; A_v=X[4:11]
        try:
            U,_,_=fem_120bar(A_v,E_v,p1,p2,p3); return DISP_LIM-np.max(np.abs(U[:111]))
        except Exception: return -1.0
    X=mu.copy(); Z=np.zeros(N_RV); beta=0.0; eps_Z=100.0; eps_beta=100.0
    for _ in range(FORM_MAX_ITER):
        if abs(eps_Z)<=FORM_TOL and abs(eps_beta)<=FORM_TOL: break
        CNT.inc("hlrf_iters"); temp=beta; tmp=np.linalg.norm(Z)
        g0=g(X); G=np.zeros(N_RV)
        for i in range(N_RV):
            x_p=X.copy(); x_p[i]+=dmuy[i]; G[i]=-(g(x_p)-g0)/dmuy[i]*sig[i]
        norm_G=np.linalg.norm(G)
        if norm_G<1e-10: break
        beta=beta+g0/norm_G; alpha=G/norm_G; Z=alpha*beta
        eps_beta=beta-temp; eps_Z=np.linalg.norm(Z)-tmp; X=mu+sig*Z
        if abs(beta)>50: break
    return float(beta),float(norm.cdf(beta))

def evaluate(A_grp):
    CNT.inc("eval_calls")
    A_grp=np.clip(np.asarray(A_grp,dtype=float).ravel(),A_MIN,A_MAX)
    U,stress,weight=fem_120bar(A_grp)
    ratios=stress_ratio_all(A_grp,U,stress); max_sr=np.max(ratios)
    beta,R=form_120bar(A_grp)
    feasible=(R>=TARGET_R-1e-6) and (max_sr<=1.0)
    return weight,R,feasible,max_sr

A_SORA=np.array([2.47,18.6943,6.7604,2.9971,11.8378,4.2042,2.3672])
def init_design(mode,rng):
    if mode=="warm":
        cand=[A_SORA.copy(),
              np.array([2.4698,18.6914,6.7816,3.0119,11.8327,4.1407,2.368]),
              np.clip(A_SORA+rng.uniform(-0.5,0.5,N_GRP),A_MIN,A_MAX)]
        fc=[]
        for c in cand:
            cs=np.clip(c,A_MIN,A_MAX); w,r,feas,_=evaluate(cs); fc.append((cs,w if feas else np.inf+w))
        return min(fc,key=lambda x:x[1])[0]
    return np.clip(rng.uniform(A_MIN,A_MAX,N_GRP),A_MIN,A_MAX)

def coord_descent(A_init,W_init,R_init,max_passes=20):
    A=A_init.copy(); W,R=W_init,R_init; improved=True
    for _ in range(max_passes):
        if not improved: break
        improved=False
        for i in range(N_GRP):
            for delta in [0.5,1.0,2.0,5.0]:
                A_try=A.copy(); A_try[i]=max(A_MIN,A[i]-delta)
                if A_try[i]>=A[i]: continue
                W_t,R_t,feas,_=evaluate(A_try)
                if feas and W_t<W: A,W,R=A_try,W_t,R_t; improved=True; break
    return A,W,R

# ================================================================
# KRIGING / EGO
# ================================================================
def latin_hypercube(n,dim,rng,center=None,spread=None):
    cut=np.linspace(0,1,n+1); u=rng.uniform(size=(n,dim))
    pts=cut[:n,None]+u*(cut[1:,None]-cut[:n,None])
    for j in range(dim): rng.shuffle(pts[:,j])
    X=A_MIN+pts*(A_MAX-A_MIN)
    if center is not None and spread is not None:
        X=np.clip(center+(X-(A_MIN+A_MAX)/2.0)*spread,A_MIN,A_MAX)
    return X

def expected_improvement(mu,sigma,f_best):
    sigma=np.maximum(sigma,1e-9); z=(f_best-mu)/sigma
    return (f_best-mu)*norm.cdf(z)+sigma*norm.pdf(z)

def run_kriging_ego(seed,init_mode,total_budget):
    rng=np.random.RandomState(seed)
    n_init=max(2*N_GRP,total_budget//4); n_infill=total_budget-n_init

    cache={}
    def true_eval(A):
        key=tuple(np.round(A,6))
        if key not in cache:
            W,R,feas,sr=evaluate(A); cache[key]=(W,R,feas,sr)
        return cache[key]

    def pen(A):
        W,R,feas,sr=true_eval(A)
        if R<TARGET_R: return W+1e6+1e8*(TARGET_R-R)**2
        if sr>1.0: return W+1e6+1e5*(sr-1.0)
        return W

    if init_mode=="warm":
        center=init_design("warm",rng)
        X=latin_hypercube(n_init,N_GRP,rng,center=center,spread=0.5)
    else:
        X=latin_hypercube(n_init,N_GRP,rng)
    X=np.clip(X,A_MIN,A_MAX)
    y=np.array([pen(x) for x in X])

    kernel=ConstantKernel(1.0)*Matern(length_scale=[1.0]*N_GRP,nu=2.5)+WhiteKernel(noise_level=1e-3)

    for _ in range(n_infill):
        try:
            gp=GaussianProcessRegressor(kernel=kernel,normalize_y=True,
                                        n_restarts_optimizer=1,random_state=seed)
            gp.fit(X,y)
        except Exception:
            break
        cand=rng.uniform(A_MIN,A_MAX,(300,N_GRP))
        mu,sigma=gp.predict(cand,return_std=True)
        ei=expected_improvement(mu,sigma,y.min())
        x_next=cand[np.argmax(ei)]
        y_next=pen(x_next)
        X=np.vstack([X,x_next]); y=np.append(y,y_next)

    best_W=np.inf; best_A=None; best_R=0.0
    for i in range(len(X)):
        W,R,feas,sr=true_eval(X[i])
        if feas and W<best_W: best_W,best_A,best_R=W,X[i].copy(),R
    if best_A is None: return None,None,0.0,False
    return best_A,best_W,best_R,True

# ================================================================
# ONE RUN
# ================================================================
def run_one(init_mode,budget,seed):
    global CNT
    CNT=Counters(); t0=time.time()
    total=NATIVE_TOTAL if budget=="native" else MATCHED_TOTAL
    A_best,W,R,feas=run_kriging_ego(seed,init_mode,total)
    eval_search=CNT.total("eval_calls")
    CNT.set_phase("cd")
    W_cd,R_cd=W,R
    if feas and A_best is not None:
        A_cd,W_cd2,R_cd2=coord_descent(A_best,W,R)
        if W_cd2<W and R_cd2>=TARGET_R: W_cd,R_cd=W_cd2,R_cd2
    elapsed=time.time()-t0
    return {"method":"Kriging-EGO","init":init_mode,"budget":budget,"seed":seed,
        "W_search":W if feas else None,"W_final":W_cd if feas else None,
        "R_final":R_cd if feas else 0.0,"feasible":bool(feas),
        "CD_delta":(W-W_cd) if feas else 0.0,
        "eval_search":eval_search,"eval_total":CNT.total("eval_calls"),
        "fem_total":CNT.total("fem_solves"),"time_s":round(elapsed,2)}

INITS=["warm","random"]; BUDGETS=["native","matched"]

def append_csv(fname,rows,fieldnames):
    new=not os.path.exists(fname)
    with open(fname,"a",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

def rebuild_excel():
    if not os.path.exists(OUT_CSV): print("No data yet."); return
    rows=list(csv.DictReader(open(OUT_CSV)))
    if not rows: return
    from collections import defaultdict
    groups=defaultdict(list)
    for r in rows: groups[(r["init"],r["budget"])].append(r)
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="Summary"
    ws.append(["method","init","budget","n","feasible_rate","W_final_mean","W_final_std","W_final_min","CD_delta_mean","eval_total_mean"])
    for (init,budget),rs in groups.items():
        wf=np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd=np.array([float(r["CD_delta"]) for r in rs]); ev=np.array([float(r["eval_total"]) for r in rs])
        feas=np.mean([r["feasible"]=="True" for r in rs])
        ws.append(["Kriging-EGO",init,budget,len(rs),feas,
                   float(wf.mean()) if len(wf) else None,float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,float(cdd.mean()),float(ev.mean())])
    ws.append([]); ws.append(["timestamp",datetime.datetime.now().isoformat()])
    ws.append(["note","native=5 seeds (500 evals); matched=20 seeds (200 evals)"])
    ws2=wb.create_sheet("PerRun"); keys2=list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])
    wb.save(OUT_XLSX); print(f"✓ Saved: {OUT_XLSX}  ({len(rows)} runs)")

def download_final():
    try:
        from google.colab import files as _c; _c.download(OUT_XLSX); print("⬇ Downloaded")
    except Exception: pass

def main():
    combos=[(i,b) for i in INITS for b in BUDGETS]
    if len(sys.argv)>1:
        want=set(sys.argv[1:]); combos=[c for c in combos if f"{c[0]}_{c[1]}" in want]
    done={}
    if os.path.exists(OUT_CSV):
        for r in csv.DictReader(open(OUT_CSV)):
            done.setdefault((r["init"],r["budget"]),set()).add(int(r["seed"]))
    print(f"Running {len(combos)} combos")
    for (init,budget) in combos:
        seeds_here=SEEDS_NATIVE if budget=="native" else SEEDS
        already=done.get((init,budget),set()); remaining=[s for s in seeds_here if s not in already]
        if not remaining: print(f"\n=== {init}_{budget}: all done ==="); continue
        print(f"\n=== {init}_{budget} ({len(remaining)}/{len(seeds_here)}) ===")
        fieldnames=None
        for s in remaining:
            r=run_one(init,budget,s)
            if fieldnames is None: fieldnames=list(r.keys())
            append_csv(OUT_CSV,[r],fieldnames)
            print(f"  seed {s:2d}: W_final={r['W_final']}  R={r['R_final']:.4f}  "
                  f"feas={r['feasible']}  eval={r['eval_total']}  t={r['time_s']}s",flush=True)
            rebuild_excel()
    rebuild_excel(); download_final()

if __name__=="__main__":
    main()
