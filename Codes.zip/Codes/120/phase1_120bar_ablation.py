# ============================================================
#  PHASE 1 — ABLATION STUDY — 120-bar space dome truss
#  Mirrors the 10-bar/25-bar Phase 1 methodology, adapted for:
#    - 7 CONTINUOUS design groups, bounds [0.755, 20] in^2
#    - 11 random variables (E, P1, P2, P3, A1..A7), COV 5%
#    - PROBABILISTIC displacement constraint (via FORM)
#    - DETERMINISTIC stress/buckling constraint (tension limit +
#      inelastic buckling allowable, from Analyze_bar120.m)
#
#  FEM/FORM are an exact translation of the validated MATLAB
#  reference (Analyze_bar120.m, FORM_Reliability.m); FEM assembly
#  is accelerated with precomputed element matrices (numerics
#  identical to the reference to ~1e-10). Reference check:
#  SORA design W=39070.1 lb, R=0.9987.

# ============================================================

import numpy as np
from scipy.stats import norm
import requests, time, warnings, datetime, csv, os, sys
warnings.filterwarnings('ignore')

API_KEY      = "YOUR_DEEPSEEK_API_KEY_HERE"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"

RUN_SET = "local"   # "local" (no API) | "llm" (needs API key)
N_SEEDS = 20
SEEDS   = list(range(1, N_SEEDS+1))

# ================================================================
# CONSTANTS  (exact from Analyze_bar120.m, validated)
# ================================================================
E_MEAN=30450e3; P1_M=13.49e3; P2_M=6.744e3; P3_M=2.248e3
RHO=0.288; Fi=58e3; SIG_T=0.6*Fi; DISP_LIM=0.1969
z1,z2,z3=118.11,196.85,275.59
r1,r2,r3=273.26,492.12,625.59
TARGET_R=0.99; COV=0.05
A_MIN,A_MAX,N_GRP=0.755,20.0,7
MAX_ITER_LLM=150; STAGNATION_LIMIT=5
FORM_MAX_ITER=40; FORM_TOL=1e-3

OUT_CSV=f"phase1_perrun_120bar_{RUN_SET}.csv"

# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS=["fem_solves","ls_evals","form_calls","hlrf_iters","eval_calls","llm_calls"]
    def __init__(self): self.phase="init"; self.data={}
    def _d(self):
        if self.phase not in self.data: self.data[self.phase]={f:0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self,f,n=1): self._d()[f]+=n
    def set_phase(self,p): self.phase=p; self._d()
    def total(self,f): return sum(d[f] for d in self.data.values())
CNT=Counters()

# ================================================================
# GEOMETRY  (exact from Analyze_bar120.m)
# ================================================================
NODES=np.zeros((49,3))
NODES[0]=[0,0,z3]
for i,a in enumerate([np.pi/2,np.pi/3,np.pi/6,0,-np.pi/6,-np.pi/3,-np.pi/2,
                      8*np.pi/6,7*np.pi/6,np.pi,5*np.pi/6,4*np.pi/6]):
    NODES[1+i]=[r1*np.cos(a),r1*np.sin(a),z2]
for i,a in enumerate([np.pi/2,5*np.pi/12,4*np.pi/12,3*np.pi/12,2*np.pi/12,np.pi/12,0,
                      -np.pi/12,-2*np.pi/12,-3*np.pi/12,-4*np.pi/12,-5*np.pi/12,-np.pi/2,
                      -7*np.pi/12,-8*np.pi/12,-9*np.pi/12,-10*np.pi/12,-11*np.pi/12,np.pi,
                      11*np.pi/12,10*np.pi/12,9*np.pi/12,8*np.pi/12,7*np.pi/12]):
    NODES[13+i]=[r2*np.cos(a),r2*np.sin(a),z1]
for i,a in enumerate([np.pi/2,np.pi/3,np.pi/6,0,-np.pi/6,-np.pi/3,-np.pi/2,
                      -4*np.pi/6,-5*np.pi/6,np.pi,5*np.pi/6,4*np.pi/6]):
    NODES[37+i]=[r3*np.cos(a),r3*np.sin(a),0]

def _p(pairs): return np.array([[a-1,b-1] for a,b in pairs])
g1=_p([(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13)])
g2=_p([(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(9,10),(10,11),(11,12),(12,13),(13,2)])
g3=_p([(2,14),(3,16),(4,18),(5,20),(6,22),(7,24),(8,26),(9,28),(10,30),(11,32),(12,34),(13,36)])
g4=_p([(2,15),(3,15),(3,17),(4,17),(4,19),(5,19),(5,21),(6,21),(6,23),(7,23),(7,25),(8,25),
       (8,27),(9,27),(9,29),(10,29),(10,31),(11,31),(11,33),(12,33),(12,35),(13,35),(13,37),(2,37)])
g5=_p([(14,15),(15,16),(16,17),(17,18),(18,19),(19,20),(20,21),(21,22),(22,23),(23,24),(24,25),(25,26),
       (26,27),(27,28),(28,29),(29,30),(30,31),(31,32),(32,33),(33,34),(34,35),(35,36),(36,37),(37,14)])
g6=_p([(14,38),(16,39),(18,40),(20,41),(22,42),(24,43),(26,44),(28,45),(30,46),(32,47),(34,48),(36,49)])
g7=_p([(15,38),(15,39),(17,39),(17,40),(19,40),(19,41),(21,41),(21,42),(23,42),(23,43),(25,43),(25,44),
       (27,44),(27,45),(29,45),(29,46),(31,46),(31,47),(33,47),(33,48),(35,48),(35,49),(37,49),(37,38)])
ELEMS=np.vstack([g1,g2,g3,g4,g5,g6,g7])
IDA=np.array([0]*12+[1]*12+[2]*12+[3]*24+[4]*24+[5]*12+[6]*24)
N_EL,N_SDOF=120,147
FIXED_DOFS=list(range(37*3,49*3))
EL_LE=np.array([np.linalg.norm(NODES[ELEMS[i,1]]-NODES[ELEMS[i,0]]) for i in range(N_EL)])
EL_DIR=np.array([(NODES[ELEMS[i,1]]-NODES[ELEMS[i,0]])/EL_LE[i] for i in range(N_EL)])

# precomputed element matrices (speedup only, identical numerics)
_KE,_DOFS,_SROW=[],[],[]
for _i in range(N_EL):
    _lx,_ly,_lz=EL_DIR[_i]; _le=EL_LE[_i]
    _Te=np.array([[_lx,_ly,_lz,0,0,0],[0,0,0,_lx,_ly,_lz]])
    _KE.append(_Te.T@np.array([[1.,-1.],[-1.,1.]])@_Te)
    _n1,_n2=ELEMS[_i]; _DOFS.append([3*_n1,3*_n1+1,3*_n1+2,3*_n2,3*_n2+1,3*_n2+2])
    _SROW.append(np.array([-1/_le,1/_le])@_Te)
_KE=np.array(_KE); _DOFS=np.array(_DOFS); _SROW=np.array(_SROW)

# ================================================================
# FEM (accelerated, identical to reference)
# ================================================================
def fem_120bar(A_grp,E_v=E_MEAN,p1=P1_M,p2=P2_M,p3=P3_M):
    CNT.inc("fem_solves")
    A_grp=np.asarray(A_grp,dtype=float).ravel(); A_el=A_grp[IDA]
    K=np.zeros((N_SDOF,N_SDOF)); scale=E_v*A_el/EL_LE
    for i in range(N_EL):
        idx=_DOFS[i]; K[np.ix_(idx,idx)]+=scale[i]*_KE[i]
    wt=RHO*np.sum(EL_LE*A_el)
    F=np.zeros(N_SDOF); F[2]-=p1
    for i in range(1,13): F[i*3+2]-=p2
    for i in range(13,37): F[i*3+2]-=p3
    Kb,Fb=K.copy(),F.copy()
    for d in FIXED_DOFS: Kb[d,:]=0;Kb[:,d]=0;Kb[d,d]=1;Fb[d]=0
    try: U=np.linalg.solve(Kb,Fb)
    except np.linalg.LinAlgError: return np.zeros(N_SDOF),np.zeros(N_EL),np.inf
    stress=np.array([E_v*(_SROW[i]@U[_DOFS[i]]) for i in range(N_EL)])
    return U,stress,wt

def compressive_limit(le,Ae,E_v=E_MEAN):
    ri=0.4993*Ae**0.677; lam=le/ri; C=np.sqrt(2*np.pi**2*E_v/Fi)
    if lam<C: return (1-lam**2/(2*C**2))*Fi/(5/3+3*lam/(8*C)-lam**3/(8*C**3))
    return 12*np.pi**2*E_v/(23*lam**2)

def stress_ratio_all(A_grp,U,stress):
    A_el=A_grp[IDA]; ratios=np.zeros(N_EL)
    for i in range(N_EL):
        s=stress[i]; Ai=A_el[i]; le=EL_LE[i]
        if s>=0: ratios[i]=s/SIG_T
        else: ratios[i]=abs(s)/abs(compressive_limit(le,Ai))
    return ratios

# ================================================================
# FORM (exact translation of FORM_Reliability.m, displacement LSF)
# ================================================================
def form_120bar(A_grp):
    CNT.inc("form_calls")
    A_grp=np.asarray(A_grp,dtype=float).ravel()
    mu=np.array([E_MEAN,P1_M,P2_M,P3_M,*A_grp]); sig=COV*mu; N_RV=11
    dmuy=1e-4*mu
    def g(X):
        CNT.inc("ls_evals")
        E_v,p1,p2,p3=X[0],X[1],X[2],X[3]; A_v=X[4:11]
        try:
            U,_,_=fem_120bar(A_v,E_v,p1,p2,p3)
            return DISP_LIM-np.max(np.abs(U[:111]))
        except Exception: return -1.0
    X=mu.copy(); Z=np.zeros(N_RV); beta=0.0; eps_Z=100.0; eps_beta=100.0
    for _ in range(FORM_MAX_ITER):
        if abs(eps_Z)<=FORM_TOL and abs(eps_beta)<=FORM_TOL: break
        CNT.inc("hlrf_iters")
        temp=beta; tmp=np.linalg.norm(Z)
        g0=g(X); G=np.zeros(N_RV)
        for i in range(N_RV):
            x_p=X.copy(); x_p[i]+=dmuy[i]; G[i]=-(g(x_p)-g0)/dmuy[i]*sig[i]
        norm_G=np.linalg.norm(G)
        if norm_G<1e-10: break
        beta=beta+g0/norm_G; alpha=G/norm_G; Z=alpha*beta
        eps_beta=beta-temp; eps_Z=np.linalg.norm(Z)-tmp; X=mu+sig*Z
        if abs(beta)>50: break
    return float(beta),float(norm.cdf(beta))

# ================================================================
# EVALUATE  (probabilistic disp via FORM + deterministic stress)
# ================================================================
def evaluate(A_grp):
    CNT.inc("eval_calls")
    A_grp=np.clip(np.asarray(A_grp,dtype=float).ravel(),A_MIN,A_MAX)
    U,stress,weight=fem_120bar(A_grp)
    max_disp=np.max(np.abs(U[:111]))
    ratios=stress_ratio_all(A_grp,U,stress); max_sr=np.max(ratios)
    beta,R=form_120bar(A_grp)
    feasible=(R>=TARGET_R-1e-6) and (max_sr<=1.0)
    return weight,R,feasible,max_disp,max_sr

# reference feasible design (SORA) used for warm start
A_SORA=np.array([2.47,18.6943,6.7604,2.9971,11.8378,4.2042,2.3672])

def init_design(mode,rng):
    if mode=="warm":
        cand=[A_SORA.copy(),
              np.array([2.4698,18.6914,6.7816,3.0119,11.8327,4.1407,2.368]),  # NDL-ICDE
              np.clip(A_SORA+rng.uniform(-0.5,0.5,N_GRP),A_MIN,A_MAX)]
        fc=[]
        for c in cand:
            cs=np.clip(c,A_MIN,A_MAX); w,r,feas,_,_=evaluate(cs); fc.append((cs,w if feas else np.inf+w))
        return min(fc,key=lambda x:x[1])[0]
    return np.clip(rng.uniform(A_MIN,A_MAX,N_GRP),A_MIN,A_MAX)

def coord_descent(A_init,W_init,R_init,max_passes=20):
    A=A_init.copy(); W,R=W_init,R_init; improved=True
    for _ in range(max_passes):
        if not improved: break
        improved=False
        for i in range(N_GRP):
            for delta in [0.5,1.0,2.0,5.0]:
                A_try=A.copy(); A_try[i]=max(A_MIN,A[i]-delta)
                if A_try[i]>=A[i]: continue
                W_t,R_t,feas,_,_=evaluate(A_try)
                if feas and W_t<W: A,W,R=A_try,W_t,R_t; improved=True; break
    return A,W,R

# ================================================================
# PROMPTS  (full=anchor, fewshot=worked examples, generic=no knowledge)
# ================================================================
FULL_PROMPT_TMPL="""You are an expert in structural reliability-based design optimization.

PROBLEM: 120-bar space dome truss RBDO
  Goal: minimize weight (lb), Reliability >= {tr} (displacement), stress ratio <= 1.0
  Design: A[1]..A[7] (7 continuous groups), bounds [{amin}, {amax}] in^2
  Random variables (11, COV 5%): E, P1, P2, P3, A1..A7
  Probabilistic constraint: nodal displacement (via FORM)
  Deterministic constraint: tension/buckling stress ratio <= 1.0

STRUCTURAL KNOWLEDGE:
  - Group 2 (A[2]): upper ring bars -> dominant, KEEP LARGE (~15-19)
  - Group 5 (A[5]): mid diagonal ring -> important (~8-12)
  - Groups 3,6 (A[3],A[6]): connecting diagonals -> moderate (~5-7 / ~3-5)
  - Groups 1,4,7 (A[1],A[4],A[7]): apex + lower bars -> smaller (~2-3)

REFERENCE DESIGN (feasible): SORA A=[2.47,18.69,6.76,3.00,11.84,4.20,2.37]
  W=39070 lb, R=0.999 -- feasible but heavy; TARGET find lighter with R>={tr}

CURRENT STATE (iteration {it})
  Weight={W:.1f} lb  Reliability={R:.4f} (need>={tr})
  max_disp={disp:.4f} in (limit={displim})  max_stress_ratio={sr:.3f} (limit=1.0)
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE applied ~{stag} times. Deterministic only.
Return ONLY the function (no markdown, no text):

def update_operator(A, reliability, weight, disp, stress_ratio):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

FEWSHOT_PROMPT_TMPL="""You are an expert in structural reliability-based design optimization.

PROBLEM: 120-bar space dome truss RBDO
  Goal: minimize weight (lb), Reliability >= {tr} (displacement), stress ratio <= 1.0
  Design: A[1]..A[7] (7 continuous groups), bounds [{amin}, {amax}] in^2
  Random variables (11, COV 5%): E, P1, P2, P3, A1..A7
  Probabilistic constraint: nodal displacement (via FORM)
  Deterministic constraint: tension/buckling stress ratio <= 1.0

STRUCTURAL KNOWLEDGE:
  - Group 2 (A[2]): upper ring bars -> dominant, KEEP LARGE (~15-19)
  - Group 5 (A[5]): mid diagonal ring -> important (~8-12)
  - Groups 3,6 (A[3],A[6]): connecting diagonals -> moderate
  - Groups 1,4,7 (A[1],A[4],A[7]): apex + lower bars -> smaller

WORKED EXAMPLES (different starting configurations -- learn the PATTERN of
good moves, not a fixed target; the right final design depends on where you are):

Example A -- infeasible, key groups too thin:
  state: A=[2.0,8.0,3.0,2.0,5.0,2.0,1.5]  R=0.40 (need>={tr})
  good update: raise A[2] and A[5] substantially (they carry the dome
    action); nudge A[3],A[6] up; keep A[1],A[4],A[7] modest.
  result: R rose toward 0.9 -- closer to feasible.

Example B -- feasible but heavy:
  state: A=[3.0,19.0,7.0,3.5,12.0,4.5,2.5]  R=0.999  W=40000 lb
  good update: trim A[2] and A[5] by a few percent since they are the
    heaviest and sit above the reliability boundary; leave the small
    groups near their current values.
  result: W dropped a few percent, R stayed >= {tr}.

Example C -- feasible, near-optimal, fine-tuning:
  state: A=[2.5,18.7,6.8,3.0,11.8,4.2,2.4]  R=0.999  W=39070 lb
  good update: reduce the single largest group by 1-2%, re-check R; if it
    drops below {tr} revert and try another group.
  result: small, safe weight reductions per iteration.

CURRENT STATE (iteration {it})
  Weight={W:.1f} lb  Reliability={R:.4f} (need>={tr})
  max_disp={disp:.4f} in (limit={displim})  max_stress_ratio={sr:.3f} (limit=1.0)
  {areas}

RECENT HISTORY
{hist}

TASK: Using the PATTERN from the examples (not their numbers -- your state
differs), write an adaptive UPDATE RULE applied ~{stag} times that lowers
weight while keeping reliability >= {tr} and stress ratio <= 1.0.
Return ONLY the function (no markdown, no text):

def update_operator(A, reliability, weight, disp, stress_ratio):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

GENERIC_PROMPT_TMPL="""You are an optimization assistant.

PROBLEM: minimize weight of a structure with 7 continuous variables
  A[1]..A[7] in [{amin}, {amax}], subject to Reliability >= {tr} and a
  stress ratio <= 1.0. Increasing variables generally raises reliability
  and weight. You have NO other structural information.

CURRENT STATE (iteration {it})
  Weight={W:.1f}  Reliability={R:.4f} (need>={tr})  stress_ratio={sr:.3f}
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE applied ~{stag} times from the feedback.
Return ONLY the function (no markdown, no text):

def update_operator(A, reliability, weight, disp, stress_ratio):
    import numpy as np
    A_new = A.copy()
    return np.clip(A_new, {amin}, {amax})
"""

PROMPTS={"llm_full":FULL_PROMPT_TMPL,"llm_fewshot":FEWSHOT_PROMPT_TMPL,"llm_generic":GENERIC_PROMPT_TMPL}

def build_prompt(kind,A,R,W,disp,sr,it,history):
    hist="\n".join(f"  iter={h['iter']:3d}  W={h['W']:9.1f}  R={h['R']:.4f}  feasible={h['feasible']}" for h in history[-6:])
    areas=", ".join(f"A[{i+1}]={v:.3f}" for i,v in enumerate(A))
    return PROMPTS[kind].format(tr=TARGET_R,amin=A_MIN,amax=A_MAX,displim=DISP_LIM,
        it=it,W=W,R=R,disp=disp,sr=sr,areas=areas,hist=hist,stag=STAGNATION_LIMIT)

def extract_code(text):
    lines,inside=[],False
    for line in text.splitlines():
        clean=line.replace("```python","").replace("```","")
        if clean.strip().startswith("def update_operator"): inside=True
        if inside: lines.append(clean)
    return "\n".join(lines) if lines else None

# ================================================================
# PROPOSER
# ================================================================
def _post_with_retry(url,headers,json_body,timeout=45,max_retries=4):
    last=None
    for attempt in range(max_retries):
        try:
            r=requests.post(url,headers=headers,json=json_body,timeout=timeout)
            if r.status_code>=500: raise requests.exceptions.HTTPError(f"{r.status_code} Server Error",response=r)
            r.raise_for_status(); return r
        except Exception as e:
            last=e
            if attempt<max_retries-1:
                w=(2**attempt)+np.random.uniform(0,1); print(f"    retry {w:.1f}s ({e})"); time.sleep(w)
    raise last

def call_deepseek(prompt):
    r=_post_with_retry(DEEPSEEK_URL,
        headers={"Authorization":f"Bearer {API_KEY}","Content-Type":"application/json"},
        json_body={"model":"deepseek-chat","messages":[{"role":"user","content":prompt}],"temperature":0.7,"max_tokens":700})
    return extract_code(r.json()["choices"][0]["message"]["content"])

class Proposer:
    LLM_KINDS=("llm_full","llm_fewshot","llm_generic")
    def __init__(self,kind,rng=None): self.kind=kind; self.rng=rng
    def get_operator(self,A,R,W,disp,sr,it,history):
        if self.kind in self.LLM_KINDS:
            CNT.inc("llm_calls")
            try: return call_deepseek(build_prompt(self.kind,A,R,W,disp,sr,it,history))
            except Exception as e: print(f"    ⚠ DeepSeek error after retries: {e}"); return None
        return None
    def apply(self,code,A,R,W,disp,sr):
        if self.kind=="fallback" or (self.kind in self.LLM_KINDS and code is None):
            f=1.05 if R<TARGET_R else 0.97
            return np.clip(A*f,A_MIN,A_MAX)
        if self.kind=="random":
            return np.clip(A*(1.0+self.rng.uniform(-0.15,0.15,N_GRP)),A_MIN,A_MAX)
        try:
            ns={"np":np,"numpy":np,"N_GRP":N_GRP,"A_MIN":A_MIN,"A_MAX":A_MAX}
            exec(code,ns)
            raw=ns["update_operator"](A.copy(),float(R),float(W),float(disp),float(sr))
            A_new=np.atleast_1d(np.asarray(raw,dtype=float)).flatten()
            if A_new.shape[0]!=N_GRP: raise ValueError("shape")
            return np.clip(A_new,A_MIN,A_MAX)
        except Exception:
            f=1.05 if R<TARGET_R else 0.97
            return np.clip(A*f,A_MIN,A_MAX)

# ================================================================
# ONE RUN
# ================================================================
def run_one(variant,proposer_kind,init_mode,use_cd,seed):
    global CNT
    CNT=Counters(); t0=time.time(); rng=np.random.RandomState(seed)
    prop=Proposer(proposer_kind,rng=rng)
    CNT.set_phase("init")
    A=init_design(init_mode,rng)
    W,R,feasible,disp,sr=evaluate(A)
    best_A=A.copy(); best_W=W if feasible else np.inf; best_R=R
    history=[{"iter":0,"W":W,"R":R,"disp":disp,"sr":sr,"feasible":feasible}]
    stag=0
    CNT.set_phase("loop")
    if proposer_kind=="none":
        it=0
        while not feasible and it<MAX_ITER_LLM:
            it+=1; A=np.clip(A*1.05,A_MIN,A_MAX); W,R,feasible,disp,sr=evaluate(A)
            if feasible: best_A,best_W,best_R=A.copy(),W,R
    else:
        op=prop.get_operator(A,R,W,disp,sr,0,history)
        for it in range(1,MAX_ITER_LLM+1):
            try:
                A_new=prop.apply(op,A,R,W,disp,sr)
                W_n,R_n,feas_n,disp_n,sr_n=evaluate(A_new)
            except Exception:
                A_new,W_n,R_n,feas_n,disp_n,sr_n=A.copy(),W,R,feasible,disp,sr
            accept=((not feasible and R_n>R) or (feasible and feas_n and W_n<W))
            if accept:
                A,W,R,disp,sr,feasible=A_new,W_n,R_n,disp_n,sr_n,feas_n
                if feas_n and W_n<best_W: best_A,best_W,best_R=A_new.copy(),W_n,R_n
            history.append({"iter":it,"W":W,"R":R,"disp":disp,"sr":sr,"feasible":feasible})
            stag=0 if accept else stag+1
            if stag>=STAGNATION_LIMIT:
                op=prop.get_operator(A,R,W,disp,sr,it,history); stag=0
    W_loop,R_loop=best_W,best_R; eval_loop=CNT.total("eval_calls")
    CNT.set_phase("cd")
    if use_cd and best_W<np.inf:
        A_cd,W_cd,R_cd=coord_descent(best_A,best_W,best_R)
        if W_cd<best_W and R_cd>=TARGET_R: best_A,best_W,best_R=A_cd,W_cd,R_cd
    elapsed=time.time()-t0
    row={"variant":variant,"proposer":proposer_kind,"init":init_mode,"cd":use_cd,"seed":seed,
        "W_loop_end":W_loop if W_loop<np.inf else None,
        "W_final":best_W if best_W<np.inf else None,"R_final":best_R,
        "feasible":bool(best_R>=TARGET_R-1e-6 and best_W<np.inf),
        "CD_delta":(W_loop-best_W) if (use_cd and W_loop<np.inf) else 0.0,
        "eval_loop":eval_loop,"eval_total":CNT.total("eval_calls"),
        "fem_total":CNT.total("fem_solves"),"llm_calls":CNT.total("llm_calls"),"time_s":round(elapsed,2)}
    for i in range(N_GRP): row[f"A{i+1}"]=float(best_A[i]) if best_W<np.inf else None
    return row

# ================================================================
# VARIANT MATRIX
# ================================================================
LOCAL_VARIANTS=[
    ("fallback+CD_warm","fallback","warm",True),("fallback+CD_rand","fallback","random",True),
    ("fallback-noCD_rand","fallback","random",False),
    ("random+CD_warm","random","warm",True),("random+CD_rand","random","random",True),
    ("random-noCD_rand","random","random",False),
    ("CDonly_warm","none","warm",True),("CDonly_rand","none","random",True)]
LLM_VARIANTS=[
    ("LLM+CD_warm","llm_full","warm",True),("LLM+CD_rand","llm_full","random",True),
    ("LLM-noCD_rand","llm_full","random",False),("LLMgeneric+CD_rand","llm_generic","random",True),
    ("LLMfewshot+CD_rand","llm_fewshot","random",True),("LLMfewshot+CD_warm","llm_fewshot","warm",True)]

def append_csv(fname,rows,fieldnames):
    new=not os.path.exists(fname)
    with open(fname,"a",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

def rebuild_excel(run_set):
    csv_name=f"phase1_perrun_120bar_{run_set}.csv"
    if not os.path.exists(csv_name): print("No data yet."); return
    rows=list(csv.DictReader(open(csv_name)))
    if not rows: return
    from collections import defaultdict
    groups=defaultdict(list)
    for r in rows: groups[r["variant"]].append(r)
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="Summary"
    ws.append(["variant","n","feasible_rate","W_final_mean","W_final_std","W_final_min","W_final_max","CD_delta_mean","eval_total_mean","llm_calls_mean"])
    for name,rs in groups.items():
        wf=np.array([float(r["W_final"]) for r in rs if r["W_final"] not in ("","None")])
        cdd=np.array([float(r["CD_delta"]) for r in rs]); ev=np.array([float(r["eval_total"]) for r in rs])
        lc=np.array([float(r["llm_calls"]) for r in rs]); feas=np.mean([r["feasible"]=="True" for r in rs])
        ws.append([name,len(rs),feas,
                   float(wf.mean()) if len(wf) else None,float(wf.std(ddof=1)) if len(wf)>1 else 0.0,
                   float(wf.min()) if len(wf) else None,float(wf.max()) if len(wf) else None,
                   float(cdd.mean()),float(ev.mean()),float(lc.mean())])
    ws.append([]); ws.append(["timestamp",datetime.datetime.now().isoformat()])
    ws.append(["RUN_SET",run_set]); ws.append(["N_SEEDS",N_SEEDS])
    ws2=wb.create_sheet("PerRun"); keys2=list(rows[0].keys()); ws2.append(keys2)
    for r in rows: ws2.append([r[k] for k in keys2])
    fname=f"phase1_120bar_{run_set}.xlsx"; wb.save(fname)
    print(f"✓ Saved: {fname}  ({len(rows)} runs)")

def download_final(run_set):
    try:
        from google.colab import files as _c; _c.download(f"phase1_120bar_{run_set}.xlsx")
        print(f"⬇ Downloaded")
    except Exception: pass

def main():
    variants=LOCAL_VARIANTS if RUN_SET=="local" else LLM_VARIANTS
    if len(sys.argv)>1:
        want=set(sys.argv[1:]); variants=[v for v in variants if v[0] in want]
    csv_name=f"phase1_perrun_120bar_{RUN_SET}.csv"; done_seeds={}
    if os.path.exists(csv_name):
        for r in csv.DictReader(open(csv_name)):
            done_seeds.setdefault(r["variant"],set()).add(int(r["seed"]))
    print(f"RUN_SET={RUN_SET}: {len(variants)} variants")
    for (name,prop,init,cd) in variants:
        already=done_seeds.get(name,set()); remaining=[s for s in SEEDS if s not in already]
        if not remaining:
            print(f"\n=== {name}: all done ==="); continue
        print(f"\n=== {name} ({len(remaining)}/{N_SEEDS}) ===")
        fieldnames=None
        for s in remaining:
            row=run_one(name,prop,init,cd,s)
            if fieldnames is None: fieldnames=list(row.keys())
            append_csv(csv_name,[row],fieldnames)
            print(f"  seed {s:2d}: W_loop={row['W_loop_end']}  W_final={row['W_final']}  "
                  f"R={row['R_final']:.4f}  eval={row['eval_total']}  llm={row['llm_calls']}  t={row['time_s']}s",flush=True)
            rebuild_excel(RUN_SET)
    rebuild_excel(RUN_SET); download_final(RUN_SET)

if __name__=="__main__":
    main()
