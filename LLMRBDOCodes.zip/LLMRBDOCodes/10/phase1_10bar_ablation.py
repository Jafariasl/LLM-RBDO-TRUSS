# ============================================================
#  PHASE 1 — ABLATION STUDY — 10-bar truss
#  Answers R1-1, R1-7, R1-8, R1-9, R2 (CD attribution), R3-2.
#
#  Factors:
#    proposer : "llm"         DeepSeek generates update rules (API)
#               "llm_generic" DeepSeek, prompt STRIPPED of structural
#                             knowledge + known-good reference (R1-9)
#               "fallback"    hand-coded rule (×1.05 infeasible / ×0.97 feasible)
#               "random"      knowledge-free random perturbation ±10%
#               "none"        no search loop: repair-to-feasible then CD only
#    init     : "warm"        paper's start near reference design
#               "random"      uniform in [A_MIN, A_MAX]
#    cd       : True / False  coordinate-descent refinement
#
#  RUN_SET = "local"  → all no-API variants   (run anywhere, no key)
#  RUN_SET = "llm"    → LLM variants          (Colab, needs API_KEY)

# ============================================================

import numpy as np
from scipy.stats import norm
import requests, time, warnings, datetime, os, csv
warnings.filterwarnings('ignore')

# ================================================================
# EXPERIMENT CONSTANTS
# ================================================================
RUN_SET = "llm"          # kept for reference; the __main__ loop runs BOTH sets
N_SEEDS = 20             # set to 2 for a quick test, then back to 20
SEEDS   = list(range(1, N_SEEDS + 1))

E_MEAN, P_MEAN, RHO   = 1.0e7, 1.0e5, 0.1
COV, DELTA_MAX        = 0.05, 2.0
TARGET_R              = 0.99
A_MIN, A_MAX, N_MEM   = 0.1, 40.0, 10
STAGNATION_LIMIT      = 5
MAX_ITER_LLM          = 150

# ================================================================
# CONFIG
# ================================================================
API_KEY      = "YOUR_DEEPSEEK_API_KEY_HERE"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"

# ---- variant matrix ----
LOCAL_VARIANTS = [
    # (name,                proposer,   init,     cd)
    ("fallback+CD_warm",   "fallback", "warm",   True),
    ("fallback+CD_rand",   "fallback", "random", True),
    ("fallback-noCD_rand", "fallback", "random", False),
    ("random+CD_warm",     "random",   "warm",   True),
    ("random+CD_rand",     "random",   "random", True),
    ("random-noCD_rand",   "random",   "random", False),
    ("CDonly_warm",        "none",     "warm",   True),
    ("CDonly_rand",        "none",     "random", True),
]
LLM_VARIANTS = [
    ("LLM+CD_warm",         "llm",          "warm",   True),   # = paper config
    ("LLM+CD_rand",         "llm",          "random", True),
    ("LLM-noCD_rand",       "llm",          "random", False),
    ("LLMgeneric+CD_rand",  "llm_generic",  "random", True),
    ("LLMfewshot+CD_rand",  "llm_fewshot",  "random", True),
    ("LLMfewshot+CD_warm",  "llm_fewshot",  "warm",   True),
]

# ================================================================
# COUNTERS
# ================================================================
class Counters:
    FIELDS = ["fem_solves", "ls_evals", "form_calls", "hlrf_iters",
              "eval_calls", "llm_calls"]
    def __init__(self):
        self.phase = "init"; self.data = {}; self.form_iter_log = []
    def _d(self):
        if self.phase not in self.data:
            self.data[self.phase] = {f: 0 for f in self.FIELDS}
        return self.data[self.phase]
    def inc(self, f, n=1): self._d()[f] += n
    def set_phase(self, p): self.phase = p; self._d()
    def total(self, f): return sum(d[f] for d in self.data.values())
    def phase_val(self, ph, f): return self.data.get(ph, {}).get(f, 0)

CNT = Counters()

# ================================================================
# GEOMETRY + FEM + FORM + EVALUATE  (identical to Phase 0)
# ================================================================
NODES = np.array([[720.,360.],[720.,0.],[360.,360.],
                  [360.,0.],[0.,360.],[0.,0.]])
MEMBERS = np.array([[4,2],[2,0],[5,3],[3,1],[3,2],
                    [0,1],[3,4],[2,5],[1,2],[0,3]])
FIXED_DOFS = [8,9,10,11]
FREE_DOFS  = [d for d in range(12) if d not in FIXED_DOFS]
MEMBER_LENGTHS = np.array([np.linalg.norm(NODES[j]-NODES[i]) for i,j in MEMBERS])

def fem_10bar(A, E=E_MEAN, P=P_MEAN):
    CNT.inc("fem_solves")
    A = np.asarray(A, dtype=float)
    K = np.zeros((12,12))
    for m,(i,j) in enumerate(MEMBERS):
        L = MEMBER_LENGTHS[m]
        c = (NODES[j,0]-NODES[i,0])/L; s = (NODES[j,1]-NODES[i,1])/L
        k = E*A[m]/L
        ke = k*np.array([[c*c,c*s,-c*c,-c*s],[c*s,s*s,-c*s,-s*s],
                         [-c*c,-c*s,c*c,c*s],[-c*s,-s*s,c*s,s*s]])
        dofs=[2*i,2*i+1,2*j,2*j+1]
        for a in range(4):
            for b in range(4):
                K[dofs[a],dofs[b]] += ke[a,b]
    F = np.zeros(12); F[3] = -P; F[7] = -P
    Kff = K[np.ix_(FREE_DOFS,FREE_DOFS)]
    try:
        uf = np.linalg.solve(Kff, F[FREE_DOFS])
    except np.linalg.LinAlgError:
        return np.inf, np.inf, np.inf, np.zeros(N_MEM)
    U = np.zeros(12); U[FREE_DOFS] = uf
    disp = abs(U[3])
    W = RHO*np.sum(A*MEMBER_LENGTHS)
    return W, disp, disp-DELTA_MAX, None

def limit_state(x):
    CNT.inc("ls_evals")
    E_v = max(x[0], E_MEAN*0.01); P_v = max(x[1], P_MEAN*0.01)
    A_v = np.maximum(x[2:], A_MIN*0.01)
    _, disp, _, _ = fem_10bar(A_v, E=E_v, P=P_v)
    return DELTA_MAX - disp

def form_reliability(A_design):
    CNT.inc("form_calls")
    A_design = np.clip(A_design, A_MIN, A_MAX)
    muy = np.concatenate([[E_MEAN, P_MEAN], A_design])
    sig = COV*muy; dmuy = 1e-4*muy
    X = muy.copy(); Z = (X-muy)/sig; beta = np.linalg.norm(Z)
    eZ, eB, n_it = 100., 100., 0
    for _ in range(100):
        if abs(eZ) <= 1e-3 and abs(eB) <= 1e-3: break
        n_it += 1; CNT.inc("hlrf_iters")
        bp, znp = beta, np.linalg.norm(Z)
        g0 = limit_state(X); G = np.zeros(len(X))
        for i in range(len(X)):
            xp = X.copy(); xp[i] += dmuy[i]
            G[i] = -(limit_state(xp)-g0)/dmuy[i]*sig[i]
        gn = np.linalg.norm(G)
        if gn < 1e-12: break
        beta = beta + g0/gn; Z = (G/gn)*beta; X = muy + sig*Z
        eB = beta-bp; eZ = np.linalg.norm(Z)-znp
    CNT.form_iter_log.append(n_it)
    return float(beta), float(norm.cdf(beta)), float(1.-norm.cdf(beta))

def evaluate(A):
    CNT.inc("eval_calls")
    A = np.atleast_1d(np.asarray(A, dtype=float)).flatten()
    if A.shape[0] != N_MEM: return np.inf, 0.0, False, np.inf
    A = np.clip(A, A_MIN, A_MAX)
    W, disp, cstr, _ = fem_10bar(A)
    _, ps, _ = form_reliability(A)
    return W, ps, (ps >= TARGET_R) and (cstr <= 0), disp

# ================================================================
# PROPOSERS
# ================================================================
FULL_PROMPT_TMPL = """You are an expert in structural reliability optimization.

PROBLEM: 10-bar truss RBDO — minimize weight, keep Reliability >= {tr}
  A[1]..A[10]: cross-sectional areas (in²), bounds [{amin}, {amax}]

STRUCTURAL INFO (critical for good solutions):
  - Members 1,3,4 (A[0],A[2],A[3]): horizontal top/bottom chords → CRITICAL
  - Members 8,9 (A[7],A[8]): diagonal tension members → CRITICAL
  - Members 2,5,6 (A[1],A[4],A[5]): near-zero force → keep at {amin}
  - Members 7,10 (A[6],A[9]): secondary diagonals → moderate

KNOWN GOOD REFERENCE: W≈6076 lb at A≈[39,0.1,27,19,0.1,0.1,3.2,28,27,0.1]

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  Displacement= {disp:.4f} in (limit=2.0)
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE applied ~{stag} times.

Rules:
  1. If reliability < {tr}: increase A[0],A[2],A[3],A[7],A[8] proportionally
     to violation; keep A[1],A[4],A[5] at {amin}.
  2. If reliability >= {tr} and weight > 6500: reduce A[0],A[2],A[3],A[7],A[8]
     by 1-3%; set A[1],A[4],A[5] = {amin}.
  3. If reliability >= {tr} and weight <= 6500: reduce the LARGEST area by
     1-2% per iteration; revert if reliability drops below 0.9950.

Use step sizes proportional to how far from target you are.

Return ONLY this function, no extra text, no markdown fences:

def update_operator(A, reliability, weight, disp):
    import numpy as np
    A_new = A.copy()
    # your adaptive logic
    return np.clip(A_new, {amin}, {amax})
"""

GENERIC_PROMPT_TMPL = """You are an optimization assistant.

PROBLEM: minimize the weight of a structure with 10 design variables
  A[1]..A[10] (continuous, bounds [{amin}, {amax}]) subject to a reliability
  constraint: Reliability >= {tr}. Increasing variables generally increases
  reliability and weight; decreasing them does the opposite. You have NO
  other information about the structure.

CURRENT STATE (iteration {it})
  Weight      = {W:.2f}
  Reliability = {R:.4f}   (need >= {tr})
  {areas}

RECENT HISTORY
{hist}

TASK: Write an adaptive UPDATE RULE applied ~{stag} times that improves the
design based only on the numerical feedback above. Balance exploration and
exploitation as you see fit.

Return ONLY this function, no extra text, no markdown fences:

def update_operator(A, reliability, weight, disp):
    import numpy as np
    A_new = A.copy()
    # your adaptive logic
    return np.clip(A_new, {amin}, {amax})
"""

FEWSHOT_PROMPT_TMPL = """You are an expert in structural reliability optimization.

PROBLEM: 10-bar truss RBDO — minimize weight, keep Reliability >= {tr}
  A[1]..A[10]: cross-sectional areas (in²), bounds [{amin}, {amax}]

STRUCTURAL INFO (critical for good solutions):
  - Members 1,3,4 (A[0],A[2],A[3]): horizontal top/bottom chords → CRITICAL
  - Members 8,9 (A[7],A[8]): diagonal tension members → CRITICAL
  - Members 2,5,6 (A[1],A[4],A[5]): near-zero force → keep at {amin}
  - Members 7,10 (A[6],A[9]): secondary diagonals → moderate

WORKED EXAMPLES (illustrating good update behaviour from DIFFERENT starting
configurations — use these to learn the PATTERN of good moves, not a fixed
target design; the correct final design depends on where you currently are):

Example A — far from feasible, critical members too thin:
  state:  A=[8,15,6,7,20,18,5,9,8,22]  R=0.41  (infeasible, need >= {tr})
  good update: increase A[0],A[2],A[3],A[7],A[8] by ~40-60% each (they are
    under-sized relative to the load path); decrease A[1],A[4],A[5] toward
    {amin} since they carry negligible force; leave A[6],A[9] roughly as is.
  result: R rose to 0.87 (still infeasible but much closer), weight rose
    moderately — this is an acceptable intermediate trade.

Example B — feasible but overweight, redundant members oversized:
  state:  A=[35,12,30,28,15,10,20,32,29,14]  R=0.996  weight=9400 lb
  good update: reduce A[1],A[4],A[5],A[6],A[9] sharply toward {amin} (they
    are not on the critical load path and are wasting weight); reduce
    A[0],A[2],A[3],A[7],A[8] only slightly (2-4%) since they are close to
    the reliability boundary.
  result: weight dropped to ~6900 lb, R stayed above {tr}.

Example C — feasible and near-optimal, fine-tuning phase:
  state:  A=[24,0.3,18,15,0.2,0.2,4,19,18,0.3]  R=0.9915  weight=6350 lb
  good update: identify the single largest-area critical member and reduce
    it by 1-2%; re-check reliability; if it drops below 0.9950 revert that
    member and try a different one. Do not change near-zero members further.
  result: small, safe weight reductions of a few percent per iteration.

CURRENT STATE (iteration {it})
  Weight      = {W:.2f} lb
  Reliability = {R:.4f}   (need >= {tr})
  Displacement= {disp:.4f} in (limit=2.0)
  {areas}

RECENT HISTORY
{hist}

TASK: Using the PATTERN from the worked examples above (not their specific
numbers — your current state is different from all three), write an
adaptive UPDATE RULE applied ~{stag} times that moves the CURRENT design
toward lower weight while keeping reliability >= {tr}.

Return ONLY this function, no extra text, no markdown fences:

def update_operator(A, reliability, weight, disp):
    import numpy as np
    A_new = A.copy()
    # your adaptive logic
    return np.clip(A_new, {amin}, {amax})
"""

class Proposer:
    """Pluggable proposer. kinds: llm | llm_generic | fallback | random"""
    def __init__(self, kind, api_key=None, rng=None):
        self.kind = kind; self.api_key = api_key; self.rng = rng

    LLM_KINDS = ("llm", "llm_generic", "llm_fewshot")

    def get_operator(self, A, R, W, disp, it, history):
        if self.kind in self.LLM_KINDS:
            CNT.inc("llm_calls")
            return self._call_llm(A, R, W, disp, it, history)
        return None   # fallback / random need no operator code

    def apply(self, code, A, R, W, disp):
        if self.kind == "fallback" or (self.kind in self.LLM_KINDS and code is None):
            f = 1.05 if R < TARGET_R else 0.97
            return np.clip(A*f, A_MIN, A_MAX)
        if self.kind == "random":
            pert = 1.0 + self.rng.uniform(-0.10, 0.10, N_MEM)
            return np.clip(A*pert, A_MIN, A_MAX)
        # llm / llm_generic / llm_fewshot with code
        try:
            ns = {"np": np, "numpy": np, "N_MEM": N_MEM,
                  "A_MIN": A_MIN, "A_MAX": A_MAX}
            exec(code, ns)
            raw = ns["update_operator"](A.copy(), float(R), float(W), float(disp))
            A_new = np.atleast_1d(np.asarray(raw, dtype=float)).flatten()
            if A_new.shape[0] != N_MEM: raise ValueError("shape")
            return np.clip(A_new, A_MIN, A_MAX)
        except Exception:
            f = 1.05 if R < TARGET_R else 0.97
            return np.clip(A*f, A_MIN, A_MAX)

    def _call_llm(self, A, R, W, disp, it, history):
        hist = "\n".join(f"  iter={h['iter']:3d}  W={h['W']:9.1f}  R={h['R']:.4f}  "
                         f"feasible={h['feasible']}" for h in history[-6:])
        areas = ", ".join(f"A[{i+1}]={v:.3f}" for i,v in enumerate(A))
        tmpl = {"llm": FULL_PROMPT_TMPL,
                "llm_generic": GENERIC_PROMPT_TMPL,
                "llm_fewshot": FEWSHOT_PROMPT_TMPL}[self.kind]
        prompt = tmpl.format(tr=TARGET_R, amin=A_MIN, amax=A_MAX, it=it,
                             W=W, R=R, disp=disp, areas=areas, hist=hist,
                             stag=STAGNATION_LIMIT)
        try:
            r = requests.post(DEEPSEEK_URL,
                headers={"Authorization": f"Bearer {self.api_key}",
                         "Content-Type": "application/json"},
                json={"model": "deepseek-chat",
                      "messages": [{"role": "user", "content": prompt}],
                      "temperature": 0.7, "max_tokens": 600},
                timeout=45)
            r.raise_for_status()
            content = r.json()["choices"][0]["message"]["content"]
            lines, inside = [], False
            for line in content.splitlines():
                clean = line.replace("```python","").replace("```","")
                if clean.strip().startswith("def update_operator"): inside = True
                if inside: lines.append(clean)
            return "\n".join(lines) if lines else None
        except Exception as e:
            print(f"    ⚠ LLM API error: {e}")
            return None

# ================================================================
# COORDINATE DESCENT
# ================================================================
def coord_descent(A_init, W_init, R_init, max_passes=20):
    A = A_init.copy(); W, R = W_init, R_init
    improved = True
    for _ in range(max_passes):
        if not improved: break
        improved = False
        for i in range(N_MEM):
            for delta in [0.5, 1.0, 2.0, 5.0]:
                A_try = A.copy()
                A_try[i] = max(A_MIN, A[i]-delta)
                if A_try[i] >= A[i]: continue
                W_t, R_t, feas, _ = evaluate(A_try)
                if feas and W_t < W:
                    A, W, R = A_try, W_t, R_t; improved = True; break
    return A, W, R

# ================================================================
# ONE RUN  (any variant)
# ================================================================
def run_one(variant, proposer_kind, init_mode, use_cd, seed, api_key):
    global CNT
    CNT = Counters()
    t0 = time.time()
    rng = np.random.RandomState(seed)
    prop = Proposer(proposer_kind, api_key=api_key, rng=rng)

    CNT.set_phase("init")
    if init_mode == "warm":
        A = np.array([30.,0.5,22.,18.,0.5,0.5,3.,22.,20.,0.5])
        A += rng.uniform(-2, 2, N_MEM)
    else:
        A = rng.uniform(A_MIN, A_MAX, N_MEM)
    A = np.clip(A, A_MIN, A_MAX)
    W, R, feasible, disp = evaluate(A)

    best_A = A.copy(); best_W = W if feasible else np.inf; best_R = R
    history = [{"iter":0,"W":W,"R":R,"disp":disp,"feasible":feasible}]
    conv = [{"iter":0,"best_W":best_W if best_W<np.inf else None,"R":R}]
    stag, prev_bw = 0, best_W

    CNT.set_phase("loop")
    if proposer_kind == "none":
        # repair-to-feasible (uniform up-scaling), budget counted in loop
        it = 0
        while not feasible and it < MAX_ITER_LLM:
            it += 1
            A = np.clip(A*1.05, A_MIN, A_MAX)
            W, R, feasible, disp = evaluate(A)
            conv.append({"iter":it,"best_W":W if feasible else None,"R":R})
            if feasible: best_A, best_W, best_R = A.copy(), W, R
    else:
        op = prop.get_operator(A, R, W, disp, 0, history)
        for it in range(1, MAX_ITER_LLM+1):
            try:
                A_new = prop.apply(op, A, R, W, disp)
                W_n, R_n, feas_n, disp_n = evaluate(A_new)
            except Exception:
                A_new, W_n, R_n, feas_n, disp_n = A.copy(), W, R, feasible, disp
            accept = ((not feasible and R_n > R) or
                      (feasible and feas_n and W_n < W))
            if accept:
                A, W, R, disp, feasible = A_new, W_n, R_n, disp_n, feas_n
                if feas_n and W_n < best_W:
                    best_A, best_W, best_R = A_new.copy(), W_n, R_n
            history.append({"iter":it,"W":W,"R":R,"disp":disp,"feasible":feasible})
            conv.append({"iter":it,"best_W":best_W if best_W<np.inf else None,"R":R})
            stag = (stag+1) if abs(best_W-prev_bw) < 0.5 else 0
            prev_bw = best_W
            if stag >= STAGNATION_LIMIT:
                op = prop.get_operator(A, R, W, disp, it, history)
                stag = 0

    W_loop, R_loop = best_W, best_R
    A_loop = best_A.copy()

    CNT.set_phase("cd")
    if use_cd and best_W < np.inf:
        A_cd, W_cd, R_cd = coord_descent(best_A, best_W, best_R)
        if W_cd < best_W and R_cd >= TARGET_R:
            best_A, best_W, best_R = A_cd, W_cd, R_cd

    elapsed = time.time()-t0
    row = {
        "variant": variant, "proposer": proposer_kind, "init": init_mode,
        "cd": use_cd, "seed": seed,
        "W_loop_end": W_loop if W_loop < np.inf else None,
        "W_final": best_W if best_W < np.inf else None,
        "R_final": best_R,
        "feasible": bool(best_R >= TARGET_R and best_W < np.inf),
        "CD_delta": (W_loop-best_W) if (use_cd and W_loop < np.inf) else 0.0,
        "eval_loop": CNT.phase_val("loop","eval_calls") + CNT.phase_val("init","eval_calls"),
        "eval_cd": CNT.phase_val("cd","eval_calls"),
        "eval_total": CNT.total("eval_calls"),
        "fem_total": CNT.total("fem_solves"),
        "llm_calls": CNT.total("llm_calls"),
        "time_s": round(elapsed,2),
    }
    for i in range(N_MEM):
        row[f"A{i+1}"] = float(best_A[i]) if best_W < np.inf else None
    return row, conv

# ================================================================
# DRIVER + EXCEL
# ================================================================
import csv, os

def append_csv(fname, rows, fieldnames):
    new = not os.path.exists(fname)
    with open(fname, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new: w.writeheader()
        for r in rows: w.writerow(r)

def main(run_set):
    variants = LOCAL_VARIANTS if run_set == "local" else LLM_VARIANTS
    all_rows, conv_rows = [], []
    print(f"RUN_SET={run_set}: {len(variants)} variants × {N_SEEDS} seeds")
    for (name, prop, init, cd) in variants:
        print(f"\n=== {name} ===")
        for s in SEEDS:
            row, conv = run_one(name, prop, init, cd, s, API_KEY)
            all_rows.append(row)
            for c in conv:
                conv_rows.append({"variant":name,"seed":s,
                                  "iter":c["iter"],"best_W":c["best_W"],"R":c["R"]})
            wf = row["W_final"]
            print(f"  seed {s:2d}: W_loop={row['W_loop_end'] if row['W_loop_end'] else 'inf'}"
                  f"  W_final={wf if wf else 'INFEASIBLE'}"
                  f"  R={row['R_final']:.4f}  eval={row['eval_total']}"
                  f"  llm={row['llm_calls']}  t={row['time_s']}s", flush=True)
        # incremental save after EACH variant (crash-safe, resumable)
        vrows = [r for r in all_rows if r["variant"] == name]
        vconv = [c for c in conv_rows if c["variant"] == name]
        append_csv(f"phase1_perrun_{run_set}.csv", vrows, list(vrows[0].keys()))
        append_csv(f"phase1_conv_{run_set}.csv", vconv,
                   ["variant","seed","iter","best_W","R"])
        print(f"  ✓ appended to phase1_perrun_{run_set}.csv", flush=True)
        try:
            from google.colab import files as _colab_files
            _colab_files.download(f"phase1_perrun_{run_set}.csv")
        except Exception:
            pass

    # ---- summary ----
    from collections import defaultdict
    groups = defaultdict(list)
    for r in all_rows: groups[r["variant"]].append(r)
    summary = []
    for name, rs in groups.items():
        wf = np.array([r["W_final"] for r in rs if r["W_final"] is not None])
        wl = np.array([r["W_loop_end"] for r in rs if r["W_loop_end"] is not None])
        cdd = np.array([r["CD_delta"] for r in rs])
        ev = np.array([r["eval_total"] for r in rs])
        lc = np.array([r["llm_calls"] for r in rs])
        feas = np.mean([r["feasible"] for r in rs])
        summary.append({
            "variant": name, "n_runs": len(rs), "feasible_rate": feas,
            "W_final_mean": wf.mean() if len(wf) else None,
            "W_final_std": wf.std(ddof=1) if len(wf) > 1 else 0.0,
            "W_final_min": wf.min() if len(wf) else None,
            "W_final_max": wf.max() if len(wf) else None,
            "W_loop_mean": wl.mean() if len(wl) else None,
            "CD_delta_mean": cdd.mean(),
            "eval_total_mean": ev.mean(), "llm_calls_mean": lc.mean(),
        })
        s = summary[-1]
        print(f"\n{name}: W_final = {s['W_final_mean']:.1f} ± {s['W_final_std']:.1f} "
              f"(min {s['W_final_min']:.1f})  feas={feas*100:.0f}%  "
              f"CDΔ={s['CD_delta_mean']:.1f}" if s['W_final_mean'] else
              f"\n{name}: NO FEASIBLE RUNS")

    # ---- Excel ----
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active; ws.title = "Summary"
    keys = list(summary[0].keys())
    ws.append(keys)
    for s in summary: ws.append([s[k] for k in keys])
    ws.append([]); ws.append(["timestamp", datetime.datetime.now().isoformat()])
    ws.append(["RUN_SET", run_set]); ws.append(["N_SEEDS", N_SEEDS])
    ws.append(["MAX_ITER", MAX_ITER_LLM]); ws.append(["llm_temperature", 0.7])

    ws2 = wb.create_sheet("PerRun")
    keys2 = list(all_rows[0].keys())
    ws2.append(keys2)
    for r in all_rows: ws2.append([r[k] for k in keys2])

    ws3 = wb.create_sheet("Convergence")
    ws3.append(["variant","seed","iter","best_W","R"])
    for c in conv_rows:
        ws3.append([c["variant"],c["seed"],c["iter"],c["best_W"],c["R"]])

    fname = f"phase1_10bar_{run_set}.xlsx"
    wb.save(fname)
    print(f"\n✓ Saved: {fname}")

    # auto-download immediately if running in Google Colab
    try:
        from google.colab import files as _colab_files
        _colab_files.download(fname)
        print(f"  ⬇ Auto-download triggered for {fname}")
    except Exception:
        pass   # not in Colab / download blocked — file still saved on disk

if __name__ == "__main__":
    # Run BOTH variant sets automatically, one after the other.
    # "llm" needs API_KEY; "local" needs no key.
    for _rs in ["llm", "local"]:
        print(f"\n\n############### RUNNING SET: {_rs} ###############\n")
        main(_rs)
    print("\n\nALL DONE — both llm and local sets complete.")
